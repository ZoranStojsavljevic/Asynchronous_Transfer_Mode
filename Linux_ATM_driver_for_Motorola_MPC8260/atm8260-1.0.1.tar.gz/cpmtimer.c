/* 
#
# (C) Copyright 2001
#  David Pegler, Cambridge Broadband Ltd, dwp@cambridgebroadband.com
#  Daris Nevil,  Simple Network Magic Corporation dnevil@snmc.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#
*/

#include <linux/config.h>
#include <linux/module.h>
#include <asm/system.h>
#include "cpmtimer.h"
#include <linux/errno.h>
#include <asm/immap_8260.h>
#include <asm/mpc8260.h>
#include "cpm.h"

/* PEM - added - need bd_t structure and IMAP_ADDR */
#ifdef CONFIG_ATM_VADS
//#include <asm/mpc8260ads.h>
#endif

//#define CPM_TIMER_UNIT_TEST
//#define CPM_TIMER_RESTART_TEST

//#define CPM_TIMER_DEBUG

#ifdef CPM_TIMER_DEBUG
#define DEBUG(args...) printk(args)
#else
#define DEBUG(args...)
#endif


#define CPMT_CAS4	0x8000
#define CPMT_CAS2	0x0080
#define CPMT_FRZ4	0x4000
#define CPMT_FRZ3	0x0400
#define CPMT_FRZ2	0x0040
#define CPMT_FRZ1	0x0004
#define CPMT_STP4	0x2000
#define CPMT_STP3	0x0200
#define CPMT_STP2	0x0020
#define CPMT_STP1	0x0002
#define CPMT_RST4	0x1000
#define CPMT_RST3	0x0100
#define CPMT_RST2	0x0010
#define CPMT_RST1	0x0001
#define CPMT_GM1	0x0008
#define CPMT_GM2	0x0800
#define CPMT_OM		0x0020
#define CPMT_ORI	0x0010
#define CPMT_FRR	0x0008
#define CPMT_GE		0x0001


//-------------------------------------------------------------------
// Local structures

typedef struct
	{
	int			allocated;
	int			cascade;
	const char*		user_name;
	Cpm_Timer_Callout_t	callout;
	} Cpm_Timer_t;


//-------------------------------------------------------------------
// Function Prototypes

#ifdef CPM_TIMER_UNIT_TEST
void cpm_timer_unit_test(void);
static void cpm_timer_ut_callout(void* ter_ptr);
#endif

//-------------------------------------------------------------------
// Global initializers

// Array to hold state of each timer
static Cpm_Timer_t Cpm_Timer[CPM_TIMER_MAX];


//--------------------------------------------------------------
// cpm_timer_create()
//
// Return:
//	0 on success, negative integer on failure
//
// Input Parameters:
//	See include file.
//
// Initializes and allocates the CPM Timers. Returns an error if an illegal
// parameter is given, or if the timer is already allocated.

int cpm_timer_create(
	int timer_num,
	int cascade,
	int freeze,
	int rstgate,
	int prescale,
	CPMT_CE_Type ce,
	int toggle_tout,
	int ref_interrupt,
	int restart,
	CPMT_ICLK_Type iclk,
	int tgate,
	ulong trr
	)
{
	volatile immap_t* immap = (immap_t*)IMAP_ADDR;
	ushort tgcr;
	ushort tmr = 0;
	ushort enable;
	int result;

	DEBUG("cpm_timer_create(%d)\n", timer_num);

	if (prescale > 255)
		{
		DEBUG("cpm_timer_create: prescale > 255");
		return(-EINVAL);
		}

	// Read the Timer Global Configuration Register
	tgcr = immap->im_cpmtimer.cpmt_tgcr1;

	switch (timer_num)
	{
	case 1:
		if (Cpm_Timer[0].allocated)
			return(-EBUSY);

		if (cascade)
			return(-EINVAL);

		// Reset the timer, then place in stop mode
		immap->im_cpmtimer.cpmt_tgcr1 &= ~CPMT_RST1;
		tgcr |= CPMT_STP1;
		enable = CPMT_RST1;

		if (freeze)
			tgcr |= CPMT_FRZ1;
		else
			tgcr &= ~CPMT_FRZ1;

		if (rstgate)
			tgcr |= CPMT_GM1;
		else
			tgcr &= ~CPMT_GM1;

		tmr = prescale << 8;
		tmr |= (ce & 0x03) << 6;

		if (toggle_tout)
			tmr |= CPMT_OM;

		if (ref_interrupt)
			tmr |= CPMT_ORI;

		if (restart)
			tmr |= CPMT_FRR;

		if (cascade && (iclk != CPMT_ICLK_CASCADE))
			return(-EINVAL);

		tmr |= (iclk & 0x03) << 1;

		if (tgate)
			tmr |= CPMT_GE;

		Cpm_Timer[0].allocated = 1;
		Cpm_Timer[0].cascade = cascade;

		// Write the timer mode
		immap->im_cpmtimer.cpmt_tmr1 = tmr;

		// Clear any pending events
		immap->im_cpmtimer.cpmt_ter1 = 0xffff;

		// Set the Timer Reference Register
		immap->im_cpmtimer.cpmt_trr1 = trr;

		break;

	case 2:
		if (Cpm_Timer[1].allocated)
			return(-EBUSY);

		// Reset the timer, then place in stop mode
		immap->im_cpmtimer.cpmt_tgcr1 &= ~CPMT_RST2;
		tgcr |= CPMT_STP2;
		enable = CPMT_RST2;

		if (cascade)
			tgcr |= CPMT_CAS2;
		else
			tgcr &= ~CPMT_CAS2;

		if (freeze)
			tgcr |= CPMT_FRZ2;
		else
			tgcr &= ~CPMT_FRZ2;

		if (rstgate)
			tgcr |= CPMT_GM1;
		else
			tgcr &= ~CPMT_GM1;

		tmr = prescale << 8;
		tmr |= (ce & 0x03) << 6;

		if (toggle_tout)
			tmr |= CPMT_OM;

		if (ref_interrupt)
			tmr |= CPMT_ORI;

		if (restart)
			tmr |= CPMT_FRR;

		if (cascade && (iclk == CPMT_ICLK_CASCADE))
			return(-EINVAL);

		tmr |= (iclk & 0x03) << 1;

		if (tgate)
			tmr |= CPMT_GE;

		if (cascade)
			{
			// Allocate and enable timer 1
			result = cpm_timer_create(1, 0,
				freeze, rstgate, prescale, ce,
				toggle_tout, ref_interrupt,
				restart, CPMT_ICLK_CASCADE, tgate,
				trr);

			if (result)
				return(result);
			}

		Cpm_Timer[1].allocated = 1;
		Cpm_Timer[1].cascade = cascade;

		// Write the timer mode
		immap->im_cpmtimer.cpmt_tmr2 = tmr;

		// Clear any pending events
		immap->im_cpmtimer.cpmt_ter2 = 0xffff;

		// Set the Timer Reference Register
		// Must be a 32 bit access of TRR1 & TRR2 if cascaded
		if (cascade)
			*(ulong*)&(immap->im_cpmtimer.cpmt_trr1) = trr;
		else
			immap->im_cpmtimer.cpmt_trr4 = trr;

		break;

	case 3:
		if (Cpm_Timer[2].allocated)
			return(-EBUSY);

		if (cascade)
			return(-EINVAL);

		// Reset the timer, then place in stop mode
		immap->im_cpmtimer.cpmt_tgcr1 &= ~CPMT_RST3;
		tgcr |= CPMT_STP3;
		enable = CPMT_RST3;

		if (freeze)
			tgcr |= CPMT_FRZ3;
		else
			tgcr &= ~CPMT_FRZ3;

		if (rstgate)
			tgcr |= CPMT_GM2;
		else
			tgcr &= ~CPMT_GM2;

		tmr = prescale << 8;
		tmr |= (ce & 0x03) << 6;

		if (toggle_tout)
			return(-EINVAL);

		if (ref_interrupt)
			tmr |= CPMT_ORI;

		if (restart)
			tmr |= CPMT_FRR;

		if (cascade && (iclk != CPMT_ICLK_CASCADE))
			return(-EINVAL);

		if (tgate)
			tmr |= CPMT_GE;

		tmr |= (iclk & 0x03) << 1;

		Cpm_Timer[2].allocated = 1;
		Cpm_Timer[2].cascade = cascade;

		// Write the timer mode
		immap->im_cpmtimer.cpmt_tmr3 = tmr;

		// Clear any pending events
		immap->im_cpmtimer.cpmt_ter3 = 0xffff;

		// Set the Timer Reference Register
		immap->im_cpmtimer.cpmt_trr3 = trr;

		break;

	case 4:
		if (Cpm_Timer[3].allocated)
			return(-EBUSY);

		// Reset the timer, then place in stop mode
		immap -> im_cpmtimer.cpmt_tgcr1 &= ~CPMT_RST4;
		tgcr |= CPMT_STP4;
		enable = CPMT_RST4;

		if (cascade)
			tgcr |= CPMT_CAS4;
		else
			tgcr &= ~CPMT_CAS4;

		if (freeze)
			tgcr |= CPMT_FRZ4;
		else
			tgcr &= ~CPMT_FRZ4;

		if (rstgate)
			tgcr |= CPMT_GM2;
		else
			tgcr &= ~CPMT_GM2;

		tmr = prescale << 8;
		tmr |= (ce & 0x03) << 6;

		if (toggle_tout)
			tmr |= CPMT_OM;

		if (ref_interrupt)
			tmr |= CPMT_ORI;

		if (restart)
			tmr |= CPMT_FRR;

		if (cascade && (iclk == CPMT_ICLK_CASCADE))
			return(-EINVAL);

		tmr |= (iclk & 0x03) << 1;

		if (tgate)
			tmr |= CPMT_GE;

		if (cascade)
			{
			// Allocate and enable timer 3
			result = cpm_timer_create(3, 0,
				freeze, rstgate, prescale, ce,
				toggle_tout, ref_interrupt,
				restart, CPMT_ICLK_CASCADE, tgate,
				trr);

			if (result)
				return(result);
			}

		Cpm_Timer[3].allocated = 1;
		Cpm_Timer[3].cascade = cascade;

		// Write the timer mode
		immap->im_cpmtimer.cpmt_tmr4 = tmr;
		DEBUG("cpm tmr4=%x\n", tmr);

		// Clear any pending events
		immap->im_cpmtimer.cpmt_ter4 = 0xffff;

		// Set the Timer Reference Register
		// Must be a 32 bit access of TRR1 & TRR2 if cascaded
		if (cascade)
			*(ulong*)&(immap->im_cpmtimer.cpmt_trr3) = trr;
		else
			immap->im_cpmtimer.cpmt_trr4 = trr;

		DEBUG("cpm trr4=%lx\n", trr);

		break;

	default:
		DEBUG("cpm_timer_create: timer_num must be 1-4\n");
		return(-ECHRNG);
	}

	// Write the new updated value of TGCR
	immap->im_cpmtimer.cpmt_tgcr1 = tgcr;

	// Enable the timer, but leave in stop mode
	immap->im_cpmtimer.cpmt_tgcr1 |= enable;

	// Success
	return(0);
}
EXPORT_SYMBOL(cpm_timer_create);


//--------------------------------------------------------------
// cpm_timer_delete()
//
// Return:
//	0 on success, negative integer on failure
//
// Input Parameters:
//	(I) timer number - value of 1-4 to identify the timer to delete
//
// Disables and deallocates the specified timer

int cpm_timer_delete(int timer_num)
{
	volatile immap_t* immap = (immap_t*)IMAP_ADDR;
	ushort tgcr;

	DEBUG("cpm_timer_delete(%d)\n", timer_num);

	// Read the Timer Global Configuration Register
	tgcr = immap->im_cpmtimer.cpmt_tgcr1;

	switch (timer_num)
	{
	case 1:
		tgcr |= CPMT_STP1;
		tgcr &= ~CPMT_RST1;
		Cpm_Timer[0].allocated = 0;
		break;

	case 2:
		tgcr |= CPMT_STP2;
		tgcr &= ~CPMT_RST2;
		Cpm_Timer[1].allocated = 0;
		break;

	case 3:
		tgcr |= CPMT_STP3;
		tgcr &= ~CPMT_RST3;
		Cpm_Timer[2].allocated = 0;
		break;

	case 4:
		tgcr |= CPMT_STP4;
		tgcr &= ~CPMT_RST4;
		Cpm_Timer[3].allocated = 0;
		break;

	default:
		DEBUG("cpm_timer_delete: timer_num must be 1-4\n");
		return(-ECHRNG);
	}

	// Write the new updated value of TGCR
	immap->im_cpmtimer.cpmt_tgcr1 = tgcr;
	DEBUG("cpm timer tgcr=%x\n", tgcr);

	// Success
	return(0);
}
EXPORT_SYMBOL(cpm_timer_delete);


//--------------------------------------------------------------
// cpm_timer_start()
//
// Return:
//	0 on success, negative integer on failure
//
// Input Parameters:
//	(I) timer number - value of 1-4 to identify the timer to delete
//
// Starts the operation of the timer

int cpm_timer_start(int timer_num)
{
	volatile immap_t* immap = (immap_t*)IMAP_ADDR;
	ushort tgcr;

	DEBUG("cpm_timer_start(%d)\n", timer_num);

	// Read the Timer Global Configuration Register
	tgcr = immap->im_cpmtimer.cpmt_tgcr1;

	switch (timer_num)
	{
	case 1:
		if (!Cpm_Timer[0].allocated)
			return(-ENODEV);

		tgcr &= ~CPMT_STP1;
		break;

	case 2:
		if (!Cpm_Timer[1].allocated)
			return(-ENODEV);

		tgcr &= ~CPMT_STP2;

		if (Cpm_Timer[1].cascade)
			tgcr &= ~CPMT_STP1;

		break;

	case 3:
		if (!Cpm_Timer[2].allocated)
			return(-ENODEV);

		tgcr &= ~CPMT_STP3;
		break;

	case 4:
		if (!Cpm_Timer[3].allocated)
			return(-ENODEV);

		tgcr &= ~CPMT_STP4;

		if (Cpm_Timer[3].cascade)
			tgcr &= ~CPMT_STP3;

		break;

	default:
		DEBUG("cpm_timer_start: timer_num must be 1-4\n");
		return(-ECHRNG);
	}

	// Write the new updated value of TGCR
	immap->im_cpmtimer.cpmt_tgcr1 = tgcr;

	// Success
	return(0);
}
EXPORT_SYMBOL(cpm_timer_start);


//--------------------------------------------------------------
// cpm_timer_stop()
//
// Return:
//	0 on success, negative integer on failure
//
// Input Parameters:
//	(I) timer number - value of 1-4 to identify the timer to delete
//
// Starts the operation of the timer

int cpm_timer_stop(int timer_num)
{
	volatile immap_t* immap = (immap_t*)IMAP_ADDR;
	ushort tgcr;

	DEBUG("cpm_timer_stop(%d)\n", timer_num);

	// Read the Timer Global Configuration Register
	tgcr = immap->im_cpmtimer.cpmt_tgcr1;

	switch (timer_num)
	{
	case 1:
		if (!Cpm_Timer[0].allocated)
			return(-ENODEV);

		tgcr |= CPMT_STP1;
		break;

	case 2:
		if (!Cpm_Timer[1].allocated)
			return(-ENODEV);

		tgcr |= CPMT_STP2;

		if (Cpm_Timer[1].cascade)
			tgcr |= CPMT_STP1;

		break;

	case 3:
		if (!Cpm_Timer[2].allocated)
			return(-ENODEV);

		tgcr |= CPMT_STP3;
		break;

	case 4:
		if (!Cpm_Timer[3].allocated)
			return(-ENODEV);

		tgcr |= CPMT_STP4;

		if (Cpm_Timer[3].cascade)
			tgcr |= CPMT_STP3;

		break;

	default:
		DEBUG("cpm_timer_stop: timer_num must be 1-4\n");
		return(-ECHRNG);
	}

	// Write the new updated value of TGCR
	immap->im_cpmtimer.cpmt_tgcr1 = tgcr;

	// Success
	return(0);
}
EXPORT_SYMBOL(cpm_timer_stop);



//--------------------------------------------------------------
// cpm_timer_set_callback()
//
// Return:
//	0 on success, negative integer on failure
//
// Input Parameters:
//	(I) timer_num - identifies a specific CPM timer
//	(I) callout - pointer to a callout function to be executed when
//		the timer generates an interrupt.  Should be set to
//		NULL if no callout is desired.
//
// Sets the callback function for interrupt events driven from the
// timer.

int cpm_timer_set_callback(int timer_num,
	Cpm_Timer_Callout_t callout)
{
	volatile immap_t* immap = (immap_t*)IMAP_ADDR;
	ushort timer_vector;
	volatile ushort* ter_addr;

	DEBUG("cpm_timer_set_callback(%d)\n", timer_num);

	switch (timer_num)
	{
	case 1:
		if (!Cpm_Timer[0].allocated)
			return(-ENODEV);

		timer_vector = 0x0C;
		ter_addr = &(immap->im_cpmtimer.cpmt_ter1);

		break;

	case 2:
		if (!Cpm_Timer[1].allocated)
			return(-ENODEV);

		timer_vector = 0x0D;
		ter_addr = &(immap->im_cpmtimer.cpmt_ter2);

		break;

	case 3:
		if (!Cpm_Timer[2].allocated)
			return(-ENODEV);

		timer_vector = 0x0E;
		ter_addr = &(immap->im_cpmtimer.cpmt_ter3);

		break;

	case 4:
		if (!Cpm_Timer[3].allocated)
			return(-ENODEV);

		timer_vector = 0x0F;
		ter_addr = &(immap->im_cpmtimer.cpmt_ter4);

		break;

	default:
		DEBUG("cpm_timer_set_callback: timer_num must be 1-4\n");
		return(-ECHRNG);
	}

	// Save the callout pointer
	Cpm_Timer[timer_num-1].callout = callout;

	// Install the interrupt handler and enable interrupts
    request_8xxirq(timer_vector, (void*)ter_addr, 0, "cpmtmr", 0);

	// Success
	return(0);
}
EXPORT_SYMBOL(cpm_timer_set_callback);



//--------------------------------------------------------------
// cpm_timer_set_tcr()
//
// Return:
//	0 on success, negative integer on failure
//
// Input Parameters:
//	(I) timer_num - identifies a specific CPM timer
//	(I) tcr - 32 bit value for cascaded timer, 16 bit otherwise
//
// Sets the Timer Capture Register

int cpm_timer_set_tcr(int timer_num, ulong tcr)
{
	volatile immap_t* immap = (immap_t*)IMAP_ADDR;

	DEBUG("cpm_timer_set_tcr(%d),tcr=%ld\n", timer_num, tcr);

	switch (timer_num)
	{
	case 1:
		if (!Cpm_Timer[0].allocated)
			return(-ENODEV);

		immap->im_cpmtimer.cpmt_tcr1 = tcr;

		break;

	case 2:
		if (!Cpm_Timer[1].allocated)
			return(-ENODEV);

		if (Cpm_Timer[1].cascade)
			*(ulong*)&(immap->im_cpmtimer.cpmt_tcr2) = tcr;
		else
			immap->im_cpmtimer.cpmt_tcr2 = tcr;

		break;

	case 3:
		if (!Cpm_Timer[2].allocated)
			return(-ENODEV);

		immap->im_cpmtimer.cpmt_tcr3 = tcr;

		break;

	case 4:
		if (!Cpm_Timer[3].allocated)
			return(-ENODEV);

		if (Cpm_Timer[3].cascade)
			*(ulong*)&(immap->im_cpmtimer.cpmt_tcr4) = tcr;
		else
			immap->im_cpmtimer.cpmt_tcr4 = tcr;

		break;

	default:
		DEBUG("cpm_timer_set_tcr: timer_num must be 1-4\n");
		return(-ECHRNG);
	}

	// Success
	return(0);
}
EXPORT_SYMBOL(cpm_timer_set_tcr);



//--------------------------------------------------------------
// cpm_timer_get_tcr()
//
// Return:
//	0 on success, negative integer on failure
//
// Input Parameters:
//	(I) timer_num - identifies a specific CPM timer
//	(O) tcr - pointer to a 32 bit integer to hold the value,
//		32 bit value for cascaded timer, 16 bit otherwise
//
// Gets the Timer Capture Register

int cpm_timer_get_tcr(int timer_num, ulong* tcr)
{
	volatile immap_t* immap = (immap_t*)IMAP_ADDR;

	DEBUG("cpm_timer_get_tcr(%d)\n", timer_num);

	switch (timer_num)
	{
	case 1:
		if (!Cpm_Timer[0].allocated)
			return(-ENODEV);

		*tcr = immap->im_cpmtimer.cpmt_tcr1;

		break;

	case 2:
		if (!Cpm_Timer[1].allocated)
			return(-ENODEV);

		if (Cpm_Timer[1].cascade)
			*tcr = *(ulong*)&(immap->im_cpmtimer.cpmt_tcr2);
		else
			*tcr = immap->im_cpmtimer.cpmt_tcr2;

		break;

	case 3:
		if (!Cpm_Timer[2].allocated)
			return(-ENODEV);

		*tcr = immap->im_cpmtimer.cpmt_tcr3;

		break;

	case 4:
		if (!Cpm_Timer[3].allocated)
			return(-ENODEV);

		if (Cpm_Timer[3].cascade)
			*tcr = *(ulong*)&(immap->im_cpmtimer.cpmt_tcr4);
		else
			*tcr = immap->im_cpmtimer.cpmt_tcr4;

		break;

	default:
		DEBUG("cpm_timer_get_tcr: timer_num must be 1-4\n");
		return(-ECHRNG);
	}

	// Success
	return(0);
}
EXPORT_SYMBOL(cpm_timer_get_tcr);




//--------------------------------------------------------------
// cpm_timer_set_tcn()
//
// Return:
//	0 on success, negative integer on failure
//
// Input Parameters:
//	(I) timer_num - identifies a specific CPM timer
//	(I) tcn - 32 bit value for cascaded timer, 16 bit otherwise
//
// Sets the Timer Counter Register

int cpm_timer_set_tcn(int timer_num, ulong tcn)
{
	volatile immap_t* immap = (immap_t*)IMAP_ADDR;

	DEBUG("cpm_timer_set_tcn(%d)\n,tcn=%ld", timer_num, tcn);

	switch (timer_num)
	{
	case 1:
		if (!Cpm_Timer[0].allocated)
			return(-ENODEV);

		immap->im_cpmtimer.cpmt_tcn1 = tcn;

		break;

	case 2:
		if (!Cpm_Timer[1].allocated)
			return(-ENODEV);

		if (Cpm_Timer[1].cascade)
			*(ulong*)&(immap->im_cpmtimer.cpmt_tcn2) = tcn;
		else
			immap->im_cpmtimer.cpmt_tcn2 = tcn;

		break;

	case 3:
		if (!Cpm_Timer[2].allocated)
			return(-ENODEV);

		immap->im_cpmtimer.cpmt_tcn3 = tcn;

		break;

	case 4:
		if (!Cpm_Timer[3].allocated)
			return(-ENODEV);

		if (Cpm_Timer[3].cascade)
			*(ulong*)&(immap->im_cpmtimer.cpmt_tcn4) = tcn;
		else
			immap->im_cpmtimer.cpmt_tcn4 = tcn;

		break;

	default:
		DEBUG("cpm_timer_set_tcn: timer_num must be 1-4\n");
		return(-ECHRNG);
	}

	// Success
	return(0);
}
EXPORT_SYMBOL(cpm_timer_set_tcn);



//--------------------------------------------------------------
// cpm_timer_get_tcn()
//
// Return:
//	0 on success, negative integer on failure
//
// Input Parameters:
//	(I) timer_num - identifies a specific CPM timer
//	(O) tcn - pointer to a 32 bit integer to hold the value,
//		32 bit value for cascaded timer, 16 bit otherwise
//
// Gets the Timer Counter Register

int cpm_timer_get_tcn(int timer_num, ulong* tcn)
{
	volatile immap_t* immap = (immap_t*)IMAP_ADDR;

	DEBUG("cpm_timer_get_tcn(%d)\n", timer_num);

	switch (timer_num)
	{
	case 1:
		if (!Cpm_Timer[0].allocated)
			return(-ENODEV);

		*tcn = immap->im_cpmtimer.cpmt_tcn1;

		break;

	case 2:
		if (!Cpm_Timer[1].allocated)
			return(-ENODEV);

		if (Cpm_Timer[1].cascade)
			*tcn = *(ulong*)&(immap->im_cpmtimer.cpmt_tcn2);
		else
			*tcn = immap->im_cpmtimer.cpmt_tcn2;

		break;

	case 3:
		if (!Cpm_Timer[2].allocated)
			return(-ENODEV);

		*tcn = immap->im_cpmtimer.cpmt_tcn3;

		break;

	case 4:
		if (!Cpm_Timer[3].allocated)
			return(-ENODEV);

		if (Cpm_Timer[3].cascade)
			*tcn = *(ulong*)&(immap->im_cpmtimer.cpmt_tcn4);
		else
			*tcn = immap->im_cpmtimer.cpmt_tcn4;

		break;

	default:
		DEBUG("cpm_timer_get_tcn: timer_num must be 1-4\n");
		return(-ECHRNG);
	}

	// Success
	return(0);
}
EXPORT_SYMBOL(cpm_timer_get_tcn);



#ifdef CPM_TIMER_UNIT_TEST

//--------------------------------------------------------------
// cpm_timer_unit_test()
//
// Return:
//	0 on success, negative integer on failure
//
// Input Parameters:
//	(I) param - unused
//
// Disables the specified timer.

void cpm_timer_unit_test(void)
{
	int result;

	DEBUG("cpm_timer_unit_test\n");

	// Create a one-shot timer
	result = cpm_timer_create(
		4, // timer_num
		0, // cascade
		0, // freeze
		0, // rstgate
		0xff, // prescale
		CPMT_CE_DISABLE, // capture edge
		0, // toggle_tout,
		1, // ref_interrupt
#ifdef CPM_TIMER_RESTART_TEST
		1, // restart
#else
		0, // restart
#endif
		CPMT_ICLK_SYS_CLK_16, // iclk
		0, // tgate1
		0xfff0 // trr
		);

	if (result)
		printk(KERN_WARNING "cpm_timer_create=%d\n", result);

	// Set the callback function
	result = cpm_timer_set_callback(4, cpm_timer_ut_callout);
	if (result)
		printk(KERN_WARNING "cpm_timer_set_callback=%d\n", result);

	result = cpm_timer_start(4);
	if (result)
		printk(KERN_WARNING "cpm_timer_start=%d\n", result);
}


static void cpm_timer_ut_callout(void* ter_ptr)
{
	volatile ushort* ter = (volatile ushort*)ter_ptr;
	int result;
	static int counter = 0;

	// Read the Event Register
	printk(KERN_INFO "cpm_timer ter=0x%x\n", *ter);

	// Clear the timer events
	*ter = *ter;

	if (counter++ > 4)
		{
		result = cpm_timer_stop(4);
		if (result)
			printk(KERN_WARNING "cpm_timer_stop() result=%d\n", result);

		result = cpm_timer_delete(4);
		if (result)
			printk(KERN_WARNING "cpm_timer_delete() result=%d\n", result);

		}
}

#endif // CPM_TIMER_UNIT_TEST


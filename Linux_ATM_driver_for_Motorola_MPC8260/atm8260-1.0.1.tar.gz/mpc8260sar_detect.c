/*
#######################################################################
#
# (C) Copyright 2002
# Peter McCormick, pete261@yahoo.com
# Eastern Research Inc., http://www.erinc.com
# ported from mpc860sar project, http://mpc860sar.sourceforge.net
#
# (C) Copyright 2001
# David Pegler, Cambridge Broadband Ltd, dwp@cambridgebroadband.com
# Daris Nevil,  Simple Network Magic Corporation dnevil@snmc.com
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
*/

#ifdef MODULE
#include <linux/module.h>
#endif
#include <linux/config.h>
#include <linux/init.h>
#include <linux/atm.h>
#include <linux/atmdev.h>

#include "utopia.h"
#include "debug.h"
#include "mpc8260sar.h"

extern const struct atmdev_ops mpc8260sar_ops;

/* module parameters */
unsigned long base = 0xf0000000;
unsigned long brg = 6;

/* PEM - added */
#ifdef MODULE
MODULE_DESCRIPTION("ATM driver");
MODULE_AUTHOR("Peter McCormick pete261@yahoo.com");
MODULE_SUPPORTED_DEVICE("Motorola MPC8260");
MODULE_PARM(base, "l");
MODULE_PARM_DESC(base, "Base address for IMMR");
MODULE_PARM(brg, "l");
MODULE_PARM_DESC(brg, "Which baud rate generator to use");
#endif
 
extern int mpc8260sar_init_proc(struct atm_dev *);

int __init mpc8260atm_detect(void)
{
    RETURN_ON_ERROR(mpc8260sar_init());

    utopia_disable_interrupts();
    utopia_dev = atm_dev_register(UTOPIA_DEV_LABEL,&mpc8260sar_ops,-1,0);

    // Were we able to register this device?
    if(!utopia_dev){
      return -EINVAL;
    }

    DINIT_PRINTK("utopia_dev->number=%d\n", utopia_dev->number);

    // Device is registered
    // Try to initialise
    if(utopia_init(utopia_dev) != 0){
      printk(KERN_ERR "Failed to initialise and start CPM ATM interface\n");
      atm_dev_deregister(utopia_dev);
      utopia_dev = NULL;
      return -EINVAL;
    }
    else{   // Success
      printk(KERN_INFO "CPM ATM(utopia) driver Version 1.1\n");
    }
    
#ifdef CONFIG_ATM_VADS
    suni_init(utopia_dev); 
    if(utopia_dev->phy->start)
      utopia_dev->phy->start(utopia_dev);
#endif
   
    mpc8260sar_init_proc(utopia_dev);

    utopia_enable_interrupts(utopia_dev);

    return 0;
}

module_init(mpc8260atm_detect);


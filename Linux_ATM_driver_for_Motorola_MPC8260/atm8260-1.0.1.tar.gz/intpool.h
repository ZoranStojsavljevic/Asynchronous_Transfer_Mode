/*
#######################################################################
#
# (C) Copyright 2001
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
# Notes:
# 
# Defines an object (intpool_t) from which client code can allocate,
# and then free, non-negative integers.  Will always return the lowest
# free value.
# 
#######################################################################
*/

#ifndef __INTPOOL_H__
#define __INTPOOL_H__

#include <linux/atm.h>
#include <linux/atmdev.h>
#include <linux/sonet.h>
#include <linux/skbuff.h>
#include <linux/time.h>


/* intpool_t
 * keeps track of a pool of numbers from which the client
 * code can allocate a number or free an allocated number.
 * intpool_alloc() always returns the smallest free number
 * or -1 for error.
 * DO NOT MODIFY DIRECTLY.  Instead use
 *    intpool_init(intpool_t *ip, int log2_size)
 *    intpool_destroy(intpool_t *ip)
 *    intpool_alloc(intpool *ip)
 *    intpool_free(intpool_t *ip, int val);
 *    intpool_inuse(intpool_t *ip);
 */
typedef struct
{
    ushort *bitmask;
    ulong *chksums;
    int bitmask_sz;
    int chksums_sz;
    int log2_hwords_in_chksum;
    int inuse;
} intpool_t;


/* intpool_t methods */
void intpool_init(intpool_t *ip, int log2_size);
void intpool_destroy(intpool_t *ip);
int intpool_alloc(intpool_t *ip);
void intpool_free(intpool_t *ip, int val);
int intpool_inuse(intpool_t *ip);                /* returns number of channels allocated */

#endif // __INTPOOL_H__

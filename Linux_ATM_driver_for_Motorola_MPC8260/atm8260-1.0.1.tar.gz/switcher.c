/*
#######################################################################
#
# (C) Copyright 2001
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
# Notes:
# This file contains function definitions and data applicable to the
# ATM switching fabric
#
# The interface to the switching fabric is via the /proc file system.
# User code will be able to add and delete switched VCs by writing
# to a file in /proc, and monitor the status of open switched VCs by
# reading a file in /proc.
# 
# 
#######################################################################
*/
/*##################### Includes ############################*/
#include <linux/module.h>
#include <linux/config.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/errno.h>
#include <linux/atm.h>
#include <linux/atmdev.h>
#include <linux/sonet.h>
#include <linux/skbuff.h>
#include <linux/time.h>
#include <linux/delay.h>
#include <linux/uio.h>
#include <linux/init.h>
#include <asm/system.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include <asm/string.h>
#include <asm/byteorder.h>

#include <linux/netdevice.h>
#include <linux/ioport.h>
#include <linux/atm.h>
#include <linux/proc_fs.h>

extern struct proc_dir_entry *atm_proc_root; /* @@@ move elsewhere */

#include "debug.h"
#include "switcher.h"
#include "mpc8260sar.h"		/* PEM - changed */

/*##################### Macros  #############################*/
#define isdigit(c)	(((unchar)((c)-'0')) < 10)
#define isspace(c)  ((c)==' ' || (c)=='\t' || (c)=='\r' || (c)=='\n')

/*##################### Defines #############################*/
#define MAX_SWITCHED_PVCS 10 // Maximum simultaneous switched PVCs

/*##################### Types ###############################*/

/*##################### Forward declarations ################*/
static sw_pvc_t *list_get(sw_pvc_t **list);
static void list_put(sw_pvc_t **list, sw_pvc_t *entry);
static sw_pvc_t *list_remove_match(sw_pvc_t **list, sw_pvc_t *match);
static int switch_write(struct file *file, const char *buffer, unsigned long count, void *data);
static int switch_read(char *buf, char **start, off_t offset, int count, int *eof, void *data);
static int switch_list_print_header(char *buf);
static int switch_list_print_entry(char *buf, int off, sw_pvc_t *entry);
static int parse_cmd(const char *text, unsigned long textlen, sw_pvc_t *pvc, int *add);
static int get_ci(const char *text, int textlen, short *port, short *vpi, int *vci);
static int switch_add(sw_pvc_t *pvc);
static int switch_delete(sw_pvc_t *pvc);

/*##################### File scope data #####################*/
static sw_pvc_t sw_pvcs[MAX_SWITCHED_PVCS];
static sw_pvc_t *free_list = NULL;
static sw_pvc_t *alloc_list = NULL;

/*##################### Function definitions ################*/

/* PEM - stubs for now... */
int mpc8260sar_init_ptp_channel(sw_pvc_t *pvc)
{
  return 0;
}

int mpc8260sar_delete_ptp_channel(sw_pvc_t *pvc)
{
  return 0;
}

static int switch_add(sw_pvc_t *pvc)
{
    int result = mpc8260sar_init_ptp_channel(pvc);
    if(result == 0)
        MOD_INC_USE_COUNT;
    return result;
}
static int switch_delete(sw_pvc_t *pvc)
{
    int result =  mpc8260sar_delete_ptp_channel(pvc);
    if (result == 0)
        MOD_DEC_USE_COUNT;
    return result;
}


/*
#############################################################
# List manipulation functions
#           list_get()          removes head entry from list
#           list_put()          adds entry to head of list
#           list_remove_match() removes matching entry from list
#############################################################
*/
static sw_pvc_t *list_get(sw_pvc_t **list)
{
    sw_pvc_t *retval = *list;

    if (*list)
        *list = (*list)->next;

    return retval;
}

static void list_put(sw_pvc_t **list, sw_pvc_t *entry)
{
    entry->next = *list;
    *list = entry;
}

static sw_pvc_t *list_remove_match(sw_pvc_t **list, sw_pvc_t *match)
{
    sw_pvc_t *entry = *list;
    sw_pvc_t **pentry = list;
    while (entry)
    {
        // Compare the input CI
        if (entry->iport == match->iport &&
            entry->ivpi == match->ivpi &&
            entry->ivci == match->ivci)
        {
            // remove entry from list and return entry
            *pentry = entry->next;
            return entry;
        }

        pentry = &(entry->next);
        entry = entry->next;
    }
    // not in list
    return NULL;
}

/*
#########################################################
#
#  Function : switch_write
#             
#  Purpose  : Allows user to add/delete a new switched VC
#             E.g.
#                 echo "add 0.0.32 1.0.33 100 cbr" > /proc/atm/switch
#             adds a VC 0.0.32->1.0.33 with pcr 100.
#             And
#                 echo "del 0.0.32"
#             deletes the same VC.
#             configured
#  Args     : As per the Linux proc_read standard
#             
#  Returns  : number bytes read from buffer
#             
#  Notes    : Registered with /proc file system by switch_init().
##########################################################
#  Edit history:
#  Who     When    What
#  AJZ     23Aug01 Created
##########################################################
*/
static int switch_write(struct file *file, const char *buffer, unsigned long count, void *data)
{
    sw_pvc_t pvc;
    int add;

    // Get the command
    if (parse_cmd(buffer, count, &pvc, &add) != 0)
    {
        printk(KERN_ERR "Error: (" __FUNCTION__ ") couldn't parse command\n");
        // AJZ TODO should this return -1 or something?
        return count;
    }
    
    // Was the command "add" or "del"?
    if (add)
    {
        sw_pvc_t *newpvc;
        
        // Get a free struct
        if ((newpvc = list_get(&free_list)) == NULL)
        {
            printk(KERN_ERR "Error: attempted to create too many switched PVCs\n");
            // AJZ TODO should this return -1 or something?
            return count;
        }
        
        // Copy the pvc returned from parse_cmd into the pvc
        // taken from free list
        memcpy(newpvc, &pvc, sizeof(pvc));
        
        // Open a new CPM channel
        if (switch_add(newpvc) == 0)
            list_put(&alloc_list, newpvc); // Add to list of allocated structs
        else
        {
            printk(KERN_ERR "Error: failed to create switched PVC\n");
            list_put(&free_list, newpvc);
        }
    }
    else
    {
        // Remove a match from list
        sw_pvc_t *match = list_remove_match(&alloc_list, &pvc);
 
        // Did we find one?
        if (match)
        {
            // Yes - close channel in CPM
            if (switch_delete(match) == 0)
                list_put(&free_list, match);
            else
            {
                printk(KERN_ERR "Error: could not delete switched PVC\n");
                list_put(&alloc_list, match);
            }
        }
        else
            printk(KERN_ERR "Error: tried to remove non existent PVC\n");
    }

    return count;
}

static int textcmp(const char *s1, const char *s2, int len)
{
    while (--len != -1)
        if (s1[len] != s2[len])
            return -1;
    return 0;
}

#define PARSE_CMD_USAGE() printk("usage:\n"                                     \
       "\tadd <iport>.<ivpi>.<ivci> <oport>.<ovpi>.<ovci> <pcr> [ubr|cbr]\n"    \
       "\tdel <iport>.<ivpi>.<ivci>\n")

static int parse_cmd(const char *text, unsigned long textlen, sw_pvc_t *pvc, int *add)
{
    int i;
    int result;
    const char *cmdsubstr[4];
    int cmdsubstrlen[4] = {0};
    int pcr = 0;

    // Skip spaces
    while(textlen && isspace(*text)) {
        text++;
        textlen--;
    }
    
    // Get command string
    if (textlen >= 4 && textcmp(text, "add ", 4) == 0)
        *add = 1;
    else if (textlen >= 4 && textcmp(text, "del ", 4) == 0)
        *add = 0;
    else
    {
        PARSE_CMD_USAGE();
        return -1;
    }
    text += 4;
    
    // Split command into 4 substrings (or 1 if we're deleting)
    for(i = 0; i < (*add?4:1); i++)
    {
        while(textlen && isspace(*text)) {
            text++;
            textlen--;
        }
        if (!textlen)
            return -1; // No more substrings
        cmdsubstr[i] = text;
        while(textlen && !isspace(*text)) {
            text++;
            textlen--;
            cmdsubstrlen[i]++;
        }
    }

    // We've now got 4 or 1 substrings in cmdsubstr[]

    // Get intput CI
    if ((result = get_ci(cmdsubstr[0], cmdsubstrlen[0], &(pvc->iport), &(pvc->ivpi), &(pvc->ivci))))
        return result;

    // That's all there is to do if we're deleting
    if (!*add)
        return 0;

    // Get output CI
    if ((result = get_ci(cmdsubstr[1], cmdsubstrlen[1], &(pvc->oport), &(pvc->ovpi), &(pvc->ovci))))
        return result;

    // Get PCR
    do 
    {
        if (pcr > INT_MAX/10)
            return -1; // number too big
        pcr = (pcr*10)+((*cmdsubstr[2]++)-'0');
        cmdsubstrlen[2]--;
    }
    while (cmdsubstrlen[2] && isdigit(*cmdsubstr[2]));
    pvc->pcr = pcr;

    // Get traffic class
    if (cmdsubstrlen[3] >= 3  && textcmp(cmdsubstr[3],"ubr",3) == 0)
        pvc->traffic_class = ATM_UBR;
    else if (cmdsubstrlen[3] >= 3  && textcmp(cmdsubstr[3],"cbr",3) == 0)
        pvc->traffic_class = ATM_CBR;
    else
    {
        PARSE_CMD_USAGE();
        return -1;
    }

    // Success
    return 0;
}

static int get_ci(const char *text, int textlen, short *port, short *vpi, int *vci)
{
    int part[3] = {0};
    int i = 0;
    struct atm_dev *dev;
    dev_data_t *dev_data;

    while (1)
    {
        if (!textlen)
            return -1; /* empty or ends with a dot */
        if (i == 3)
            return -1; /* too long */
        if (isdigit(*text))
        {
            if (*text == '0' && isdigit(text[1]))
                return -1; /* no leading zeroes */
            do 
            {
                if (part[i] > INT_MAX/10)
                    return -1;/* number too big */
                part[i] = part[i]*10+*text++-'0';
                textlen--;
            }
            while (textlen && isdigit(*text));
            i++;
            if (!textlen)
                break;
            if (*text++ != '.')
                return -1; /* non-PVC character */
            textlen--;
            continue;
        }
        
        if (*text++ == '*')
            part[i++] = -1;
        textlen--;
        if (!textlen)
            break;

        if (*text++ != '.')
            return -1; /* dot required */
        textlen--;
    }
    
    if (i != 3)
        return -1; /* no dots */

    /* Set port number */
    if (part[0] != -1 && (dev = port2dev(part[0])) != NULL)
        *port = (short) part[0];
    else
    {
        printk("Error: Unrecognised port\n");
        return -1;      /* port not registered with switch fabric */
    }
 
    dev_data = (dev_data_t *)dev->dev_data;

    /* Set VPI */
    if (part[1] != -1 && (uint) part[1] < dev_data->num_vpis)
    {
        *vpi = part[1];
    }
    else
    {
        printk("Error: VPI out of range\n");
        return -1; /* VPI out of range */
    }
    
    /* Set VCI */
    if (part[2] == -1 || (uint) part[2] < dev_data->num_vcis_per_vpi)
    {
        *vci = part[2];
    }
    else
    {
        printk("Error: VCI out of range\n");
        return -1; /* VCI out of range */
    }

    // Success
    return 0;
}

/* PEM - stub for now... */
struct atm_dev * port2dev(short part)
{
  return NULL;
}

/*
#########################################################
#
#  Function : switch_read
#             
#  Purpose  : Outputs a list of switched VCs currently 
#             configured
#             User interface is "cat /proc/atm/switch"
#  Args     : As per the Linux proc_read standard
#             
#  Returns  : number bytes written to buf
#             
#  Notes    : Currently assumes all output can fit into one page.
#             Registered with /proc file system by switch_init().
##########################################################
#  Edit history:
#  Who     When    What
#  AJZ     23Aug01 Created
##########################################################
*/
static int  switch_read(char *buf, char **start, off_t offset, int count, int *eof, void *data)
{
    int len = 0;
    sw_pvc_t *ptr = alloc_list;
    
    len += switch_list_print_header(buf);
    while (ptr != NULL)
    {
        len += switch_list_print_entry(buf,len,ptr);
        ptr = ptr->next;
    }

    *eof = 1;

    return len;
}

static int switch_list_print_header(char *buf)
{
    return sprintf(buf,
                   "%-16s%-16s%-10s%-10s%-10s\n"
                   "==============================================================\n",
                   "iport.ivpi.ivci", "oport.ovpi.ovci", "pcr","[ubr|cbr]","rx");
}

/* PEM - stub for now... */
int mpc8260sar_ptp_get_stats(sw_pvc_t * entry, int * prx)
{
    return 0;
}

static int switch_list_print_entry(char *buf, int off, sw_pvc_t *entry)
{
    int len = 0;
    char str[32+1];
    int rx;

    sprintf(str,  "%d.%d.%d", entry->iport, entry->ivpi, entry->ivci);
    len += sprintf(&(buf[off+len]), "%-16s", str);
    
    sprintf(str,  "%d.%d.%d", entry->oport, entry->ovpi, entry->ovci);
    len += sprintf(&(buf[off+len]), "%-16s", str);

    len += sprintf(&(buf[off+len]), "%-10d", entry->pcr);

    len += sprintf(&(buf[off+len]), "%-10s", (entry->traffic_class == ATM_UBR) ? "ubr" : "cbr");

    /* PEM - changed */
    if(mpc8260sar_ptp_get_stats(entry, &rx))
        len += sprintf(&(buf[off+len]), "error\n");
    else
        len += sprintf(&(buf[off+len]), "%-10d\n", rx);

    return len;
}

/*
#########################################################
#
#  Function : switch_init
#             
#  Purpose  : Initialises Port to Port switching
#             
#  Returns  : 0 for success
#             
#  Notes    : Interface (add/del/list) will be via
#             the /proc file system
#             
##########################################################
#  Edit history:
#  Who     When    What
#  AJZ     20Aug01 Created
##########################################################
*/
int switch_init(void)
{
    int i;
	struct proc_dir_entry *entry;

    DINIT_PRINTK(__FUNCTION__ "\n");

    // Initialise the free list/ allocated list

    // Clear the array of sw_pvc_t structs
    memset(sw_pvcs, 0, sizeof(sw_pvcs));

    // Initialise the lists of pointers to sw_pvc_t
    for (i = 0; i < MAX_SWITCHED_PVCS; i++)
        list_put(&free_list, &sw_pvcs[i]);


    // Create a file /proc/atm/switch which provides the 
    // interface to the switching fabric
	entry = create_proc_entry("switch", 0600, atm_proc_root);

	entry->nlink = 1;
	entry->read_proc = switch_read;
	entry->write_proc = switch_write;

    return 0;
}

/*
#########################################################
#
#  Function : switch_release
#             
#  Purpose  : Releases kernel resources
#             
#  Returns  : 0 for success
#             
##########################################################
#  Edit history:
#  Who     When    What
#  AJZ     19Nov01 Created
##########################################################
*/
int switch_release(void)
{
    // Sanity check
    if (list_get(&alloc_list))
    {
        printk(KERN_ERR " " __FUNCTION__ " Switched PVCs still allocated!\n");
        return -1;
    }

    // Remove /proc/.../switch
    remove_proc_entry("switch", atm_proc_root);
    
    // All okay
    return 0;
}

/*
#####################################################################
#
# (C) Copyright 2002
# Peter McCormick, pete261@yahoo.com
# Eastern Research Inc., http://www.erinc.com
# ported from mpc860sar project, http://mpc860sar.sourceforge.net
#
# (C) Copyright 2001
# David Pegler, Cambridge Broadband Ltd, dwp@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
######################################################################
#
*/

#ifndef MPC8260SAR_H
#define MPC8260SAR_H

/*############ includes ####################*/

#include <linux/atm.h>
#include <linux/atmdev.h>
#include <linux/sonet.h>
#include <linux/skbuff.h>
#include <linux/time.h>
#include <linux/config.h>
#include <linux/spinlock.h>
#include "intpool.h"
#include "mpool.h"
#include "errata.h"
#include "utopia.h"
#include "serial.h"
#include "cpm.h"

/*############# defines #####################*/

#define KHz(_k) (_k * 1000)
#define MHz(_x) KHz(KHz(_x))
#define Mbs(_y) MHz(_y)
#define Kbs(_k) KHz(_k)

#define BOOL int
#define FALSE (0)
#define TRUE (!FALSE)

/* Default AAL5 Maximum Transmission Unit (and length of AAL5 buffers) */
#define AAL5_MTU (1510+8)
#define AAL5_BUFLEN (((AAL5_MTU + 47)/48)*48) /* Round up to n*48 bytes */

#define AAL5_CRC32_MASK	(0xDEBB20E3) /* CRC-32 Mask */
#define NUM_INT_CONN_TABLES	(64)	 /* Max 32 internal connection tables */
#define APC_MI	8                    /* Max Iterations (see APC section of MPC8260 ESAR supplement */

/* AJZ Oct 19 2001:
 * The MAX_CHANNEL_BITRATE is used to calculate
 * the APC_SLOT_TIME_US (below).
 * Since only one cell can be scheduled per VC,
 * per APC tick, to acheive a higher
 * MAX_CHANNEL_BITRATE, you need a shorter
 * APC_SLOT_TIME_US.  In turn, this increases
 * loading on the CPM.
 */
#define MAX_CHANNEL_BITRATE Mbs(20)

#define MAX_CHANNEL_PCR (MAX_CHANNEL_BITRATE/(53*8))

/* The period of timer4, which triggers the APC of each device.
 * too large -> causes large NCITS on each device -> causes large CDV
 * too small -> causes heavy CPM loading
 */
#define APC_SLOT_TIME_US (1000000/MAX_CHANNEL_PCR)

#define MAX_APC_LEVELS 2 /* one for CBR; one for UBR */

/* PEM - added */
#define RATE_MODE_EXTERNAL 0
#define RATE_MODE_INTERNAL 1

/*############## types ######################*/

typedef enum _cpm_if_ctrl { CPM_CHAN_ENABLE, CPM_CHAN_DISABLE, CPM_CHAN_ATM_TX } CPM_CHAN_CTRL;

/**********************************************
 * The following struct is used by            *
 * 1)     The Raw Cell Queue                  *
 * 2)     Terminated (Rx, Tx, or Bi) Channels *
 **********************************************/
typedef struct
{
    /******************************
     * Stuff used by all channels *
     ******************************/
    struct atm_dev         *dev;        /* Points back at device */
    volatile tx_conn_table_t  *tctptr;      /* Absolute address */
    volatile rx_conn_table_t  *rctptr;      /* Absolute address */
    int		            number;     /* Channel ID used by CPM */
    unchar                  aal;        /* ATM_AAL0 or ATM_AAL5 */
    unchar        traffic_class;      /* UBR, ABR, CBR, NONE, ANYCLASS */
    /********************************************************
     * Stuff used by all channels except the Raw Cell Queue *
     ********************************************************/
    struct atm_vcc *vcc;                /* Ptr to socket layer per VC info */
    unchar		  vpi;                  /* VPI in use */
    ushort		  vci;                  /* VCI in use */
        
    /********************************************
     * Stuff used by rx and bidir channels only *
     ********************************************/
    volatile atm_rx_cbd_t*	  rbase;        /* Start of this channel's RX Buf Desc */
    int                   rx_ring_size; /* Num rx BDs and skbuffs for this channel */
    struct sk_buff**      rx_skbuff;    /* points to rx_ring_size sk_buff ptrs */
    int			          rx_tail;      /* read next from rbase[rx_tail] */

    /********************************************
     * Stuff used by tx and bidir channels only *
     ********************************************/
    volatile atm_tx_cbd_t*	  tbase;        /* Start of this channel's TX Buf Desc */
    int                   tx_ring_size; /* Num tx BDs and skbuffs for this channel */
    struct sk_buff**      tx_skbuff;    /* points to tx_ring_size sk_buff ptrs */

    /* Volatile because shared between mpc8260sar_send() and mpc8260sar_tx_bh() */
    volatile int          tx_head;      /* write next to tbase[tx_head] */
    volatile int          tx_tail;      /* all unhandled sent BDs are between tbase[tx_tail] and tbase[tx_head] */

    int                   tbusy;        /* State information for tx channels */
    int                   trans_start;  /* time in jiffies of last send to CPM */

    /***********************************************
     * Stuff used by CBR tx or bidir channels only *
     ***********************************************/
    ulong			      tx_byte_rate; /* Requested Transmission data rate (CBR only) */


    /***********************************************
     * Stuff used by UBR tx or bidir channels only *
     ***********************************************/
#ifdef ACT_BUG /* see errata.h for details */
    int                   dis;           /* Tells mpc8260sar_send() if this channel is disabled in CPM */
#endif

    unchar udc[12];
} cpm_channel_t;

/**********************************
 * The following struct keeps     *
 * count of the number of recv    *
 * errors                         *
 **********************************/
typedef struct
{
    unsigned int unknown_ci;
    unsigned int bad_hec;
    unsigned int aal5_abt;
    unsigned int aal5_bad_len;
    unsigned int bad_crc32;
    unsigned int bad_crc10;
    unsigned int clp_set;
    unsigned int charge_failed;
    unsigned int skb_dropped;
    unsigned int large_skb_missed_last;
    unsigned int large_skb_missed_first;
    unsigned int large_skb_missed_mid;
    unsigned int large_skb_too_big;
    unsigned int large_skb_bad_sz;
    unsigned int large_skb_charge_failed;
    unsigned int large_skb_drop;
    unsigned int bsy;
    unsigned int intr_q_ov;
} rx_errors_t ;

#define UTOPIA_MPHY_PRIORITY_ROUND_ROBIN 0
#define UTOPIA_MPHY_PRIORITY_FIXED       1
#define UTOPIA_MPHY_POLLING_MUX          0
#define UTOPIA_MPHY_POLLING_DIRECT       1
 
/* configuration parameters related to utopia */
typedef struct
{
    BOOL master;             /* or slave */
    int last_phy;            /* highest numbered valid phy address
                               0 implies single phy, in slave mode 
			       this is our phy address */
    int mphy_priority;       /* multiple phy only */
    int mphy_polling;        /* multiple phy only */
    int bus_size;            /* 8 or 16 bits */ 
} utopia_t;

/***********************************
 * The following struct is used to *
 * hold per device data and is     *
 * pointed to by dev->dev_data     *
 ***********************************/
typedef struct
{
    /**************************************************
     * Stuff initialised by mpc8260sar_init_dev_data() *
     **************************************************/

    intpool_t channel_tracker;      /* keeps track of which chanids are in use - see defn of intpool_t */
    int max_channels;               /* size of channels[] */
    cpm_channel_t *channels;        /* each channels[i] describes a cpm channel and is pointed to by vcc->dev_data */

    volatile atm_tx_cbd_t*	tbdbase;    /* Points to an array of UTOPIA_NUM_TX_BDS TX Buf Descrs */
    volatile atm_rx_cbd_t*	rbdbase;    /* Points to an array of UTOPIA_NUM_RX_BDS RX Buf Descrs */

    mpool_t tx_bd_pool;             /* Keeps track of which regions of tbdbase[] are free */
    mpool_t rx_bd_pool;             /* Keeps track of which regions of rbdbase[] are free */

    struct sk_buff**  tx_skbuff;    /* Points to an array of UTOPIA_NUM_TX_BDS sk_buff ptrs*/
    struct sk_buff**  rx_skbuff;    /* Points to an array of UTOPIA_NUM_RX_BDS sk_buff ptrs*/

    mpool_t tx_skbuff_ptr_pool;     /* Keeps track of which regions of tx_skbuff[] are free */
    mpool_t rx_skbuff_ptr_pool;     /* Keeps track of which regions of rx_skbuff[] are free */

#ifdef CONFIG_PTP_SWITCHING
    int ptp_tx_ring_size;           /* Num BDs in each PTP Tx ring */
#endif
    int rcq_rx_ring_size;           /* Num BDs in Raw Cell Queue Rx ring */
    int rx_ring_size;               /* Num BDs in Rx channel */
    int tx_ring_size;               /* Num BDs in Tx channel */

    unsigned long total_tx_byte_rate;/* Current total tx byte rate allocated to CBR channels */

    ulong apc_overflow[MAX_APC_LEVELS];/* Tracks the number of APC Overflow events */

    rx_errors_t rx_errors;          /* Tracks number of recv errors */

    ulong min_channel_byterate;     /* Configured minimum byte rate allowed for a channel on this ATM device */
    ulong max_channel_byterate;
    ulong phy_byterate;

    struct tq_struct bh_tq;         /* Bottom Half task queue element sheduled by interrupt hdlr in response to GINT */

    int fcc;			    /* 8260 uses FCCs for ATM, not SCCs */
    volatile fcc_t * im_fcc;        /* pointer to fcc data */
    int int_brg;                    /* internal rate clock */
    int fcc_brg;
    int rate_mode;		    /* internal or external */     
    uint num_vpis;                  /* max VPI + 1 */
  utopia_t utopia;                /* utopia-related data */     
    uint num_vcis_per_vpi;          /* max VCI + 1 */

    int num_apc_levels;             /* Number of APC levels (currently must be 1 or 2) */
    int num_of_priorities;
    /*********************************************
     * Stuff initialised by mpc8260sar_init_rcq() *
     *********************************************/

    cpm_channel_t rcq_chan;         /* Used by the raw cell queue */

    /**********************************************
     * Stuff initialised by mpc8260sar_init_pram() *
     **********************************************/    

    volatile tx_conn_table_t *tctbase;  /* Internal (DPRAM) connection table (chanids 0 to 31) */
    volatile rx_conn_table_t *rctbase; 
    volatile tx_conn_table_t *etctbase; /* External (DPRAM) connection table (chanids 0 to 31) */
    volatile rx_conn_table_t *erctbase;    

    volatile tx_conn_table_extension_t *tctebase;  /* Internal (DPRAM) TCTE tables (chanids 0 to 31) */
    volatile tx_conn_table_extension_t *etctebase; /* External memory TCTE tables (chanids >= 32) */

    ushort                 flmask;  /* Address Matching: first level mask for Address matching */
    volatile fl_ent_t     *flbase;  /* Address Matching: Addr of Address matching First Level base */
    volatile ulong        *slbase;  /* Address Matching: Addr of Address matching 2nd Level base */

    volatile sar8260_pram_t *sar_pram;  /* Address of parameter RAM corresponding to this device */

    volatile apc_param_t* apcptr;   /* APC Parameter Table pointer */
    volatile apc_prior_t* apc_pr_ptr; /* APC Priority Tables start pointer */

    volatile intq_pram_t  *intq_pram_ptr;

    interrupt_table_t *intbase[ATM_INT_QUEUES];        /* Interrupt Table base pointer, virtual address */
    volatile interrupt_table_t *intptr[ATM_INT_QUEUES];/* Interrupt Table current pointer, virtual address */
    volatile ushort t_status;
    volatile ushort t_chan;

    int dpalloc_base1;              /* return value from m8xx_cpm_dpalloc */
    int dpalloc_base2;              /* return value from m8xx_cpm_dpalloc */
    int dpalloc_base3;              /* return value from m8xx_cpm_dpalloc */
    int dpalloc_base4;              /* return value from m8xx_cpm_dpalloc */
    int dpalloc_base5;              /* return value from m8xx_cpm_dpalloc */
    int dpalloc_base6;              /* return value from m8xx_cpm_dpalloc */
    int dpalloc_base7;              /* return value from m8xx_cpm_dpalloc */
    int dpalloc_base8;              /* return value from m8xx_cpm_dpalloc */

    /*****************************************************
     * Stuff initialised by mpc8260sar_calculate_timing() *
     *****************************************************/    

    ulong number_of_slots;       
    ulong cells_per_slot;
    ulong line_rate_kbps;
    ulong min_vc_rate;
    ulong max_vc_rate;
    ulong peek_cell_rate;
    ulong peek_cell_rate_fraction; 

    /******************* ABR Protocol Specific Parameters *******************/

    ulong cells_per_slot_abr;
    ulong line_rate_abr;

    spinlock_t lock;

    volatile immap_t* immap;

  /* global ATM parameters */  
  int addr_lookup_local; /* address lookup bus: 0=60x bus, 1=local bus */
  int conn_tbl_local; /* ext conn tables bus: 0=60x bus, 1=local bus */
  int vp_tbl_ext; /* ext addr comp vp table: 0=dual-port RAM, 1=external RAM */
  int addr_lookup_comp; /* addr lookup: 0=external CAM, 1=address compression */

  int log2_max_channels;
  //int num_apc_levels;
  //int rcq_rx_ring_size;
  //int tx_ring_size;
  //uint num_vpis;
  //uint num_vcis_per_vpi;
  int num_rx_bds;
  int num_tx_bds;

  int loop_mode;

} dev_data_t;

/**************************************
 * Switched PVC type                  *
 **************************************/
typedef struct sw_pvc
{    
    /******************************************
     * Stuff initialised by switcher.c module *
     ******************************************/
    /* Next in list (either free list or allocated list) */
    struct sw_pvc *next;
    
    /* Input PORT/VPI/VCI */
    short       iport;
    short		ivpi;
	int 		ivci;  /* ATM_VCI_ANY implies PVP */

    /* Output PORT/VPI/VCI */
    short       oport;
    short		ovpi;
	int 		ovci;  /* ATM_VCI_ANY implies PVP */

    /* APC params */
    int pcr;
    unsigned char traffic_class;

    /*******************************************
     * Stuff initialised by mpc8260sar.c module *
     *******************************************/
    int       ichanid;
    int       ochanid;
    volatile atm_tx_cbd_t*	  tbase;
    unchar   *bufaddr;
    volatile tx_conn_table_t *itct;
    volatile tx_conn_table_t *otct;
    volatile rx_conn_table_t *irct;
    volatile rx_conn_table_t *orct;
    ulong tx_byte_rate; /* Requested Transmission data rate */
} sw_pvc_t;


/*#################### function prototypes ####################*/
int mpc8260sar_init_dev_data(dev_data_t *data);

int mpc8260sar_release_dev_data(dev_data_t *data);

int mpc8260sar_init_pram (struct atm_dev *dev,
                         int screen_oam,
                         int interrupt_table_size);
int mpc8260sar_release_pram (struct atm_dev *dev);

int mpc8260sar_init_rcq(struct atm_dev *dev);
void mpc8260sar_release_rcq(struct atm_dev *dev);

int mpc8260sar_init(void);
int mpc8260sar_release(void);

int mpc8260sar_start(void);
int mpc8260sar_stop(void);

#ifdef CONFIG_PTP_SWITCHING
int mpc8260sar_init_ptp_channel(sw_pvc_t *pvc);
int mpc8260sar_delete_ptp_channel(sw_pvc_t *pvc);
int mpc8260sar_ptp_get_stats(sw_pvc_t *pvc, int *rx);
#endif

struct atm_dev *port2dev(short port);
int mpc8260sar_calculate_timing(struct atm_dev *dev);

/*################### Global data ###############################*/
extern const struct atmdev_ops mpc8260sar_ops;



#endif

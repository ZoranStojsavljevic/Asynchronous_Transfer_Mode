/*
#######################################################################
#
# (C) Copyright 2001
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
# Notes:
# 
#######################################################################
*/

#ifndef __ATM_DEBUG_H__
#define __ATM_DEBUG_H__

//#define DEBUG_ALL
//#define DEBUG_OPENCLOSE
//#define DEBUG_XMIT
//#define DEBUG_RECV
//#define DEBUG_MM
//#define DEBUG_INIT
//#define DEBUG_INT
//#define DEBUG_LOW
//#define DEBUG_PRINT_ALL

#ifdef  DEBUG_ALL
#    define DEBUG_INIT
#    define DEBUG_RECV
#    define DEBUG_XMIT
#    define DEBUG_OPENCLOSE
#    define DEBUG_MM
#    define DEBUG_INT
#    define DEBUG_LOW
#endif

#ifdef  DEBUG_INIT
#    define DINIT_PRINTK(format,args...) printk(format,##args)
#else
#    define DINIT_PRINTK(format,args...)
#endif

#ifdef  DEBUG_MM
#    define DMM_PRINTK(format,args...) printk(format,##args)
#else
#    define DMM_PRINTK(format,args...)
#endif

#ifdef  DEBUG_RECV
#    define DRECV_PRINTK(format,args...) printk(format,##args)
#else
#    define DRECV_PRINTK(format,args...)
#endif

#ifdef  DEBUG_XMIT
#    define DXMIT_PRINTK(format,args...) printk(format,##args)
#else
#    define DXMIT_PRINTK(format,args...)
#endif

#ifdef  DEBUG_OPENCLOSE
#    define DOPENCLOSE_PRINTK(format,args...) printk(format,##args)
#else
#    define DOPENCLOSE_PRINTK(format,args...)
#endif

#ifdef  DEBUG_INT
#    define DINT_PRINTK(format,args...) printk(format,##args)
#else
#    define DINT_PRINTK(format,args...)
#endif

#ifdef  DEBUG_ALL
#    define DPRINTK(format,args...) printk(format,##args)
#else
#    define DPRINTK(format,args...)
#endif

#ifdef  DEBUG_LOW
#    define DLPRINTK(format,args...) printk(format,##args)
#else
#    define DLPRINTK(format,args...)
#endif

extern void report_error(char*,int);
#define RETURN_ON_ERROR(x) if((x)){report_error(__FUNCTION__,__LINE__); return -EINVAL;}

extern void print_table(ushort * p);
extern void print_tabled(uint * p, int num);
extern void debug_print(struct atm_dev *dev, int param);

#endif




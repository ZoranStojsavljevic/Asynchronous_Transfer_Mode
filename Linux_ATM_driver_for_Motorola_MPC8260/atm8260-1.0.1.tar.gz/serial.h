/*
#######################################################################
#
# (C) Copyright 2001
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
# Notes:
# This file declares functions and data specific to the serial devices
# (TDMa and TDMb)
# and required by mpc860sar_detect() for the initialisation of that
# device.
#
#
#######################################################################
*/

#ifndef __SERIAL_ATM__
#define __SERIAL_ATM__

/*################ Types ##############################*/
// The Time Division Multiplexer to configure
typedef enum 
{
    TDMa,
    TDMb
} tdm_e;

/*################ Function prototypes ################*/

int serial_init(struct atm_dev *dev, tdm_e tdm);
int serial_release(struct atm_dev *dev);
void serial_disable_interrupts(tdm_e tdm);
void serial_enable_interrupts(struct atm_dev *dev);

/*################ Global data ########################*/

extern struct atm_dev *serial_tdma_dev;
extern struct atm_dev *serial_tdmb_dev;

/*################ Defines ############################*/
#define SERIAL_TDMA_DEV_LABEL	"tdma"
#define SERIAL_TDMB_DEV_LABEL	"tdmb"

#endif // __SERIAL_ATM__

/*
#######################################################################
#
# (C) Copyright 2002
# Peter McCormick, pete261@yahoo.com
# Eastern Research Inc., http://www.erinc.com
# ported from mpc860sar project, http://mpc860sar.sourceforge.net
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
*/

#include <linux/config.h>
#include <linux/delay.h>
#include <linux/init.h>
#include <linux/kernel.h>

/* PEM - added - need to locate BCSR registers */
#ifdef CONFIG_ATM_VADS
#include <asm/mpc8260ads.h>		/* PEM - -ppc should be removed */
#else
#include <asm/est8260.h>
typedef struct bcsr
{
    unsigned int  bcsr0; /* Board Control and Status Register */
    unsigned int  bcsr1;
    unsigned int  bcsr2;
    unsigned int  bcsr3;
} bcsr_t;
#endif

int start_vads_phy(void)
{
  /* PEM - changed */  
#ifdef CONFIG_ATM_VADS
  volatile bcsr_t* bcsr = (bcsr_t*)CFG_BCSR;
#else
  volatile bcsr_t* bcsr = (bcsr_t*)0xFA100000; 
#endif
  unsigned char *ptr;
  int i;
 
  /* PEM - moved */
  /* ptr = (unsigned char *) 0x80000000; */

  bcsr->bcsr1 &= ~0x10000000; 
 
  for(i = 0; i < 0x100; i++);

  bcsr->bcsr1 |= 0x10000000;
  bcsr->bcsr1 &= ~0x20000000;

  printk(KERN_INFO "Found ATM physical SUNI PM5350\n");

/* PEM - what was the following trying to do?  registers 0x32 and 0x35 don't even exist on the PM5350! */
#ifndef CONFIG_ATM_VADS
  ptr = (unsigned char *) 0x80000000;
  //*(ptr + 5) = 0x28;
  *(ptr + 50) = 0x84;
  *(ptr + 53) = 0xff;
#endif
  
  return 0;
}

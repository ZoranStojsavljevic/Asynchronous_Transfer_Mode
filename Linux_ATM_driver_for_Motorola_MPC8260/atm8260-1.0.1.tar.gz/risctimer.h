/*
#
# (C) Copyright 2001
#  David Pegler, Cambridge Broadband Ltd, dwp@cambridgebroadband.com
#  Daris Nevil,  Simple Network Magic Corporation dnevil@snmc.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#
*/

#ifndef __RISC_TIMER_H__
#define __RISC_TIMER_H__

#ifdef __KERNEL__

#include <linux/types.h>
#include <linux/kernel.h>


#define RISC_TIMER_MAX	(16)	// CP Supports 16 RISC Timers

#define RISC_TIMER_MAX_TIMEOUT (0xffff)

//-------------------------------------------------------------------
// Enumberated Types

// Timer type specified in risc_timer_set()
typedef enum {
	RT_ONE_SHOT = 1,
	RT_PERIODIC,
	RT_PWM
} RT_Type;


//-------------------------------------------------------------------
// Function Prototypes

typedef void (*Risc_Timer_Callout_t)(int timer_num);

int risc_timer_enable(uint timer_period);
int risc_timer_get_tick(uint* tick_period);
int risc_timer_disable(void);
int risc_timer_set(int timer_num, ulong timeout, RT_Type type,
	Risc_Timer_Callout_t callout, char* user_name);
int risc_timer_get_addr(int timer_num, uint* timer_addr);
int risc_timer_stop(int timer_num);


#endif // __KERNEL__


#endif // __RISC_TIMER_H__



#include <linux/module.h>
#include <linux/config.h>
#include <linux/kernel.h>
#include <linux/vmalloc.h>      /* for vmalloc */
#include <linux/mm.h>
#include <linux/pci.h>
#include <linux/errno.h>
#include <linux/atm.h>
#include <linux/atmdev.h>
#include <linux/sonet.h>
#include <linux/skbuff.h>
#include <linux/time.h>
#include <linux/timex.h>
#include <linux/sched.h>        /* for xtime */
#include <linux/delay.h>
#include <linux/uio.h>
#include <linux/init.h>
#include <asm/system.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include <asm/string.h>
#include <asm/byteorder.h>

#include <linux/netdevice.h>
#include <linux/ioport.h>
#include <linux/atm.h>

#include <asm/mpc8260.h>
#include <asm/immap_8260.h>
#include <asm/cpm_8260.h>
#include "mpc8260sar.h"
#include "mpool.h"
#include "intpool.h"
#include "cpmtimer.h"
#include "mm.h"
#include "risctimer.h"
#include "debug.h"
#include "errata.h"

#if 0
#define MPC8260_IOPORTS 4
#define MPC8260_IOPORT_PINS 32

struct ioport_pin_t[MPC8260_IOPORTS][MPC8260_IOPORT_PINS];


/* configure a single ioport pin */
int mpc8260_ioport_cfg(uint port, uint pin, uint ppar, uint psor, uint pdir)
{
    struct ioport_pin_t * piop;
    volatile immap_t* immap = (immap_t*)IMAP_ADDR;
    u32 mask;
    volatile u32 * p;
    
    if(port > MPC8260_IOPORTS){
	printk(KERN_ERR "ioport %c invalid\n", 'a'+port);
        return -EINVAL;
    }

    if(pin > MPC8260_IOPORT_PINS){
        printk(KERN_ERR "ioport %c pin %d invalid\n", 'a'+port, pin);
        return -EINVAL;
    }

    piop = &ioport_pin_t[port][pin];
    if(piop->configured){
        printk(KERN_ERR "ioport %c pin %d is already in use\n", 'a'+port,pin);
	return -EINVAL;
    }
    
    piop->configured = TRUE;            /* mark pin as in-use */
    piop->ppar = ppar;                  /* remember values for possible future verification */
    piop->psor = psor;
    piop->pdir = pdir;
    
    /* configure the hardware */
    p = &immap->im_ioport.iop_pdira;
    p += port*8;
    mask = 0x80000000 >> pin;

    /* the following must be done in the order: pdir, ppar, psor, podr, pdat
     * this is how the registers are in memory on the 8260 */
    if(pdir){
        *p++ |= mask;
    }
    else{
        *p++ &= ~mask;
    }			                
    if(ppar){
        *p++ |= mask;
    }	    
    else{
        *p++ &= ~mask;
    }
    if(psor){
        *p++ |= mask;
    }
    else{
        *p++ &= ~mask;
    }
}

/* mark a single ioport pin as available for use */
int mpc8260_ioport_free(uint port, uint pin)
{
    struct ioport_pin_t * piop;
    volatile immap_t* immap = (immap_t*)IMAP_ADDR;
    u32 mask;
		        
    if(port > MPC8260_IOPORTS){
	printk(KERN_ERR "ioport %c invalid\n", 'a'+port);
	return -EINVAL;
    }

    if(pin > MPC8260_IOPORT_PINS){
        printk(KERN_ERR "ioport %c pin %d invalid\n", 'a'+port, pin);
        return -EINVAL;
    }

    piop = &ioport_pin_t[port][pin];
    piop->configured = FALSE;            /* mark pin as available */
}
#endif

/* PEM - avoid waiting forever for CPM commands to complete */
void mpc8260_cmd_wait(char *func, int line)
{
    volatile cpm8260_t *cp = cpmp;
    volatile int i;

    for (i = 0; i < 10000000; i++) {
	if (!(cp->cp_cpcr & CPM_CR_FLG)) {
	    return;
	}
    }

    printk(KERN_ERR
	   "mpc8260_cmd_wait: function=%s line=%d: timeout waiting for command completion!\n",
	   func, line);
}

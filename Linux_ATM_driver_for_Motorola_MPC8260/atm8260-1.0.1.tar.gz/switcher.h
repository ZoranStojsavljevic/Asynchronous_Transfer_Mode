/*
#######################################################################
#
# (C) Copyright 2001
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
# Notes:
# This file contains function definitions and data applicable to the
# ATM switching fabric
#
# The interface to the switching fabric is via the /proc file system.
# User code will be able to add and delete switched VCs by writing
# to a file in /proc, and monitor the status of open switched VCs by
# reading a file in /proc.
# 
#######################################################################
*/

#ifndef __SWITCHER_H__
#define __SWITCHER_H__


/*################ Function prototypes #####################*/
extern int switch_init(void);
extern int switch_release(void);


#endif // __SWITCHER_H__

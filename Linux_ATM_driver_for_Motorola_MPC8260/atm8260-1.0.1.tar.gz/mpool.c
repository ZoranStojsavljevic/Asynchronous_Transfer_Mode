/*
#######################################################################
#
# (C) Copyright 2001
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
# Notes:
# This file implements the mpool_t object.
#
# Usage:
# ======
#
# The mpool_t object allows the client code to specify a region of
# memory.  The client code will then be able to allocate memory from that
# region.  Once it has been allocated the memory, the client will then
# be able to free it.
#
# The mpool_t object has the following public methods:
#
#  void mpool_init(mpool_t *mt, unsigned char *buf, int sz);
#  unsigned char* mpool_alloc(mpool_t *mt, int sz);
#  void mpool_free(mpool_t *mt, unsigned char * addr, int sz);
#  void mpool_destroy(mpool_t *mt)
# ... and no public data.
#
# Properties:
# ===========
# 
# The mpool_t object actually allocates blocks of the following
# sizes, in bytes:
#       64 128 256 512 1K ... MAX_BLOCK
#
# It is therefore most efficient if the client tries to allocate one of
# these sizes, and not something in between.
#
# The mpool object will only ever use the first 4096K of the memory
# range passed to mpool_init().
#
# mpool_alloc() will fail if 2^^n  consecutive bytes are
# not available, where n is the least integer with 2^^n >= sz.
# mpool_alloc() will *always* succeed if there are 2^^n consecutive
# bytes available which are aligned on a 2^^n byte boundary.
# This remains true even if the block in question is composed of 
# smaller blocks which have previously been freed.
#
# Important: the mpool_t object reserves all memory not currently
# allocated for internal use.
#
# Implementation:
# ===============
#
# On initialisation mpool_t sorts the memory into the following
# groups:
#
#    MAX_BLOCK byte aligned blocks of MAX_BLOCK bytes
#       ...
#       ...
#    128 byte aligned blocks of 128 Gbytes
#    64 byte aligned blocks of 64 bytes
#
# By seeking blocks in the order specified above the object ensures
# that the memory is segmented into the fewest number of blocks possible.
#
# when the client code calls mpool_alloc(), the groups are searched
# in the following order:
#
#    2^^n      byte blocks,
#    2^^(n+1)  byte blocks,
#    etc.,
#
# where n is the least int with 2^^n >= sz.
# When a block is found mpool_alloc() gives the first 2^^n bytes
# to the caller, and returns the rest to the free lists.  Note that,
# if the block found is larger than that needed, the remainder will
# be split into blocks of 2^^n, 2^^(n+1), etc. before being returned
# to the free lists.
#
# mpool_free() searches the list of free 2^^n byte blocks for a
# block that could be combined with the block being freed to make a
# 2^^(n+1) byte block.  If one is found it is removed and mpool_free()
# is invoked with the larger block; if one is not found the block is
# simply added to the list of free 2^^n byte blocks
#
# The lists are 16-ary trees.
# Each list consists of a pointer to a block.  the 1st 64 bytes of that
# block consists of 16 pointers to other blocks, and so on.  a NULL
# pointer indicates a terminated branch.  A block with 16 NULL pointers
# is a leaf block.
#
# The 2^^n tree is searched for an address in the following way:
# o   Get the match pattern: match = addr>>(n+1);
#     (if a block found has an address whose top bits match this then
#     it must be the block in question or the other half of a 2^^(n+1)
#     byte block)
#
# o   Get the first level block (if it exists)
# o   Get the first level index: idx = match & 0xf;
# o   Get the 2nd level block: block = block[idx];
# o   Get the 2nd level index: idx = (match >>= 4) & 0xf
# 
# and so on.
# This system guarantees a maximum of 8 levels.
#
# mpool_destroy() doesn't have to do anything because it is the
# client code's responsibility to allocate the original (complete) block
# of memory, and to free it.
#
# Possible improvements:
# ======================
#
# Low cache impact version:
# 
# This version reduces the impact on the cache by allocating to callers 
# the most recently freed blocks.  It has one drawback, which is that 
# instead of having a minimum block size of 64B, it has a minimum
# blocksize of 128B.
# 
# The free blocks are arranged in 16-ary trees in exactly the same way as
# before (one tree per block size from 128 bytes up to MAX_BLOCK bytes.)
# As before, you use the first 64 bytes of each block as pointers to the next
# level of blocks in the tree.  As before you use
# 
#     blockaddr&(0xf<<(order(blocksz)+1))
# 
# as the index of the first branch, and
# 
#     blockaddr&(0xf<<(order(blocksz)+1+4))
# 
# as the index of the 2nd branch, and so on.
# 
# What's new is that as well as having a pointer to a tree of free blocks for
# each blocksize, you have a pointer to a linked list of free blocks.  Each
# free block uses bytes 64-67 as a "next" pointer.  When you free a block you
# place it in the tree in exactly the same way as before, but then you also
# stick it at the head of the free list.  When you allocate a block from a
# tree, instead of taking the block at the top of the tree you simply pop a
# block off the head of the free list.
# 
# The upshot of this modification is that alloc will (usually) return the most
# recently freed block of the required size.  This minimises the impact
# on the cache.
# 
#######################################################################
*/


/*############# Includes ##########################*/
#include "mpool.h"

//#define TEST_HARNESS
#ifdef TEST_HARNESS
#    include "stdio.h"
#    define OUTPUT(format,args...) printf(format,##args)
#else
#    include <linux/kernel.h>
#    include <string.h>
#    define OUTPUT(format,args...) printk(KERN_INFO format,##args)
#endif


/*############# Private mpool_t methods  ##############*/

static inline int get_table_index(unsigned int sz)
{
    int idx = 0;
    while ((64<<idx) < sz)
        idx++;
    
	return idx;
}

static inline int roundup(unsigned int sz)
{
    int ret = 64;
    while (ret < sz)
        ret <<= 1;
    
	return ret;
}

#ifdef TEST_HARNESS
static void dump_branch(unsigned char *block)
{
    int i;
    unsigned char **addr = (unsigned char **)block;
    OUTPUT("%p %p %p %p %p %p %p %p %p %p %p %p %p %p %p %p\n\n",
           addr[0],
           addr[1],
           addr[2],
           addr[3],
           addr[4],
           addr[5],
           addr[6],
           addr[7],
           addr[8],
           addr[9],
           addr[10],
           addr[11],
           addr[12],
           addr[13],
           addr[14],
           addr[15]
           );
    for (i = 0; i < 16; i++)
    {
        if (addr[i])
        {
            OUTPUT("%p:\n", addr[i]);
            dump_branch(addr[i]);
        }
    }
}

static void dump_tree(mpool_t *mp)
{
    int i;
    for (i = 0; i < NUM_LISTS; i++)
    {
        OUTPUT("%p ", mp->freeblocks[i]);
    }
    OUTPUT("\n");
    
    for (i = 0; i < NUM_LISTS; i++)
    {
        if (mp->freeblocks[i])
        {
            OUTPUT("%p:\n", mp->freeblocks[i]);
            dump_branch(mp->freeblocks[i]);
        }
    }
}
#endif

// block = address of block to remove
// pblock = address of pointer to block in tree
static void remove_block(unsigned char *block, unsigned char **pblock)
{
    unsigned char *leaf = block;
    unsigned char **pleaf = pblock;

    // Remove a leafnode from this tree
    for (;;)
    {
        int i;
        for (i = 0; i < 16; i++)
        {
            if (((unsigned char **)leaf)[i])
                break;
        }

        if (i == 16)
        {
            // leaf is a leafnode - so remove it
            *pleaf = (unsigned char *)0;
            break;
        }
        else
        {
            // block is not a leafnode
            // get one of the branches
            pleaf = &((unsigned char **)leaf)[i];
            leaf = *pleaf;
        }
    }
    
    // Move leaf into block's current position
    // in tree (unless leaf == block, in which case
    // we only need to remove the block!)
    if (leaf != block)
    {
        memcpy(leaf, block, 16*sizeof(unsigned char *));
        *pblock = leaf;
    }
}

// This differs from mpool_free() because the free list for
// the largest block size can only ever have 1 block in it.
// Therefore we don't need to do anything complicated to free to this list.
// Note that we seek free block in exactly the same way as with the other
// lists and so it's important that if there is a block in the list
// it points to 16 NULLs
static void free_largest_block(mpool_t *mp, unsigned char *addr, int sz)
{
    mp->freeblocks[NUM_LISTS - 1] = addr;
    memset(addr, 0, 16 * sizeof(unsigned char *));
}

/*###################### Public mpool_t methods ##################*/

void mpool_free(mpool_t *mp, unsigned char *addr, int sz)
{
    int idx;
    unsigned char *block;
    unsigned char **pblock;
    unsigned int match;
    unsigned int cmatch; //copy of match

    // Note: This function is recursive!!!
    
    // Check sz is not too big
    if (((unsigned int)sz) > MAX_BLOCK)
    {
        OUTPUT(__FUNCTION__ " Error: sz too big\n");
        return;
    }

    // Round up sz to 64B, 128B, ....
    sz = roundup(sz);

    // Get index of tree to which to free block
    idx = get_table_index(sz);

    // We free 4MB blocks in a different manner
    if (idx == NUM_LISTS - 1)
    {
        free_largest_block(mp, addr, sz);
        return;
    }

    // Look for a block in this tree which 
    // could be combined with this one to 
    // create a bigger block.
    // But just add to this tree if we can't
    // find it.
    pblock = &(mp->freeblocks[idx]); // pointer to where we found current block's address
    block = *pblock;                 // the current block

    // If there is no first block then add a leaf node at top of tree
    if (!block)
    {
        *pblock = addr;
        memset (addr, 0, 16 * sizeof(unsigned char *));
        return;
    }

    // find match such that if (block >> (idx + 6 + 1) == match) then block together
    // with addr form a larger block which can then be freed
    match = (unsigned long) addr >> (idx + 6 + 1);
    cmatch = match;                                  // copy of match
    
    for (;;)
    {        
        unsigned int i;

        // We've got a new block - does it match?
        if (((unsigned long) block >> (idx + 6 + 1)) == match)
        {
            // Remove the block from the tree
            remove_block(block, pblock);

            // free the pair of blocks
            mpool_free(mp, (unsigned char *)((unsigned long) addr & ~sz), sz << 1);
            
            return;
        }

        // Get ptr to next block along our path
        i = cmatch & 0xf;
        cmatch >>= 4;
        pblock = &((unsigned char **)block)[i];
        block = *pblock;

        // if there is no entry then we can add a leaf node
        if (!block)
        {
            *pblock = addr;
            memset(addr, 0, 16 * sizeof(unsigned char *));
            return;
        }
    }
}

void mpool_init(mpool_t *mp, unsigned char *addr, int sz)
{
    int i;
    int waste;

    // Truncate sz to 4M
    sz = (sz > MAX_BLOCK) ? MAX_BLOCK : sz;

    // Clear the free block lists
    memset(mp->freeblocks, 0, sizeof(mp->freeblocks));

    // Round up addr to 64 bytes
    waste = (((unsigned long) addr + 63) & ~63) - (unsigned long) addr;
    addr += waste;
    sz -= waste;

    // Free the blocks to make them available for allocation later
    for (i = 64; i <= sz; i <<= 1)
    {
        if ((unsigned long) addr & i)
        {
            mpool_free(mp, addr, i);
            addr += i;
            sz -= i;
        }
    }

    i >>= 1;

    for (; i >= 64; i >>=1)
    {
        if (sz >= i)
        {
            mpool_free(mp, addr, i);
            addr += i;
            sz -= i;
        }
    }

    // keep track of wasted bytes
    waste += sz;

    // @ TODO do we want the caller to know how much is wasted?
    // @ TODO this will be at most 63*2 bytes
    // return waste;
}

unsigned char* mpool_alloc(mpool_t *mp, int sz)
{
    int idx;
    unsigned char *block;
    unsigned char **pblock;
    unsigned char *retval;
    unsigned char *free_addr;
    int free_sz;

    // Check sz is not too big
    if (((unsigned int)sz) > MAX_BLOCK)
    {
        OUTPUT(__FUNCTION__ " Error: sz too big\n");
        return (unsigned char *)0;
    }

    // Round up sz to 64B, 128B, ....
    sz = roundup(sz);

    // Find a block at least as big as sz
    for (idx = get_table_index(sz); idx < NUM_LISTS; idx++)
    {
        if (mp->freeblocks[idx])
        {
            break;
        }
    }
    
    // Did we succeed?
    if (idx == NUM_LISTS)
    {
        // No
        return (unsigned char *)0;
    }

    // remove first block from tree
    // (this updates the tree so save retval first!)
    block = mp->freeblocks[idx];
    pblock = &(mp->freeblocks[idx]);
    retval = block;

    remove_block(block, pblock);
 
    // Now release the parts of the block not needed
    free_sz = (64<<idx) - sz;        // The amount not required by caller
    free_addr = retval + sz;         // The start address of the memory not required
    
    for (; sz <= free_sz; sz <<= 1)
    {
        mpool_free(mp, free_addr, sz);
        free_addr += sz;
        free_sz -= sz;
    }
    
    return retval;
}

// destroy the object
void mpool_destroy(mpool_t *mp)
{
    // Nothing to do as it is the callers responsibility to allocate
    // and free the complete block
    return;
}

#ifdef TEST_HARNESS

int main (void)
{
    unsigned char *addrs64[4];
    unsigned char *addrs256[16];
    
    mpool_t mp;
    unsigned char *mem = (unsigned char *) malloc(4096+4095);
    unsigned char *start = (unsigned char *)(((unsigned long)mem + 4095) & ~4095);

    int i;

    OUTPUT("mem=%p\nstart=%p\n", mem, start);

    mpool_init(&mp, start, 4096);

    // allocate 256 bytes in 4 64 byte blocks (should succeed)
    for (i = 0; i < 4; i++)
    {
        addrs64[i] = mpool_alloc(&mp, 64);
        if (addrs64[i])
        {
            OUTPUT("allocated: addr=%p bytes=64\n", addrs64[i]);
        }
        else
        {
            OUTPUT("failed to allocate 64 bytes\n");
            break;
        }
    }
    if (i != 4)
    {
        OUTPUT("test failed\n");
        exit(1);
    }

    // allocate 4K in 256 byte blocks (last one should fail)
    for (i = 0; i < 16; i++)
    {
        addrs256[i] = mpool_alloc(&mp, 256);
        if (addrs256[i])
        {
            OUTPUT("allocated: addr=%p bytes=256\n", addrs256[i]);
        }
        else
        {
            OUTPUT("failed to allocate 256 bytes\n");
            break;
        }
    }
    if (i != 15)
    {
        OUTPUT("test failed\n");
        exit(1);
    }

    // free the 4 64 byte blocks
    for (i = 0; i < 4; i++)
    {
        mpool_free(&mp, addrs64[i], 64);
        OUTPUT("freed: addr=%p bytes=64\n", addrs64[i]);

        // Let's see what it's doing here
        if (i == 2)
        {
            dump_tree(&mp);
        }
    }

    // allocate another 256 block
    addrs256[15] = mpool_alloc(&mp, 256);
    if (addrs256[15] != NULL)
    {
        OUTPUT("allocated: addr=%p bytes=256\n", addrs256[15]);
    }
    else
    {
        OUTPUT("failed to allocate 256 bytes\n");
        OUTPUT("test failed\n");
        exit(1);
    }

    // free the 16 256 byte blocks
    for (i = 0; i < 16; i += 2)
    {
        mpool_free(&mp, addrs256[i], 256);
        OUTPUT("freed: addr=%p bytes=256\n", addrs256[i]);
    } 

    // and what's it doing here
    dump_tree(&mp);

    // free the 16 256 byte blocks
    for (i = 1; i < 16; i += 2)
    {
        mpool_free(&mp, addrs256[i], 256);
        OUTPUT("freed: addr=%p bytes=256\n", addrs256[i]);
    } 

    // and what's it doing here
    dump_tree(&mp);

    mpool_destroy(&mp);    
    OUTPUT("mem=%p\nstart=%p\n", mem, start);

    OUTPUT("freeing mem\n");
    free(mem);

    OUTPUT("test passed\n");
    return 0;
}

#endif // TEST_HARNESS

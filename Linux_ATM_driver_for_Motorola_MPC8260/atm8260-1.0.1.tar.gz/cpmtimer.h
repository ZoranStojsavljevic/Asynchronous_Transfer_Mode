/*
#
# (C) Copyright 2001
#  David Pegler, Cambridge Broadband Ltd, dwp@cambridgebroadband.com
#  Daris Nevil,  Simple Network Magic Corporation dnevil@snmc.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#
*/

#ifndef __CPM_TIMER_H__
#define __CPM_TIMER_H__

#ifdef __KERNEL__

#include <linux/types.h>
#include <linux/kernel.h>


#define CPM_TIMER_MAX	(4)	// CPM contains 4 counters

//-------------------------------------------------------------------
// Enumberated Types

// Capture Edge types
typedef enum {
	CPMT_CE_DISABLE = 0x0,
	CPMT_CE_RISING = 0x1,
	CPMT_CE_FALLING = 0x2,
	CPMT_CE_ANY = 0x3
} CPMT_CE_Type;

typedef enum {
	CPMT_ICLK_CASCADE = 0x0,
	CPMT_ICLK_SYS_CLK_1 = 0x1,
	CPMT_ICLK_SYS_CLK_16 = 0x2,
	CPMT_ICLK_TIN = 0x3
} CPMT_ICLK_Type;


//-------------------------------------------------------------------
// Function Prototypes

typedef void (*Cpm_Timer_Callout_t)(void* ter_addr);

int cpm_timer_create(
	int timer_num,	// Timer Number, 1-4
	int cascade,	// If true then cascade the timer
	int freeze,	// If true then stop the timer during FRZ state
	int rstgate,	// If true then enable restart gate mode
	int prescale,	// Prescale value, 0x00=div by 1, 0xff=div by 256
	CPMT_CE_Type ce,// Capture Edge type
	int toggle_tout,// If true then Toggle TOUTx
	int ref_interrupt, // If true then reference value causes interrupt
	int restart,	// If true then reference value causes timer reset
	CPMT_ICLK_Type iclk, // Input clock source
	int tgate1,	// If true then TGATE1 controls timer 1 or 2
	ulong trr	// Timer Reference Register
	);

int cpm_timer_delete(int timer_num);

int cpm_timer_start(int timer_num);
int cpm_timer_stop(int timer_num);

int cpm_timer_set_callback(int timer_num, Cpm_Timer_Callout_t callout);

int cpm_timer_set_tcr(int timer_num, ulong tcr);
int cpm_timer_get_tcr(int timer_num, ulong* tcr);

int cpm_timer_set_tcn(int timer_num, ulong tcn);
int cpm_timer_get_tcn(int timer_num, ulong* tcn);


#endif // __KERNEL__


#endif // __CPM_TIMER_H__



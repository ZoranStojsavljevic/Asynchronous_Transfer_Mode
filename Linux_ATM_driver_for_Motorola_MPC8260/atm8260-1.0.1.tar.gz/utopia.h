/*
#######################################################################
#
# (C) Copyright 2001
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
# Notes:
# This file declares functions and data specific to the utopia device
# and required by mpc8260sar_detect() for the initialisation of that
# device.
#######################################################################
*/

#ifndef __UTOPIA_H__
#define __UTOPIA_H__

/*################ Function prototypes ################*/

int utopia_init(struct atm_dev *dev);
int utopia_release(struct atm_dev *dev);
void utopia_disable_interrupts(void);
void utopia_enable_interrupts(struct atm_dev *dev);

/*################ Global data ########################*/

extern struct atm_dev *utopia_dev;

#define UTOPIA_DEV_LABEL	"utopia"

// Phy rates and (minimum) channel rates for the utopia device
#define UTOPIA_PHY_BITRATE           Mbs(155)
#define ATM_MIN_CHANNEL_BITRATE   Mbs(1)
  
#define UTOPIA_PHY_BYTERATE          (UTOPIA_PHY_BITRATE / 8)
#define ATM_MIN_CHANNEL_BYTERATE  (ATM_MIN_CHANNEL_BITRATE / 8)

// Total number of VPI/VCI channels for the UTOPIA device
#define UTOPIA_LOG2_MAX_CHANNELS (7)    /* 128 channels */
#define UTOPIA_MAX_CHANNELS	(1<<UTOPIA_LOG2_MAX_CHANNELS)  /* This is the max num bidir channels */
#define ATM_NUM_VPIS     1             /* Allowed VPI range is 0 to UTOPIA_NUM_VPIS-1 (must be power of 2)*/
#define UTOPIA_SCREEN_OAM   (FALSE)

/* Allowed VCI range is 0 to UTOPIA_NUM_VCIS_PER_VPI-1 (must be power of 2)*/
#define UTOPIA_LOG2_NUM_VCIS_PER_VPI 14
#define UTOPIA_NUM_VCIS_PER_VPI (1<<UTOPIA_LOG2_NUM_VCIS_PER_VPI)

// Number of entries in the interrupt queue 
#define UTOPIA_INTERRUPT_TABLE_SIZE	(512) 

// APC Constants
// If we have 1 level then we support only CBR, if we have >1 then 1=CBR, 2=UBR
#define UTOPIA_NUM_APC_LEVELS 2

/* Number of BDs in per-device per-APC-level Port To Port Tx ring */
#define UTOPIA_PTP_TX_RING_SIZE 64

/* Number of BDs in Raw Cell Queue Rx ring */
#define UTOPIA_RCQ_RX_RING_SIZE 8

/* Number of BDs in per-VC Rx and Tx ring */
#define UTOPIA_RX_RING_SIZE 8
#define UTOPIA_TX_RING_SIZE 8

// The number of buffer descriptors (shared between all channels on this device)
// Note: Rx BDs are used by all Rx channels and the Raw Cell Queue
// Note: Tx BDs are used by all Tx channels and by all PTP tx channels.  
// (There's one PTP tx channel per APC level)
#define ATM_NUM_RX_BDS ((UTOPIA_MAX_CHANNELS * UTOPIA_RX_RING_SIZE))
#define ATM_NUM_TX_BDS ((UTOPIA_MAX_CHANNELS * UTOPIA_TX_RING_SIZE))

/* PEM - these could be made driver parameters one day */
#define ATM_FCC             1
#define ATM_FCC_BRG         6
#define ATM_INT_BRG	    5
#define ATM_RATE_MODE       RATE_MODE_INTERNAL
#define UTOPIA_MASTER       1
#define UTOPIA_LAST_PHY     0
#define UTOPIA_BUS_MASTER   1
#define UTOPIA_BUS_SIZE     8
#define ATM_NUM_PRIORITIES  (UTOPIA_LAST_PHY+1)
#define ATM_VC_MIN_KBPS     1000
#define ATM_VC_MAX_KBPS     12500
#define LINE_RATE_KBPS      25000
#define ATM_INT_QUEUES      1
#define ATM_INT_CTES	    64		/* connection table entries */
#define ATM_LOOP_MODE       NORMAL_OPERATION

// hafe: stuff for Cello switching
#ifndef CONFIG_ATM8260_TX_UDC
#define ATM_TUDC            0
#define ATM_TEHS            0
#else
#define ATM_TUDC            1
#define ATM_TEHS            7
#endif

#ifndef CONFIG_ATM8260_RX_UDC
#define ATM_RUDC            0
#define ATM_REHS            0
#else
#define ATM_RUDC            0
#define ATM_REHS            0
#endif

#endif // __UTOPIA_H__

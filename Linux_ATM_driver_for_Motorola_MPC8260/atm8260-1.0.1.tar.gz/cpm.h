/*
#######################################################################
#
# (C) Copyright 2002
# Peter McCormick, pete261@yahoo.com
# Eastern Research Inc., http://www.erinc.com
# ported from mpc860sar project, http://mpc860sar.sourceforge.net
#
# (C) Copyright 2001
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
*/

#define __CPM_H__

#include <linux/sockios.h>
#include <asm/immap_8260.h>
#include "defines.h"

/*****************************************************************
// CP RISC Timer Parameter RAM structure
*****************************************************************/

typedef struct risc_timer {

        ushort  tm_base;        // Pointer to DPRAM timers
        ushort  tm_ptr;         // RISC timer table pointer
        ushort  r_tmr;          // RISC timer mode register
        ushort  r_tmv;          // RISC timer valid register
        uint    tm_cmd;         // RISC timer command register
        uint    tm_cnt;         // RISC timer internal count

} risc_timer_t;

/*****************************************************************
        8260SAR parameter RAM
*****************************************************************/

/* address matching First level table entry */
struct fl_ent
{
    ushort vc_mask;
    ushort vc_offset;
} __attribute__ ((packed));

typedef struct fl_ent fl_ent_t;


// Interrupt Table
typedef struct {
    ushort    status;
    ushort    chnum;
} interrupt_table_t;


// Interrupt Queue (INTQ) Parameter Table
typedef struct
{
    interrupt_table_t*  intq_base;     /* Base address of interrupt queue */
    interrupt_table_t*  p_intq;        /* Pointer to interrupt queue entry */
    ushort int_cnt;       /* Interrupt counter */
    ushort int_init_cnt;  /* Interrupt counter initial value */
    ulong  intq_entry;    /* Pointer to interrupt queue entry */
} __attribute__ ((packed)) intq_pram_t;


// ATM Buffer Descriptor AAL0,AAL5, Rx,Tx (Different Status Bits)
typedef struct atm_buf_desc {
        ushort  cbd_sc;         // Status and Control
        ushort  cbd_datlen;     // Data length in buffer
        uint    cbd_bufaddr;    // Buffer address in host memory
} __attribute__ ((packed)) atm_cbd_t_;

// ATM Buffer Descriptor AAL0,AAL5, Rx,Tx (Different Status Bits) with UDC
typedef struct atm_buf_desc_udc {
        ushort  cbd_sc;         // Status and Control
        ushort  cbd_datlen;     // Data length in buffer
        uint    cbd_bufaddr;    // Buffer address in host memory
        unchar udc_header[12];  // Used Defined Cell Header
        unchar RESERVED[12];
} __attribute__ ((packed)) atm_cbd_udc_t;

#ifdef CONFIG_ATM8260_TX_UDC
#define atm_tx_cbd_t atm_cbd_udc_t
#else
#define atm_tx_cbd_t atm_cbd_t_
#endif

#ifdef CONFIG_ATM8260_RX_UDC
#define atm_rx_cbd_t atm_cbd_udc_t
#else
#define atm_rx_cbd_t atm_cbd_t_
#endif

// Transmit Connection Table Extension (TCTE) - VBR+ Protocol Specific 
typedef struct
{
    ushort scr;                     /* Sustain cell rate */
    ushort burst_tolerance;         /* Burst tolerance */
    ushort out_of_buf_rate;         /* Out of buffer rate */
    unchar sustain_rate_reminder;   /* Sustain rate reminder */
    unchar scr_fraction;            /* SCR fraction */
    ulong  sustain_rate;            /* Sustain rate */
    ushort vbr2;                    /* VBR type 2 */
    ushort RESERVED1;
    ulong  RESERVED2[4];
} tcte_vbr_t;


// Transmit Connection Table Extension (TCTE) - UBR+ Protocol Specific
typedef struct
{
    ushort mcr;           /* Minimum cell rate (in slots) */
    unchar RESERVED0;
    unchar mcr_fraction;  /* Minimum cell rate fraction */
    ushort mda;           /* Maximum delay in service allowed for the specific priority level */ 
    ushort RESERVED1;
} tcte_ubrp_t;

// Transmit Connection Table Extension (TCTE) - ABR Protocol Specific
typedef struct
{
    ushort er_ta;        /* Explicit rate-turn-around cell. */
    ushort ccr_ta;       /* CCR contents of the last received F-RM cell */
    ushort mcr_ta;       /* Minimum cell rate of the last received F-RM cell */
    ushort cp_internal;  /* CP internal use parameters */
    ushort mcr;          /* Minimum cell rate */
    ushort unack;        /* Used by CP to count F-RM cells sent in an absence */
    ushort acr;          /* Allowed cell rate */
    ushort acrc;         /* ACR change bit. Indicates a change in the ACR. */
    ulong  rcts;         /* RM cell time stamp */
    unchar cdf;          /* Cutoff Decrease Factor */
    unchar sent_cells;   /* Number of cells sent since the last F-RM cell */
    ushort icr;          /* Initial cell rate */
    ushort crm;          /* Missing RM cells counter */
    ushort adtf;         /* ADTF-ACR decrease time factor */
    ushort er;           /* Explicit rate value of the current ABR channel */
    ushort er_brm;       /* Explicit rate - Backward RM cell. Holds  the maximum explicit */
} tcte_abr_t;


typedef struct 
{
  union{
	  tcte_abr_t  abr;
	  tcte_ubrp_t ubrt;
	  tcte_vbr_t  vbr;
  } prot_spec;
} tx_conn_table_extension_t;


// RCT connection table
typedef struct
{
    ulong  rct_status;             /* RCT status and control bits */
    ulong  p_rx_data;              /* Rx data buffer pointer*/
    ulong  cell_time_stamp;        /* Cell time stamp */
    ushort rx_bd_offset;           /* Rx BD offset from Rx BD base address */
    union                          /* Protocol specific RCT */
    {
        struct                     /* AAL5 protocol specific RCT */
        {
            ushort tml;            /* Total message length */
            ulong crc_temp_res;     /* CRC32 temporary result */
            ushort rx_bd_cnt;      /* Receive BD count */
            ushort pcr;            /* For AAL5-ABR only */
        } __attribute__ ((packed)) aal5;
        struct                     /* AAL1 protocol specific RCT */
        {
            ushort status_bits;    /* The SRTV, SRT, PFM and STF status bits */
            ushort srts_device;    /* SRTS device (0-15) */
            unchar vos;            /* Valid octet size */
            unchar sp;             /* Structured pointer. */
            ushort rx_bd_cnt;      /* Receive BD count */
            ushort seq_number;     /* Sequence number */
        } __attribute__ ((packed)) aal1;
        struct                     /* AAL0 protocol specific RCT */
        {
            ushort status_bits;    /* CR10 and AHD status bits */
            unchar RESERVED3[8];
        } __attribute__ ((packed)) aal0;
    } prot_spec_rct;
    ushort StatusMask;           /* Contains errors and events masks */
    ushort Mrblr;                /* Maximum receive buffer length */
    ulong RxBdBase;             /* Rx BD base address */
} __attribute__ ((packed)) rx_conn_table_t;


// Transmit Connection Table
typedef struct
{
    ulong  tct_status;            /* TCT status bits */
    ulong  p_tx_data;             /* Tx data buffer pointer */
    ushort tx_bd_cnt;             /* Tx BD count */
    ushort tx_bd_offset;          /* Tx BD offset from TBD_BASE */
    unchar rate_reminder;         /* Rate reminder */
    unchar pcr_fraction;          /* Peak cell rate fraction */
    ushort pcr;                   /* Peak cell rate */
    union                         /* Protocol specific TCT */
    {
        struct                    /* AAL5 protocol specific TCT */
        {
            ulong crc_temp_res;   /* CRC32 temporary result */
            ushort tml;           /* Total message length */
        } __attribute__ ((packed)) aal5;
        struct                    /* AAL1 protocol specific TCT */
        {
            unchar vos;           /* Valid octed size */
            unchar status_bits;   /* SRT - Synchronous residuum time stamp; */
            ushort block_size;    /* Structured block size. (In structured format only) */
            ushort sp;            /* Structured pointer (12 least significant bits). */
        } __attribute__ ((packed)) aal1;
        struct                    /* AAL0 protocol specific TCT */
        {
            ushort status_bits;   /* CR10 and ACHC bits */
            ulong RESERVED4;
        } __attribute__ ((packed)) aal0;
    } prot_spec_tct;
    ushort apc_linked_channel;    /* APC linked channel */
    ulong cell_header;            /* ATM cell header */
    ulong tx_bd_base;             /* Holds the PMT number Tx BD base address */
} __attribute__ ((packed)) tx_conn_table_t;


// Parameter RAM for FCC (utopia)
struct fcc_pram {
    ushort riptr;      /* Rx internal temporary data pointer. */
    ushort tiptr;      /* Tx internal temporary data pointer. */
    ushort reserved0;  /* Reserved */
    ushort mrblr;      /* Rx buffer length */
    ulong  rstate;     /* Rx internal state */
    atm_rx_cbd_t*   rbase;      /* RX BD base address */
    ushort rbdstat;    /* Rx BD status and control */
    ushort rbdlen;     /* Rx BD data length */
    ulong  rdptr;      /* rx BD data pointer */
    ulong  tstate;     /* Tx internal state */
    atm_tx_cbd_t*  tbase;      /* TX BD base address */
    ushort tbdstat;    /* Tx BD status and control */
    ushort tbdlen;     /* Tx BD data length */
    ulong  tdptr;      /* Tx  data pointer */
    ulong  rbptr;      /* rx BD pointer */
    ulong  tbptr;      /* Tx BD pointer */
    ulong  rcrc;       /* Temp receive CRC */
    ulong  reserved_1[0x1];
    ulong  tcrc;       /* Temp transmit CRC */
    unchar reserved1[4];  
} __attribute__ ((packed));

typedef struct fcc_pram fcc_pram_t;

/* see 8260 UM section 29.10.1 */
/* changed variable names to match exactly the user manual */
struct atm_pram {
    ushort RCELL_TMP_BASE;    /* Rx cell temporary base address */
    ushort TCELL_TMP_BASE;    /* Tx cell temporary base address */
    ushort UDC_TMP_BASE;       /* UDC temp base address (in UDC mode only) */
    ushort INT_RCT_BASE;       /* Internal RTC base address */
    ushort INT_TCT_BASE;       /* Internal TCT base address */
    ushort INT_TCTE_BASE;      /* Internal ACT base address */
    unchar  reserved1[4];     /* reserved four bytes */
    rx_conn_table_t*  EXT_RCT_BASE;       /* External RTC base address */
    tx_conn_table_t*  EXT_TCT_BASE;       /* External TCT base address */
    tx_conn_table_extension_t*  EXT_TCTE_BASE;      /* Extrnal ACT base address */
    ushort UeadOffset;       /* The offset in half-wordunits of the UEAD entry in the UDC extra header */
    unchar  reserved2[2];     /* Reserved */
    ushort PmtBase;              /* Performance monitoring table base address */
    ushort ApcParamBase;         /* APC Parameters table base address */
    ushort FbpParamBase;         /* Free buffer pool parameters base address */
    ushort IntQParamBase;        /* Interrupt queue parameters table base */
    unchar  reserved3[2];
    ushort UniStatTableBase; /* UNI statistics table base */
    ulong  BD_BASE_EXT;        /* BD ring base address extension */
    fl_ent_t* VPT_BASE;          /* VP-level addressing table base address */
    ulong  VctBase;          /* VC-level addressing table base address */
    ulong  Vpt1Base;         /* VP1-level addressing table base address */
    ulong  Vct1Base;         /* VC1-level addressing table base address */
    ushort VpMask;           /* VP mask for address compression look-up */
	ushort VciFiltering;     /* VCI filtering enable bits */
    ushort GMODE;            /* Global mode */
    ushort CommInfo1;        /* The information fields associated with the */
    ushort Channel_num;      /* the last host command (cpcr). Channel num  */
    ushort Burst_tol;        /* and burst tolerance (VBR channels).        */
    unchar  reserved4[4];     /* Reserved */
    ulong  CRC32Preset;      /* Preset for CRC32 */
    ulong  CRC32Mask;        /* Constant mask for CRC32 */
    ushort AAL1SnpTableBase; /* AAl1 SNP protection look-up table base */
    ushort reserved5;        /* Reserved */
    ulong  SrtsBase;         /* External SRTS logic base address */
    ushort IdleBase;         /* Idle cell base address */
    ushort IdleSize;         /* Idle cell size: 52, 56, 60, 64 */
    ulong  EmptyCellPayload; /* Empty cell payload (little-indian) */
    ulong  Trm; /* ABR - Upper bound on time between F-RM cells for active source */
    ushort Nrm; /* ABR - Controls the maximum data cells sent for each F-RM cell. */
    ushort Mrm; /* ABR - Controls bandwidth between F-RM, B-RM and user data cell */
    ushort Tcr;              /* ABR - Tag cell rate */
    ushort AbrRxTcte;        /* ABR - reserved area address (2-UHWORD aligned)*/
    unchar  reserved7[76];    /* Reserved */
} __attribute__ ((packed));

typedef struct atm_pram atm_pram_t;


// Parameter RAM for FCC/ATM (utopia)
struct sar8260_pram {
     fcc_pram_t fcc;
     atm_pram_t atm;
} __attribute__ ((packed));

typedef struct sar8260_pram sar8260_pram_t;

// APC Parameter Table - see UM 29.10.4.1
typedef struct
{
    ushort APCL_FIRST;  /* Address of first APC priority level */
    ushort APCL_LAST;   /* Address of last APC priority level */
    ushort APCL_PTR;    /* Address of current APC priority level */
    unchar CPS;            /* Number of cells sent per APC slot */
    unchar CPS_CNT;         /* Cells per APC slot counter */
    unchar MAX_ITERATION;  /* Max iteration allowed */
    unchar CPS_ABR;        /* Cells per APC slot for ABR protocol only */
    ushort LINE_RATE_ABR;  /* The line rate of the port for ABR protocol only */
    ulong  REAL_TSTP;   /* Real time stamp pointer */
    ulong  APC_STATE;    
    unchar RESERVED11[12];
} __attribute__ ((packed)) apc_param_t;


// APC Priority table
typedef struct
{
    ushort apc_lev_base;   /* APC level i base address */
    ushort apc_lev_end;    /* APC level i end address */
    ushort apc_lev_rptr;   /* APC level i real-time pointer */
    ushort apc_lev_sptr;   /* APC level i service pointer */
} __attribute__ ((packed)) apc_prior_t;

//Uni Statistics Parameter Table
typedef struct
{
   ushort utopiae;
   ushort mic_cnt;
   ushort crc10_cnt;
   ushort reserved;
} __attribute__ ((packed)) uni_stat_t;  

/* PEM - added for better management of port pins */
typedef struct
{
    int		port;
    int		pin; 
    int         configured;   
    u32 	ppar;
    u32		psor;
    u32		pdir;
} ioport_pin_t;


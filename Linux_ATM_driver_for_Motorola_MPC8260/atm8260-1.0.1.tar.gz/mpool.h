/*
#######################################################################
#
# (C) Copyright 2001
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
# Notes:
# 
# Provides public interface to mpool_t object.  See top of mpool.c
# for details of what this object can do.
# 
# 
#######################################################################
*/
#ifndef __MPOOL_H__
#define __MPOOL_H__

// The maximum size of address range that the object can track
#define LOG2_MAX_BLOCK (22)            /* Must be at least 6 (64B) */
#define MAX_BLOCK (1<<LOG2_MAX_BLOCK)
#define NUM_LISTS (LOG2_MAX_BLOCK /*4M*/ - 6 /*64B*/ + 1)

typedef struct
{
    unsigned char *freeblocks[NUM_LISTS];
} mpool_t;

void mpool_init(mpool_t *mp, unsigned char *addr, int sz);
unsigned char* mpool_alloc(mpool_t *mp, int sz);
void mpool_free(mpool_t *mp, unsigned char * addr, int sz);
void mpool_destroy(mpool_t *mp);

#endif // __MPOOL_H__

/*
#######################################################################
#
# (C) Copyright 2002
# Peter McCormick, pete261@yahoo.com
# Eastern Research Inc., http://www.erinc.com
# ported from mpc860sar project, http://mpc860sar.sourceforge.net
#
# (C) Copyright 2001
# David Pegler, Cambridge Broadband Ltd, dwp@cambridgebroadband.com
# Daris Nevil,  Simple Network Magic Corporation dnevil@snmc.com
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
####################################################################
# Notes: This file contains functions/data used by all ATM devices
# on the MPC8260 SAR.
####################################################################
*/
#include <linux/module.h>
#include <linux/config.h>
#include <linux/kernel.h>
#include <linux/vmalloc.h>	/* for vmalloc */
#include <linux/mm.h>
#include <linux/pci.h>
#include <linux/errno.h>
#include <linux/atm.h>
#include <linux/atmdev.h>
#include <linux/sonet.h>
#include <linux/skbuff.h>
#include <linux/time.h>
#include <linux/timex.h>
#include <linux/sched.h>	/* for xtime */
#include <linux/delay.h>
#include <linux/uio.h>
#include <linux/init.h>
#include <asm/system.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include <asm/string.h>
#include <asm/byteorder.h>

#include <linux/netdevice.h>
#include <linux/ioport.h>
#include <linux/atm.h>

#include <asm/mpc8260.h>
#include <asm/immap_8260.h>
#include <asm/cpm_8260.h>
#include "mpc8260sar.h"
#include "mpool.h"
#include "intpool.h"
#include "cpmtimer.h"
#include "mm.h"
#include "risctimer.h"
#include "debug.h"
#include "errata.h"
#include <asm/irq.h>

/* PEM - to do: make IMAP_ADDR module parameter "base" */

// Period after which mpc8260sar_send() assumes an error has occurred
// if no tx BDs have been freed by CPM
#define TX_TIMEOUT	(10*HZ)	// In ticks

// Timeout for AAL5 Reassembly
#define ATM_RISC_TIMEOUT (RISC_TIMER_MAX_TIMEOUT)

// Empty/idle cell header and payload (see page 3-3 of mpc8260 esar supplement)
//#define ATMF_EMPTY_CELL_HEADER (0x00000000)
//#define ITU_EMPTY_CELL_HEADER  (0x01000000)

//#define EMPTY_HEADER  ATMF_EMPTY_CELL_HEADER
#define EMPTY_PAYLOAD (0x6a6a6a6a)

// receiver delineation counters used in serial ATM mode
//#define ALPHA  7
//#define DELTA  6

// Timer 4 is used for the APC tick
//#define CPM_TIMER_ID	4

// The minimum buffer size that the CPM can cope with
// (this is big enough for 1 ATM cell as well)
#define MIN_CPM_BUFSZ 64

// Define this if we've got an Enhanced SAR
// AJZ TODO: Detect this automatically
//#define GOT_ESAR

/*############# useful macros ######################*/
// Round up to a power of 2
#define ROUNDUP_PWR2(x)                         \
do                                              \
{                                               \
    int i;                                      \
    for(i = 1; i < (x); i <<= 1)                \
        ;                                       \
    (x) = i;                                    \
} while(0)

/*############## forward declarations ##############*/

#define STATIC

// generic mpc8260sar functions
STATIC volatile tx_conn_table_t *mpc8260sar_chanid_to_tx_conx_table(struct
								    atm_dev
								    *dev,
								    int
								    chanid);
STATIC volatile rx_conn_table_t *mpc8260sar_chanid_to_rx_conx_table(struct
								    atm_dev
								    *dev,
								    int
								    chanid);
STATIC volatile ulong *mpc8260sar_get_address_table_entry(struct atm_dev
							  *dev, ushort vpi,
							  ushort vci);
STATIC void mpc8260sar_close_tx_channel(cpm_channel_t * chan);
STATIC void mpc8260sar_tx_channel(struct atm_dev *dev, CPM_CHAN_CTRL ctrl,
				  cpm_channel_t * chan);
STATIC void mpc8260sar_rx_channel(struct atm_dev *dev, CPM_CHAN_CTRL ctrl,
				  cpm_channel_t * chan);
//STATIC void mpc8260sar_byterate_to_apcp(int apc_table_size, ulong byte_rate, ushort *apcp_out, ushort *apcpf_out);
STATIC int mpc8260sar_init_tx_channel(struct atm_vcc *vcc,
				      cpm_channel_t * chan);
STATIC int mpc8260sar_init_rx_channel(cpm_channel_t * chan);
STATIC int mpc8260sar_alloc_rx_ring(cpm_channel_t * chan);
STATIC int mpc8260sar_activate_tx_channel(struct atm_vcc *vcc,
					  cpm_channel_t * chan);
STATIC int mpc8260sar_activate_rx_channel(struct atm_vcc *vcc,
					  cpm_channel_t * chan);
STATIC void mpc8260sar_close_rx_channel(cpm_channel_t * chan);
//STATIC int mpc8260sar_set_apc_slot_time(int us);
STATIC void mpc8260sar_free_chan(cpm_channel_t * chan);
STATIC int mpc8260sar_activate_channel(struct atm_vcc *vcc,
				       cpm_channel_t * chan);
STATIC void mpc8260sar_undo_activate_channel(struct atm_vcc *vcc,
					     cpm_channel_t * chan);
void mpc8260sar_interrupt_bh(void *param);
STATIC void mpc8260sar_rx_bh(dev_data_t * dev_data, int chanid);
STATIC void mpc8260sar_tx_bh(dev_data_t * dev_data, int chanid);
STATIC cpm_channel_t *mpc8260sar_alloc_chan(struct atm_dev *dev);
STATIC int m8260_cpm_dpfree(int addr);
// DEBUG FUNCTION
#ifdef DXMIT_PRINTK
//STATIC void debug_print(struct atm_dev *dev, int param);
//STATIC void print_table(ushort * p);
//STATIC void print_tabled(uint * p, int num);
#endif
//STATIC void mpc8260sar_print_uni_stats(struct atm_dev *dev);

// Extern functions
extern unsigned short le_2_be(unsigned short num);
extern void idt_phy_write(unsigned short addr, unsigned short data);
extern unsigned short idt_phy_read(unsigned short addr);

// mpc8260sar_ops registered by ATM device
STATIC int mpc8260sar_open(struct atm_vcc *vcc, short vpi, int vci);
STATIC void mpc8260sar_close(struct atm_vcc *vcc);
STATIC int mpc8260sar_ioctl(struct atm_dev *dev, unsigned int cmd,
			    void *arg);
STATIC int mpc8260sar_setsockopt(struct atm_vcc *vcc, int level,
				 int optname, void *optval, int optlen);
STATIC int mpc8260sar_getsockopt(struct atm_vcc *vcc, int level,
				 int optname, void *optval, int optlen);
STATIC int mpc8260sar_send(struct atm_vcc *vcc, struct sk_buff *skb);
STATIC int mpc8260sar_sg_send(struct atm_vcc *vcc, unsigned long start,
			      unsigned long size);
STATIC void mpc8260sar_phy_put(struct atm_dev *dev, unsigned char value,
			       unsigned long addr);
STATIC unsigned char mpc8260sar_phy_get(struct atm_dev *dev,
					unsigned long addr);
STATIC int mpc8260sar_change_qos(struct atm_vcc *vcc, struct atm_qos *qos,
				 int flgs);
STATIC int mpc8260sar_proc_read(struct atm_dev *dev, loff_t * pos,
				char *page);

void mpc8260_cmd_wait(char *func, int line);

STATIC int  mpc8260sar_read_proc(char *buf, char **start, off_t offset, int count, int *eof, void *data);
STATIC int mpc8260sar_init_apc(struct atm_dev *dev);
STATIC int mpc8260sar_init_int_pram(struct atm_dev *dev, int interrupt_table_size);
STATIC int mpc8260sar_init_conn_tbls(struct atm_dev *dev);

/*#################### Global scope variables ############*/

// Offset in DPRAM of timestamp timer used by all ATM devices for timestamping AAL5 frames
STATIC uint timestamp_timer_addr;
STATIC int timestamp_timer;

/* operations registered by the atm devices */
const struct atmdev_ops mpc8260sar_ops = {
    open:mpc8260sar_open,
    close:mpc8260sar_close,
    ioctl:mpc8260sar_ioctl,
    getsockopt:mpc8260sar_getsockopt,
    setsockopt:mpc8260sar_setsockopt,
    send:mpc8260sar_send,
    sg_send:mpc8260sar_sg_send,
    phy_put:mpc8260sar_phy_put,
    phy_get:mpc8260sar_phy_get,
    change_qos:mpc8260sar_change_qos,
    proc_read:mpc8260sar_proc_read,
    owner:THIS_MODULE,
};

/*#################### File scope variables ############*/
// Variables calculated by mpc680sar_set_apc_tick()
//STATIC ulong cpm_timer_iclk;
//STATIC ulong cpm_timer_divisor;
//STATIC ulong apc_tickrate;	// The actual APC tickrate


/* Undefine this if you want /proc/net/atm/name:number to count overflow events .
 * Define this if you want APCOV events masked (saves CPU).
 * NOTE: If we've not got an ESAR (i.e. we've got a SAR) then
 * this is ignored because we can't mask APCOVs anyway.
 */
//#define MASK_APCOV

extern struct proc_dir_entry *atm_proc_root; /* @@@ move elsewhere */

#ifdef MASK_APCOV
STATIC int mask_apcov = 1;	// Mask APC Overflow events - will be cleared if no ESAR is found
#else
STATIC int mask_apcov = 0;	// Do not mask.  Number of overflows can be retrieved in /proc/net/atm/name:number
#endif

/*############## function definitions ##############*/

STATIC struct sk_buff *mpc8260sar_alloc_skb(int mtu_)
{
    struct sk_buff *newskb;
    ulong len;

    // Allocate a socket buffer
    newskb = dev_alloc_skb(mtu_);

    if (newskb) {
	// Make sure that newskb->data gives a burst-aligned
	// pointer (divisible by 16)
	if ((len = (ulong) newskb->data & (ulong) 0x0f)) {
	    skb_reserve(newskb, 16 - len);
	}
	// Push the data cache so updates are made now from cache
	// (we don't want data clobbered later)
	flush_dcache_range((ulong) newskb->data,
			   (ulong) (newskb->data + mtu_));
    }

    return (newskb);
}

/*
#########################################################
#
#  Function : mpc8260sar_init_rcq
#
#  Purpose  : Initialises the raw cell queue (channel 0)
#
#  Args     : dev = pointer to the device
#
#  Returns  : 0 for success
#
##########################################################
*/
int mpc8260sar_init_rcq(struct atm_dev *dev)
{
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;

    // Initialise the rcq_chan
    cpm_channel_t *chan = &(dev_data->rcq_chan);

    DLPRINTK("mpc8260sar_init_rcq:chan = %p\n", chan);

    // Clear each field
    memset(chan, 0, sizeof(cpm_channel_t));

    // Save the channel number in chan
    chan->number = 0;

    // Save the connection table entry pointer for the channel
    chan->tctptr = mpc8260sar_chanid_to_tx_conx_table(dev, 0);
    chan->rctptr = mpc8260sar_chanid_to_rx_conx_table(dev, 0);

    DLPRINTK("mpc8260sar_init_rcq:tctptr = %p\n", chan->tctptr);
    DLPRINTK("mpc8260sar_init_rcq:rctptr = %p\n", chan->rctptr);

    // Save ptr to the ATM device in chan
    chan->dev = dev;

    // Save the AAL in chan
    chan->aal = ATM_AAL0;

    // Initialize the RX connection table and buffer descriptors 
    // and skbuff ptrs
    RETURN_ON_ERROR(mpc8260sar_init_rx_channel(chan));

    // Allocate buffers for all RX Buf Descr for this channel
    RETURN_ON_ERROR(mpc8260sar_alloc_rx_ring(chan));

    // Finally enable receptions on this channel
    mpc8260sar_rx_channel(dev, CPM_CHAN_ENABLE, chan);

    return 0;
}

/*
#########################################################
#
#  Function : mpc8260sar_release_rcq
#
#  Purpose  : Release resources used by raw cell queue
#
#  Args     : dev = pointer to ATM device
#
##########################################################
*/
void mpc8260sar_release_rcq(struct atm_dev *dev)
{
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    cpm_channel_t *chan = &(dev_data->rcq_chan);

    mpc8260sar_close_rx_channel(chan);
}

/*
#########################################################
#
#  Function : mpc8260sar_free_tx_skb
#
#  Purpose  : frees an sk_buff.
#
#  Args     : skb=pointer to socket buffer
#
#  Notes    : Tries to use the upper layer pop() function
#             but uses dev_kfree_skb() if this doesn't exist
##########################################################
*/
STATIC void mpc8260sar_free_tx_skb(struct sk_buff *skb)
{
    struct atm_vcc *vcc;

    // See if we can use the VCC pop function !
    if (((vcc = ATM_SKB(skb)->vcc) != NULL) && (vcc->pop != NULL)) {
	// Yes, so use ATM socket layer pop function
	vcc->pop(vcc, skb);
    } else {
	printk(KERN_WARNING "Unable to call skb free function\n");

	// No, so free socket buffer
	dev_kfree_skb(skb);
    }
}

/*
#########################################################
#
#  Function : mpc8260sar_check_channel
#
#  Purpose  : checks that VPI/VCI is not in use on specified device
#             and that the VPI/VCI is in allowed range.
#
#  Args     : see Purpose
#
#  Returns  : 0 for success
#
#  Notes    : Uses a software version of Address Compression
#             (see MPC8260 Enhanced SAR supplement pg 4-4)
#             to see if there is a mapping from dev/vpi/vci
#             to an RCT.
#
##########################################################
*/
STATIC int
mpc8260sar_check_channel(struct atm_dev *dev, short vpi, int vci)
{
    volatile ulong *entry;
    ushort channel;
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;

    DOPENCLOSE_PRINTK(__FUNCTION__ "\n");

    // Check range:
    if (vpi >= dev_data->num_vpis || vci >= dev_data->num_vcis_per_vpi) {
	printk(KERN_WARNING "VPI/VCI out of acceptable range\n");
	return -EINVAL;
    }
    // Get pointer to entry in 2nd level table
    entry = mpc8260sar_get_address_table_entry(dev, vpi, vci);

    // If address matching failed then vpi/vci is not in allowed range
    if (entry == NULL)
	return -EINVAL;

    // Got match :-)

    // extract channel number from entry in 2nd level table
    channel = *entry;

    DLPRINTK("Address of VCT table Entry = %p\n", entry);
    // If this is 0 (i.e. points to the raw cell queue)
    // then dev/vpi/vci is not in use
    if (channel == 0)
	return 0;

    // dev/vpi/vci is in use by channel
    return -EADDRINUSE;
}


/*
#########################################################
#
#  Function : mpc8260sar_get_address_table_entry
#
#  Purpose  : gets a pointer to the entry in the 2nd level
#             address table corresponding to this device,
#             vpi, and vci
#  Args     : see above
#
#  Returns  : address of entry in table, or NULL if match fails
#
#  Notes    : see MPC8260 ESAR supplement pg 4-4
#
##########################################################
*/
STATIC volatile ulong *mpc8260sar_get_address_table_entry(struct atm_dev
							  *dev, ushort vpi,
							  ushort vci)
{
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    volatile fl_ent_t *flbase = dev_data->flbase;	// Base address of first level address matching tables
    volatile ulong *slbase = dev_data->slbase;	// Base address of 2nd level address matching tables
    ushort flmask = dev_data->flmask;	// first level mask
    int i, j;
    ulong tmpvc;
    ushort comp_addr, comp_bit_position;
    ushort slmask;		// 2nd level mask
    ushort sltoffset;		// 2nd level offset
    ushort mask;
    unchar count;

    DOPENCLOSE_PRINTK(__FUNCTION__ "\n");

    comp_bit_position = 0;	/* Reset "next available" compressed addr. bit position */
    comp_addr = 0;		/* Reset "compressed address" value */
    mask = 1;			/* Start with least significant bit */

    for (count = 0; (count < 16) && (mask <= flmask); count++, mask <<= 1) {
	if (mask & flmask) {
	    if (mask & flmask & vpi)
		comp_addr |= (1 << comp_bit_position);
	    comp_bit_position++;
	}
    }

    // Get the slmask and sltoffset from the first level entry
    slmask = flbase[comp_addr].vc_mask;
    sltoffset = flbase[comp_addr].vc_offset;

    // if slmask is 0 then cells are routed to raw cell queue
    // and no one entry exists for the raw cell queue
    if (slmask == 0)
	return NULL;

    tmpvc = 0x00000000;
    for (i = 0, j = 0; i < 16; i++) {
	if ((slmask >> i) & 0x1)
	    tmpvc |= (((vci >> i) & 0x1) << j++);
    }

    // return pointer to second level table entry
    return (slbase + sltoffset * 4 + tmpvc);
}

/*
#########################################################
#
#  Function : mpc8260sar_alloc_chan
#
#  Purpose  : Allocates and initialises a cpm_channel_t
#             to the caller
#  Args     :
#             dev = the atm device
#
#  Returns  : ptr to a channel structure
#             or NULL for failure
#
##########################################################
*/
STATIC cpm_channel_t *mpc8260sar_alloc_chan(struct atm_dev *dev)
{
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    cpm_channel_t *channels = dev_data->channels;
    int chanid;
    cpm_channel_t *chan;

    DOPENCLOSE_PRINTK(__FUNCTION__ "\n");

    // Allocate a channel number greater or equal
    // to 32.  The CPM will use a connection table
    // in external memory
    // We avoid using DPRAM for channels other than the
    // raw cell queue (rx) and PTP (tx) because there is not enough
    // DPRAM for (32 * num_sccs_inuse) connection tables
    // if num_sccs_inuse is greater than 1.

    // Get the lowest currently free channel number
    chanid = intpool_alloc(&(dev_data->channel_tracker));
    if (chanid == -1) {
	printk(KERN_ERR
	       "alloc_chan : could not allocate channel number\n");
	return NULL;
    }
    DLPRINTK("chanid just returned = %d\n", chanid);
    chanid += 32;		//THIS SHOULD BE FIXED!!

    // Get the channel structure associated with this channel number
    chan = &(channels[chanid]);

    DOPENCLOSE_PRINTK("chanid=%d\n", chanid);

    // Initialise chan

    // Clear each field
    memset(chan, 0, sizeof(cpm_channel_t));

    // Save the channel number in chan
    chan->number = chanid;

    // Save the connection table entry pointer for the channel
    chan->tctptr = mpc8260sar_chanid_to_tx_conx_table(dev, chanid);
    chan->rctptr = mpc8260sar_chanid_to_rx_conx_table(dev, chanid);

    memset((void *) chan->tctptr, 0, sizeof(tx_conn_table_t));
    memset((void *) chan->rctptr, 0, sizeof(rx_conn_table_t));

    DOPENCLOSE_PRINTK("----------------------\n");
    DOPENCLOSE_PRINTK("tctptr=%p\n", chan->tctptr);
    DOPENCLOSE_PRINTK("rctptr=%p\n", chan->rctptr);
    DOPENCLOSE_PRINTK("----------------------\n");

    // Save ptr to the ATM device in chan
    chan->dev = dev;

    return chan;
}

/*
#########################################################
#
#  Function : mpc8260sar_free_chan
#
#  Purpose  : Counterpart to mpc8260sar_alloc_chan()
#
#  Args     : chan = ptr to chan allocated by mpc8260sar_alloc_chan()
#  Notes    : Must be the last thing called by mpc8260sar_close()
#
##########################################################
*/
STATIC void mpc8260sar_free_chan(cpm_channel_t * chan)
{
    dev_data_t *dev_data = (dev_data_t *) chan->dev->dev_data;

    // Free the chanid so that it can be used again
    // by another VC.
    intpool_free(&(dev_data->channel_tracker), chan->number - 32);

    // No need to clear any structures in chan as this will be done
    // by mp8260sar_close() ... when this chanid gets reused mpc8260sar_open()
    // will clear the fields in chan.
}

/*
#########################################################
#
#  Function : mpc8260sar_chanid_to_tx_conx_table
#
#  Purpose  : access the connection table mapped to by channel
#
#  Args     : dev=pointer to current atm device
#             chanid=number of channel
#
#  Returns  : pointer to the connection table mapped to by that channel
#
#  Notes    : Assumes we're using Address Compression
#             See MPC8260 Enhanced SAR manual pg 4-4
##########################################################
*/
STATIC volatile tx_conn_table_t *mpc8260sar_chanid_to_tx_conx_table(struct
								    atm_dev
								    *dev,
								    int
								    chanid)
{
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;

    // Sanity check
    if ((chanid != 0 && (chanid - 32) >= dev_data->max_channels) ||
	(chanid != 0 && chanid < 32)) {
	printk(KERN_ERR "Error: (" __FUNCTION__ ") invalid chanid %d\n",
	       chanid);
	return NULL;
    }
    // Calculate the address of the connection table
    if (chanid < NUM_INT_CONN_TABLES) {
	// We allocate an internal connection table (i.e. one in DPRAM)
	return &(dev_data->tctbase[chanid]);
    } else {
	// We allocate an external connection table (i.e. one in external memory)
	return &(dev_data->etctbase[chanid - 64 + 256]);
    }

    return NULL;
}

/*
#########################################################
#
#  Function : mpc8260sar_chanid_to_rx_conx_table
#
#  Purpose  : access the connection table mapped to by channel
#
#  Args     : dev=pointer to current atm device
#             chanid=number of channel
#
#  Returns  : pointer to the connection table mapped to by that channel
#
#  Notes    : Assumes we're using Address Compression
#             See MPC8260 Enhanced SAR manual pg 4-4
##########################################################
*/
STATIC volatile rx_conn_table_t *mpc8260sar_chanid_to_rx_conx_table(struct
								    atm_dev
								    *dev,
								    int
								    chanid)
{
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;

    // Sanity check
    if ((chanid != 0 && (chanid - 32) >= dev_data->max_channels) ||
	(chanid != 0 && chanid < 32)) {
	printk(KERN_ERR "Error: (" __FUNCTION__ ") invalid chanid %d\n",
	       chanid);
	return NULL;
    }
    // Calculate the address of the connection table
    if (chanid < NUM_INT_CONN_TABLES) {
	// We allocate an internal connection table (i.e. one in DPRAM)
	return &(dev_data->rctbase[chanid]);
    } else {
	// We allocate an external connection table (i.e. one in external memory)
	return &(dev_data->erctbase[chanid - 64 + 256]);
    }

    return NULL;
}


/*
#########################################################
#
#  Function : mpc8260sar_init_pram
#
#  Purpose  : Initializes the parameter ram for a device
#             and saves copies of some of the values
#             written to dev_data
#  Args     : see below
#
#  Returns  : 0 for success
#
#  Notes    : Half of dev->dev_data is written
#             by mpc8260sar_init_dev_data().  The other
#             half is written by this function.
#
##########################################################
*/

int mpc8260sar_init_pram(struct atm_dev *dev,	// The device being initialised
			 int screen_oam,	// Are we screening for OAM cells on each VC or do we sent them to raw cell q
			 int interrupt_table_size	// The number of interrupt table entries
    )
{
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    volatile immap_t *immap = (immap_t *) dev_data->immap;
    volatile sar8260_pram_t *sar_pram =
	(sar8260_pram_t *) ((unsigned char *)immap + 0x8400 +
			    ((dev_data->fcc - 1) * 0x100));
    int result = 0;
    uint i;
    int num_bytes;
    uint num_vpis = dev_data->num_vpis;
    uint num_vcis_per_vpi = dev_data->num_vcis_per_vpi;

#ifndef CONFIG_PROC_FS
    char *name = "atm";
#else
    char *name = dev->proc_name;
#endif

    DINIT_PRINTK(__FUNCTION__ "\n");

    DLPRINTK("mpc8260sar_init_pram:dev_data at :%p\n", dev_data);
    DINIT_PRINTK("sizeof(*sar_pram)=%d sar_pram=%p\n", sizeof(*sar_pram),
		 sar_pram);

    // save a pointer to the parameter ram page in the device data
    dev_data->sar_pram = sar_pram;

    // Disable the receiver / reset
    dev_data->im_fcc->fcc_gfmr = 0;

    DLPRINTK("mpc8260sar_init_pram:&dev_data->im_fcc->fcc_gfmr = %p\n",
	     &dev_data->im_fcc->fcc_gfmr);

    // Make sure the parameter RAM area is not already allocated
    RETURN_ON_ERROR(check_region((unsigned long)sar_pram, 
				 sizeof(sar8260_pram_t)));

    // Allocate the parameter RAM
    request_region((unsigned long) sar_pram, sizeof(sar8260_pram_t), name);

    // zero the entire parameter RAM
    memset((sar8260_pram_t *) sar_pram, 0, sizeof(sar8260_pram_t));

    // PEM - temp debug
    sar_pram->atm.BD_BASE_EXT = 0xFF000000 & __pa(dev_data->tbdbase);
    printk("pa tbdbase = %lx\n", __pa(dev_data->tbdbase));
    printk("pa rbdbase = %lx\n", __pa(dev_data->rbdbase)); 
    
    // Max 64K channels
    // 53-byte ATM cell
    // Disable the reciever / transmiter
    //dev_data->im_fcc->fcc_gfmr = (GFMR_MODE_ATM | GFMR_TCI);
    dev_data->im_fcc->fcc_gfmr = GFMR_MODE_ATM; //hafe
    
    /* see 8260 UM section 29.13.2 */
    dev_data->im_fcc->fcc_fpsmr = 0;

    if(dev_data->utopia.last_phy){
	/* multi-phy mode */
        dev_data->im_fcc->fcc_fpsmr |= (FPSMR_TUMP | FPSMR_RUMP);
	dev_data->im_fcc->fcc_fpsmr |= ((dev_data->utopia.last_phy << 16) & 0x1f00);
	if(dev_data->utopia.mphy_priority){
	    dev_data->im_fcc->fcc_fpsmr |= FPSMR_UPRM;
	}
	if(dev_data->utopia.mphy_polling){
	    dev_data->im_fcc->fcc_fpsmr |= FPSMR_UPLM;
	}
    }

    if(!dev_data->utopia.master){
        /* slave mode */
        dev_data->im_fcc->fcc_fpsmr |= (FPSMR_TUMS | FPSMR_RUMS);
    }

    if(dev_data->utopia.bus_size == 16){
        dev_data->im_fcc->fcc_fpsmr |= (FPSMR_TSIZE | FPSMR_RSIZE);
    }

    /* Set up for user defined cells (if any) */
    dev_data->im_fcc->fcc_fpsmr |= (ATM_TEHS << (31-3)) | (ATM_TUDC << (31-19));
    dev_data->im_fcc->fcc_fpsmr |= (ATM_REHS << (31-7)) | (ATM_RUDC << (31-20));

    /* do not check rx parity line */
    dev_data->im_fcc->fcc_fpsmr |= FPSMR_RXP;

    // Include HEC in UDC mode
    dev_data->im_fcc->fcc_fpsmr |= FPSMR_HECI; // hafe

    /* see 8260 UM section 29.10.1.3 */
    sar_pram->atm.GMODE = 0;

    if(dev_data->addr_lookup_local){
      sar_pram->atm.GMODE |= GMODE_ALB;
    }
    if(dev_data->conn_tbl_local){
      sar_pram->atm.GMODE |= GMODE_CTB;
    }
    if(dev_data->vp_tbl_ext){
      sar_pram->atm.GMODE |= GMODE_EVPT;
    }
    if(dev_data->addr_lookup_comp){
      sar_pram->atm.GMODE |= (GMODE_ALM | GMODE_CUAB);
    }
    else{
      printk(KERN_ERR "External CAM lookup not supported\n");
      return -EINVAL;
    }

    // Configure the Address matching parameters for extended channel mode
    // Write the First-level table base
    num_bytes = (num_vpis + 1) * sizeof(fl_ent_t);	// how much memory do we need 
    i = m8260_cpm_dpalloc(num_bytes, 8);
    if (i == CPM_DP_NOSPACE)
	goto fail_malloc_dpram;

    // Clear the DPRAM connection table
    memset((void *) &immap->im_dprambase[i], 0, num_bytes);
    dev_data->flbase = (void *) &immap->im_dprambase[i];
    sar_pram->atm.VPT_BASE = (fl_ent_t *) dev_data->flbase;

    // Write the 2nd-level table base
    num_bytes = num_vpis * num_vcis_per_vpi * sizeof(ulong);	// how much memory do we need
    if (!(dev_data->slbase = (volatile ulong *) mm_alloc_uncached_pages(num_bytes)))	// alloc the pages
    {
	printk(KERN_CRIT "No more free pages\n");
	result = -ENOMEM;
	goto fail_malloc_pages;
    }
    sar_pram->atm.VctBase = __pa(dev_data->slbase);	// write the slbase pointer in pram

    DINIT_PRINTK("dev_data->slbase =%p\n", dev_data->slbase);

    // FLMASK must have AT LEAST ONE BIT SET for correct CPM behaviour
    if (num_vpis == 1) {
	// Set top VPI bit in FLMASK
	dev_data->flmask = 0x0001;
	sar_pram->atm.VpMask = dev_data->flmask;

	// Make the 2nd entry in FL table a copy of the first
	// so that both VPI ranges get mapped to the same SL table entry
	dev_data->flbase[0].vc_mask = num_vcis_per_vpi - 1;	// VCI range is 0 to num_vcis_per_vpi-1
	dev_data->flbase[0].vc_offset = 0;
	dev_data->flbase[1].vc_mask = num_vcis_per_vpi - 1;	// VCI range is 0 to num_vcis_per_vpi-1
	dev_data->flbase[1].vc_offset = 0;
    } else {
	dev_data->flmask = 0x000F;	// 16 VPis
	sar_pram->atm.VpMask = dev_data->flmask;

	// Initialise the First level address table entries
	for (i = 0; i < num_vpis; i++) {
	    dev_data->flbase[i].vc_mask = num_vcis_per_vpi - 1;	// VCI range is 0 to num_vcis_per_vpi-1
	    dev_data->flbase[i].vc_offset =
		i * num_vcis_per_vpi * sizeof(ulong);
	}
    }

    // Initialise the 2nd level address table entries to all point at the raw cell queue (0)
    memset((void *) dev_data->slbase, 0, num_bytes);

    if(mpc8260sar_init_conn_tbls(dev) != 0){
      goto fail_malloc_dpram;
    }

    // We are not performing statistics
    // Configured in Gmode register
    // We are not operating in expanded cell mode
    // Configured in Gmode register

    if(mpc8260sar_init_int_pram(dev, interrupt_table_size) != 0){
      goto fail_malloc_dpram;
    }

    // Init the CRC-32 Mask
    sar_pram->atm.CRC32Mask = AAL5_CRC32_MASK;
    sar_pram->atm.CRC32Preset = 0xFFFFFFFF;
    sar_pram->atm.IdleSize = 0x34;

    // If this is a serial ATM controller we need to initialise
    // the header and payload of the empty/idle cell
    sar_pram->atm.EmptyCellPayload = EMPTY_PAYLOAD;

    if(mpc8260sar_init_apc(dev) != 0){
        goto fail_malloc_dpram;
    } 
    
#ifdef DEBUG_PRINT_ALL
    debug_print(dev, 2);
#endif

    DLPRINTK("FCC param ram struct size = %d\n", sizeof(fcc_pram_t));
    DLPRINTK("ATM param ram struct size = %d\n", sizeof(atm_pram_t));
    DLPRINTK("TCT Connection table has size = %d\n", sizeof(tx_conn_table_t));
    DLPRINTK("RCT Connection table has size = %d\n", sizeof(rx_conn_table_t));
    DLPRINTK("Both ATM and FCC pram have the size of %d bytes\n", sizeof(sar8260_pram_t));
    DLPRINTK("Address of tcrc = %p \n", &sar_pram->fcc.tcrc);
    DLPRINTK("Address of RCELL_TMP_BASE = %p\n", &sar_pram->atm.RCELL_TMP_BASE);
    DLPRINTK("Address of AbrRxTcte = %p\n", &sar_pram->atm.AbrRxTcte);

    goto done;

  fail_malloc_pages:
    printk(KERN_CRIT "Error: No more free pages");
    result = -ENOMEM;

  fail_malloc_dpram:
    printk(KERN_CRIT "Error: No more CPM DPRAM\n");
    result = -ENOMEM;

    release_region((unsigned long) sar_pram, sizeof(sar8260_pram_t));
  done:
    return (result);
}

////////////////////////////////////////////////////////////////////////////
// Allocate memory for some Connection Tables and several Extended Connection tables
//
// We do not have enough space for 32 internal connection tables if we
// are using more than one SCC.  This is okay because we also make sure
// that chanids 1-31 are never allocated to ordinary channels
//
// The MPC8260 ATM Supplement, p2-8, shows that the first element
// of the connection table is reserved, and that the ctbase
// register points to the beginning of the second element
// of the table.  This extra entry is used by the CPM in extended channel mode
////////////////////////////////////////////////////////////////////////////
// Allocate space in DPRAM for the following:
// 1 reserved TCT;
// 1 raw cell queue TCT
// num_apc_levels PTP TCTs
// 32 alignment bytes

STATIC int mpc8260sar_init_conn_tbls(struct atm_dev *dev)
{
  int num_bytes;    
  uint i;
  dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
  volatile immap_t *immap = (immap_t *) dev_data->immap;
  volatile sar8260_pram_t *sar_pram =
    (sar8260_pram_t *) ((unsigned char *)immap + 0x8400 + ((dev_data->fcc - 1) * 0x100));
  
  // Receive internal temporary data pointer
  num_bytes = 16 * sizeof(ushort) + 64; 
  i = m8260_cpm_dpalloc(num_bytes, 8); 
  if (i == CPM_DP_NOSPACE)
    return -EINVAL;

  // Clear the DPRAM connection table
  memset((void *) &immap->im_dprambase[i], 0, num_bytes);

  // Adjust to 64 byte boundary
  i = ~63 & (i + 63);

  sar_pram->atm.IdleBase = i;

  //  Rx Cell Temporary Base Address (52 bytes size, 64byte allign
  num_bytes = 26 * sizeof(ushort) + 64;
  i = m8260_cpm_dpalloc(num_bytes, 8);
  if (i == CPM_DP_NOSPACE)
    return -EINVAL;
  memset((void *) &immap->im_dprambase[i], 0, num_bytes);
  // Adjust to 32 byte boundary
  i = ~63 & (i + 63);
  sar_pram->atm.RCELL_TMP_BASE = i;

  //  Tx Cell Temporary Base Address (52 bytes size, 64byte allign
  num_bytes = 26 * sizeof(ushort) + 64;
  i = m8260_cpm_dpalloc(num_bytes, 8);
  if (i == CPM_DP_NOSPACE)
    return -EINVAL;
  memset((void *) &immap->im_dprambase[i], 0, num_bytes);
  // Adjust to 32 byte boundary
  i = ~63 & (i + 63);
  sar_pram->atm.TCELL_TMP_BASE = i;

  //  UDC Temporary Base Address (32 bytes size, 64byte align - hafe
  num_bytes = 16 * sizeof(ushort) + 64;
  i = m8260_cpm_dpalloc(num_bytes, 8);
  if (i == CPM_DP_NOSPACE)
    return -EINVAL;
  memset((void *) &immap->im_dprambase[i], 0, num_bytes);
  i = ~63 & (i + 63);
  sar_pram->atm.UDC_TMP_BASE = i; // hafe

  // Uni statistics Parameter Ram 
  i = m8260_cpm_dpalloc(sizeof(uni_stat_t), 8);
  if (i == CPM_DP_NOSPACE)
    return -EINVAL;  
  memset((void *) &immap->im_dprambase[i], 0, sizeof(uni_stat_t));
  sar_pram->atm.UniStatTableBase = i;

  // INTERNAL TCTs in DPRAM
  num_bytes = ATM_INT_CTES * sizeof(tx_conn_table_t) + 32;
  i = dev_data->dpalloc_base1 = m8260_cpm_dpalloc(num_bytes, 8);
  if (i == CPM_DP_NOSPACE)
    return -EINVAL;
  memset((void *) &immap->im_dprambase[i], 0, num_bytes);
  // Adjust to 32 byte boundary
  i = ~31 & (i + 31);
  // Save the Connection Table base address
  // (after skipping the reserved entry)
  i += sizeof(tx_conn_table_t);
  sar_pram->atm.INT_TCT_BASE = i;
  dev_data->tctbase = (volatile tx_conn_table_t *) &immap->im_dprambase[i];
  DINIT_PRINTK("dev_data->tctbase=%p\n", dev_data->tctbase);
  DINIT_PRINTK("dev_data->max_channels=%d\n", dev_data->max_channels);

  // Allocate space in DPRAM for the following:
  // 1 reserved RCT;
  // 1 raw cell queue RCT
  // num_apc_levels PTP RCTs
  // 32 alignment bytes

  // INTERNAL RCTs in DPRAM
  num_bytes = ATM_INT_CTES * sizeof(rx_conn_table_t) + 32;
  i = dev_data->dpalloc_base2 = m8260_cpm_dpalloc(num_bytes, 8);
  if (i == CPM_DP_NOSPACE)
    return -EINVAL;
  memset((void *) &immap->im_dprambase[i], 0, num_bytes);
  // Adjust to 32 byte boundary
  i = ~31 & (i + 31);
  // Save the Connection Table base address
  // (after skipping the reserved entry)
  i += sizeof(rx_conn_table_t);
  sar_pram->atm.INT_RCT_BASE = i;
  dev_data->rctbase = (volatile rx_conn_table_t *) &immap->im_dprambase[i];
  DINIT_PRINTK("dev_data->rctbase=%p\n", dev_data->rctbase);
  DINIT_PRINTK("dev_data->max_channels=%d\n", dev_data->max_channels);

  // EXTERNAL TCTs in SDRAM
  // Allocate space in external memory for the extended tx connection table
  num_bytes = (dev_data->max_channels + 256) * sizeof(tx_conn_table_t);	// how much memory do we need
  if (!(dev_data->etctbase = (tx_conn_table_t *) mm_alloc_uncached_pages(num_bytes)))	// alloc the pages
    return -EINVAL;
  // Adjust the etctbase to account for the fact that the CPM
  // uses (chanid) to index etctbase instead of (chanid - 32)
  sar_pram->atm.EXT_TCT_BASE = (tx_conn_table_t *) __pa(dev_data->etctbase);	// write the ectbase pointer in pram
  memset((void *) (dev_data->etctbase), 0, num_bytes);

  // EXTERNAL RCTs in SDRAM
  // Allocate space in external memory for the extended rx connection table
  num_bytes = (dev_data->max_channels + 256) * sizeof(rx_conn_table_t);	// how much memory do we need
  if (!(dev_data->erctbase = (rx_conn_table_t *) mm_alloc_uncached_pages(num_bytes)))	// alloc the pages
    return -EINVAL;
  sar_pram->atm.EXT_RCT_BASE = (rx_conn_table_t *) __pa(dev_data->erctbase);	// write the ectbase pointer in pram
  memset((void *) (dev_data->erctbase), 0, num_bytes);

  
  ////////////////////////////////////////////////////////////////////////////
  // Allocate memory for some TCTEs and several Extended TCTE tables
  //
  // We do not have enough space for 32 internal TCTEs if we
  // are using more than one SCC.  This is okay because we also make sure
  // that chanids 1-31 are never allocated to ordinary channels
  //
  // The MPC8260 ATM Supplement, p2-21, shows that the first element
  // of the DPRAM TCTE table is reserved, and that the tctebase
  // register points to the beginning of the second element
  // of the table.  This extra entry is used by the CPM in extended channel mode
  ////////////////////////////////////////////////////////////////////////////
  
  // INTERNAL ETCTs in DPRAM
  
  // Allocate space in DPRAM for the following:
  // 1 reserved TCTE;
  // 1 raw cell queue TCTE (wasted space but needed so that the following correspond to CTs allocated above)
  // num_apc_levels PTP TCTEs
  // 32 alignment bytes
  num_bytes = ATM_INT_CTES * sizeof(tx_conn_table_extension_t) + 32; 
  i = dev_data->dpalloc_base3 = m8260_cpm_dpalloc(num_bytes, 8);
  if (i == CPM_DP_NOSPACE)
    return -EINVAL;
  memset((void *) &immap->im_dprambase[i], 0, num_bytes);
  // Adjust to 32 byte boundary
  i = ~31 & (i + 31);
  // Save the TCTE base address
  // (after skipping the reserved entry)
  i += sizeof(tx_conn_table_extension_t);
  sar_pram->atm.INT_TCTE_BASE = i;
  dev_data->tctebase = (volatile tx_conn_table_extension_t *) &immap->im_dprambase[i];
  DINIT_PRINTK("dev_data->tctebase=%p\n", dev_data->tctebase);

  // EXTERNAL ETCTs in SDRAM
  // Allocate space in external memory for the extended connection table
  num_bytes = dev_data->max_channels * sizeof(tx_conn_table_extension_t);	// how much memory do we need
  if (!(dev_data->etctebase = (tx_conn_table_extension_t *) mm_alloc_uncached_pages(num_bytes)))	// alloc the pages
    return -EINVAL;
  // Adjust the etctebase to account for the fact that the CPM
  // uses (chanid) to index ectbase instead of (chanid - 32)
  dev_data->etctebase = &(dev_data->etctebase[-NUM_INT_CONN_TABLES]);
  sar_pram->atm.EXT_TCTE_BASE = (tx_conn_table_extension_t *) __pa(dev_data->etctebase);	// write the etctebase pointer in pram
  // Clear the extended TCTEs
  memset((void *) &(dev_data->etctbase[NUM_INT_CONN_TABLES]), 0,
	 dev_data->max_channels * sizeof(tx_conn_table_extension_t));
  
  return 0;	
}

//  INTERRUPT PARAMETER RAM 
STATIC int mpc8260sar_init_int_pram(struct atm_dev *dev, int interrupt_table_size)
{
  int num_bytes;    
  uint i;
  dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
  volatile immap_t *immap = (immap_t *) dev_data->immap;
  volatile sar8260_pram_t *sar_pram =
    (sar8260_pram_t *) ((unsigned char *)immap + 0x8400 +
			    ((dev_data->fcc - 1) * 0x100));
  int j;
    
  // Allocate memory for Interrupt Parameter Ram
  num_bytes = ATM_INT_QUEUES * sizeof(intq_pram_t); 
  i = dev_data->dpalloc_base4 = m8260_cpm_dpalloc(num_bytes, 8);

  if (i == CPM_DP_NOSPACE)
    return -EINVAL;

  // Clear the DPRAM interrupt parameter table
  memset((void *) &immap->im_dprambase[i], 0, num_bytes);
  dev_data->intq_pram_ptr = (volatile intq_pram_t *) &immap->im_dprambase[i];
  
  DINIT_PRINTK("intq_pram_ptr=%p\n", dev_data->intq_pram_ptr);

  // Set Pointer to Interrupt paramater ram   
  sar_pram->atm.IntQParamBase = i;

  // Allocate memory for the interrupt circular table
  for(j=0; j<ATM_INT_QUEUES; j++){ 
  	num_bytes = interrupt_table_size * sizeof(interrupt_table_t);	

    if (!(dev_data->intptr[j] = dev_data->intbase[j] =
	(interrupt_table_t *) mm_alloc_uncached_pages(num_bytes))) {
       return -EINVAL;
    }

    // Initialise  the interrupt circular table
    memset((void *) dev_data->intptr[j], 0, num_bytes);
       
    DINIT_PRINTK("intptr[%d]=%p\n", j,dev_data->intptr[j]);
  }
  
  for(j=0; j<ATM_INT_QUEUES; j++){
    // Add interrupt table base ptr to parameter ram
    dev_data->intq_pram_ptr[j].intq_base = (interrupt_table_t *) __pa(dev_data->intptr[j]);
    dev_data->intq_pram_ptr[j].p_intq = (interrupt_table_t *) __pa(dev_data->intptr[j]);
    
    // Set the Interrupt counter and initiate value
    dev_data->intq_pram_ptr[j].int_cnt = 1;
    dev_data->intq_pram_ptr[j].int_init_cnt = 1;
    // Set the status field of the last table entry to W (force CP to wrap!)
    dev_data->intptr[j][interrupt_table_size - 1].status = INTR_W;   
  } 
  
  return 0;
}

//////////////////////////////////////////////////////////////////////
// Set up APC parameter ram 
// APC Status and Control
// Current channel = dev_data->scc
// Number of PHY = 1
// ESAR mode enabled
// Priority table level 2 = reserved in ESAR mode
// Clear DIS bit
// MPHY = reserved in ESAR mode
//////////////////////////////////////////////////////////////////////
// Allocate memory for the APC Parameter Table
// The APC table must be aligned on a 32 byte boundary
// so allocate 32 bytes more, and then adjust for 32 byte
// boundary

STATIC int mpc8260sar_init_apc(struct atm_dev *dev)
{
  int num_bytes;    
  uint i;
  dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
  volatile immap_t *immap = (immap_t *) dev_data->immap;
  volatile sar8260_pram_t *sar_pram =
    (sar8260_pram_t *) ((unsigned char *)immap + 0x8400 +
			    ((dev_data->fcc - 1) * 0x100));
  
  int num_of_priorities = dev_data->num_of_priorities;
  int j;
  int prior_level;
  
  // ALLOCATE SPACE FOR APC PARAMETER RAM  
  num_bytes = sizeof(apc_param_t)*(UTOPIA_LAST_PHY+1);
  i = dev_data->dpalloc_base6 = m8260_cpm_dpalloc(num_bytes + 32, 8);
  if (i == CPM_DP_NOSPACE) {
    return -EINVAL;
  }

  // Adjust to 32 byte boundary
  i = ~31 & (i + 31);
  memset((void *) &immap->im_dprambase[i], 0, num_bytes);

  // Save the APC Param Table pointer
  sar_pram->atm.ApcParamBase = i;
  dev_data->apcptr = (volatile apc_param_t *) &immap->im_dprambase[i];
  printk("apcptr=%p\n",dev_data->apcptr);
  
  // Allocate DPSRAM for APC Priority tables 
  num_bytes = sizeof(apc_prior_t) * num_of_priorities; 
  i = dev_data->dpalloc_base7 = m8260_cpm_dpalloc(num_bytes, 8);
  if (i == CPM_DP_NOSPACE) {
    return -EINVAL;    
  }
  
  memset((void *) &immap->im_dprambase[i], 0, num_bytes);
  dev_data->apc_pr_ptr = (volatile apc_prior_t *) &immap->im_dprambase[i];
  printk("apc_pr_ptr=%p\n",dev_data->apc_pr_ptr);

  ///// Init some data in APC parameter Table 
  for(j=0; j<=UTOPIA_LAST_PHY; j++){
    dev_data->apcptr[j].APCL_FIRST = i;
    dev_data->apcptr[j].APCL_PTR = i;
    dev_data->apcptr[j].APCL_LAST = i + (num_of_priorities - 1) * 8;	// Check Manual 
    dev_data->apcptr[j].REAL_TSTP = 0;
  }

  // Allocate space for scheduling tables 
  num_bytes = sizeof(ushort) * (dev_data->number_of_slots + 1) * num_of_priorities;
  i = dev_data->dpalloc_base8 = m8260_cpm_dpalloc(num_bytes + 64, 8);
  if (i == CPM_DP_NOSPACE) {
    return -EINVAL;
  }
  // Adjust to 64 byte boundary
  i = ~63 & (i + 63);

  memset((void *) &immap->im_dprambase[i], 0, num_bytes);
   
  // For each APC level, write pointers to table start, end, &c.
  for (prior_level = 0; prior_level < num_of_priorities; prior_level++) {
    ushort table_start =
      i + (dev_data->number_of_slots + 1) * prior_level;
    
    dev_data->apc_pr_ptr[prior_level].apc_lev_base = table_start;
    dev_data->apc_pr_ptr[prior_level].apc_lev_end =
      table_start + (dev_data->number_of_slots - 1) * 2;
    dev_data->apc_pr_ptr[prior_level].apc_lev_sptr = table_start;
    dev_data->apc_pr_ptr[prior_level].apc_lev_rptr = table_start;
  }

  for(j=0; j<=UTOPIA_LAST_PHY; j++){
    dev_data->apcptr[j].MAX_ITERATION = 4;
    dev_data->apcptr[j].CPS = dev_data->cells_per_slot;
    dev_data->apcptr[j].CPS_CNT = dev_data->cells_per_slot;
    dev_data->apcptr[j].CPS_ABR = dev_data->cells_per_slot_abr;
    dev_data->apcptr[j].LINE_RATE_ABR = dev_data->line_rate_abr;
    dev_data->apcptr[j].APC_STATE = 0;
  }

  return 0;	
}

/*
#########################################################
#
#  Function : mpc8260sar_release_pram
#
#  Purpose  : Releases resources used by parameter RAM
#
#  Args     : dev = ATM device being initialised
#
#  Returns  : 0 for success
#
##########################################################
*/
int mpc8260sar_release_pram(struct atm_dev *dev)
{
  dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
  volatile sar8260_pram_t *sar_pram = dev_data->sar_pram;
  int j;
  
  RETURN_ON_ERROR(m8260_cpm_dpfree(dev_data->dpalloc_base6));
  RETURN_ON_ERROR(m8260_cpm_dpfree(dev_data->dpalloc_base7));
  RETURN_ON_ERROR(m8260_cpm_dpfree(dev_data->dpalloc_base8));

  // Free DPRAM used for APC tables
  RETURN_ON_ERROR(m8260_cpm_dpfree(dev_data->dpalloc_base5));

  // Free DPRAM used for APC parameter tables
  RETURN_ON_ERROR(m8260_cpm_dpfree(dev_data->dpalloc_base4));

  // Free DPRAM used transmit queue
  RETURN_ON_ERROR(m8260_cpm_dpfree(dev_data->dpalloc_base3));

  // Free pages used for interrupt table
  for(j=0; j<ATM_INT_QUEUES; j++){
    mm_free_pages(dev_data->intbase[j]);
  }
  
  // Free pages used for external TCTEs
  dev_data->etctebase = &(dev_data->etctebase[+NUM_INT_CONN_TABLES]);
  mm_free_pages((void*) dev_data->etctebase);

  // Free DPRAM used for internal TCTEs
  RETURN_ON_ERROR(m8260_cpm_dpfree(dev_data->dpalloc_base2));
    
  // Free pages used for external CTs
  mm_free_pages((void*) dev_data->etctbase);
  mm_free_pages((void*) dev_data->erctbase);

  // Free DPRAM used for internal CTs
  RETURN_ON_ERROR(m8260_cpm_dpfree(dev_data->dpalloc_base1));
     
  // Free pages used for address lookup
  mm_free_pages((void*) dev_data->slbase);

  // Allow other code to use the region of parameter RAM
  release_region((unsigned long)sar_pram, sizeof(*sar_pram));

  return 0;
}


/*
#########################################################
#
#  Function : mpc8260sar_init
#             
#  Purpose  : Initialises CPM for Esar support.  Does all
#             setups not specific to any one ATM device
#         
#  Returns  : 0 for success
#             
#  Notes    : Called prior to initialisation of any
#             particular ATM device
##########################################################
*/
int mpc8260sar_init(void)
{
  //printk(KERN_INFO "CPM 8260ATM Found Enhanced SAR\n");

  //  RETURN_ON_ERROR(mpc8260sar_set_apc_slot_time(APC_SLOT_TIME_US));

#ifdef CONFIG_ATM_RISCTIMER
    // Enable the CP RISC Timers for a 1millisecond tick
    // (Used for AAL5 timestamping.)
    risc_timer_enable(1000);

    // Find and initialize a rolling RISC Timer for use by 
    // all ATM devices as an AAL5 timestamp
    for (i = 0; i < RISC_TIMER_MAX; ++i) {
	/* Set risc timer period */
	if (risc_timer_set(i, ATM_RISC_TIMEOUT, RT_PERIODIC, 0, "SAR") ==
	    0) {
	    break;		// Successfully set
	}
    }

    // Did we find a risc timer?
    if (i == RISC_TIMER_MAX) {
	printk(KERN_ERR
	       "Could not find available RISC timer for AAL5 timestamper\n");
	return -1;
    }

    timestamp_timer = i;

    // Save the address (offset in DPRAM) of the timestamp timer
    RETURN_ON_ERROR(risc_timer_get_addr(i, &timestamp_timer_addr));
#endif

    // Success
    return 0;
}



/*
#########################################################
#
#  Function : mpc8260sar_init_dev_data
#             
#  Purpose  : Initialises a dev_data_t struct
#             
#  Args     : see comments below
#  Returns  : 0 for success
##########################################################
*/
int mpc8260sar_init_dev_data(dev_data_t * data)
{
    int max_channels = 1 << data->log2_max_channels;
    int num_bytes;
    volatile immap_t *immap = data->immap;
    int num_bytes2;
    
    DINIT_PRINTK(__FUNCTION__ "\n");

    DLPRINTK("mpc8260sar_init_dev_data: data = %p\n", data);

    // Sanity check
    if (data->num_apc_levels < 1 || data->num_apc_levels > MAX_APC_LEVELS) {
	printk(KERN_ERR "Error: (" __FUNCTION__
	       ") num_apc_levels must be between 1 and %d\n",
	       MAX_APC_LEVELS);
	return -EINVAL;
    }

    memset(&(data->apc_overflow), 0, sizeof(data->apc_overflow));

    DLPRINTK("mpc8260sar_init_dev_data:&(data->apc_overflow)=%p\n",
	     &(data->apc_overflow));

    data->min_vc_rate = ATM_VC_MIN_KBPS;
    data->max_vc_rate = ATM_VC_MAX_KBPS;
    data->line_rate_kbps = LINE_RATE_KBPS;
    data->min_channel_byterate = data->min_vc_rate / 8;
    data->max_channel_byterate = data->max_vc_rate / 8;
    data->phy_byterate = data->line_rate_kbps / 8;

    // Initialise the structure that keeps track of channel numbers allocated

    DLPRINTK("mpc8260sar_init_dev_data:&(data->channel_tracker)=%p\n",
	     &(data->channel_tracker));

    intpool_init(&(data->channel_tracker), data->log2_max_channels);

    if ((data->fcc < 1) || (data->fcc > 2)) {
	printk(KERN_ERR "FCC%d cannot be used for ATM\n", data->fcc);
	return -EINVAL;
    }
    data->im_fcc = &immap->im_fcc[data->fcc - 1];
    DLPRINTK("ATM FCC=FCC%d\n", data->fcc);

    if ((data->int_brg < 5) || (data->int_brg > 8)) {
	printk(KERN_ERR "BRG%d cannot be used for internal rate clock\n",
	       data->int_brg);
	return -EINVAL;
    }
    DLPRINTK("ATM INT BRG=BRG%d\n", data->int_brg);

    if ((data->fcc_brg < 5) || (data->fcc_brg > 12)) {
        printk(KERN_ERR "BRG%d cannot be used for the FCC clock\n",
				               data->fcc_brg);
		        return -EINVAL;
			    }
    DLPRINTK("ATM FCC BRG=BRG%d\n", data->fcc_brg);

    data->num_of_priorities = ATM_NUM_PRIORITIES;

    // Initialize the bottom half task queue (scheduled by interrupt handler 
    // when interrupt is a general interrupt i.e. there's a new entry in
    // interrupt queue.)
    data->bh_tq.routine = mpc8260sar_interrupt_bh;
    data->bh_tq.data = data;

    // Allocate an array of cpm_channel_t structs
    // The vcc->dev_data will point to these
    // (Use vmalloc as size may be > PAGE_SIZE and vmalloc does not fragment in this situation)
    data->max_channels = max_channels;
    data->channels =
	(cpm_channel_t *) vmalloc(max_channels * sizeof(cpm_channel_t));

    DLPRINTK("mpc8260sar_init_dev_data:data->channels=%p\n",
	     data->channels);

    if (data->channels == NULL) {
	printk(KERN_ERR __FUNCTION__ " vmalloc failed\n");
	return -ENOMEM;
    }
   
    // PEM - allocate tx and rx bds together 
    // Allocate physically contiguous block of RX Buffer descriptors in external memory 
    num_bytes = data->num_rx_bds * sizeof(atm_rx_cbd_t);	// how much memory do we need
    ROUNDUP_PWR2(num_bytes);	// round up to a power of 2
    num_bytes2 = (data->num_tx_bds + data->num_tx_bds) * sizeof(atm_tx_cbd_t);      // how much memory do we need
    ROUNDUP_PWR2(num_bytes);    // round up to a power of 2
    num_bytes += num_bytes2;
	 
    if (num_bytes > 256 * 1024 * 2)	// Sanity check
    {
	printk(KERN_ERR
	       "Too many rx and tx buffer descriptors requested - CPM limits us to 256KB\n");
	return -EINVAL;
    }
    // Get the pages
    if (!(data->rbdbase =
	 (atm_rx_cbd_t *) mm_alloc_uncached_pages(num_bytes))) {
	printk(KERN_ERR "could not allocate rx buffer descs\n");
	return -ENOMEM;
    }

    DINIT_PRINTK("data->rbdbase=%p\n", data->rbdbase);
	
    // Initialise the mpool object which keeps track of blocks of rx BDs
    mpool_init(&(data->rx_bd_pool), (unchar *) data->rbdbase, num_bytes);

    // Allocate a block of pointers to sk_buffs 
    num_bytes = data->num_rx_bds * sizeof(struct sk_buff *);
    ROUNDUP_PWR2(num_bytes);	// round up to a power of 2
    if (!(data->rx_skbuff = (struct sk_buff **) vmalloc(num_bytes))) {
	printk(KERN_ERR
	       "could not allocate a pool of tx sk_buff pointers\n");
	return -ENOMEM;
    }
    memset(data->rx_skbuff, 0, num_bytes);

    // Initialise the mpool object which keeps track of blocks of sk_buff ptrs
    DLPRINTK("mpc8260sar_init_dev_data:&(data->rx_skbuff_ptr_pool)=%p\n",
	     &(data->rx_skbuff_ptr_pool));
    mpool_init(&(data->rx_skbuff_ptr_pool), (unchar *) data->rx_skbuff,
	       num_bytes);

    // Allocate TX Buffer descriptors in external memory
    num_bytes = data->num_tx_bds * sizeof(atm_tx_cbd_t);	// how much memory do we need
    ROUNDUP_PWR2(num_bytes);	// round up to a power of 2
    if (num_bytes > 256 * 1024)	// Sanity check
    {
	printk(KERN_ERR
	       "Too many tx buffer descriptors requested - CPM limits us to 256KB\n");
	return -EINVAL;
    }

    // PEM - already allocated above
    //if (!
//	(data->tbdbase =
//	 (atm_cbd_t *) mm_alloc_uncached_pages(num_bytes))) {
//	printk(KERN_ERR "could not allocate tx buffer descs\n");
//	return -ENOMEM;
//   }
    data->tbdbase = (atm_tx_cbd_t*)((unsigned char *)data->rbdbase + num_bytes);
    
    // Initialise the mpool object which keeps track of blocks of tx BDs
    mpool_init(&(data->tx_bd_pool), (unchar *) data->tbdbase, num_bytes);

    DINIT_PRINTK("data->tbdbase=%p\n", data->tbdbase);

    // Allocate a block of pointers to sk_buffs 
    num_bytes = data->num_tx_bds * sizeof(struct sk_buff *);
    ROUNDUP_PWR2(num_bytes);	// round up to a power of 2
    if (!(data->tx_skbuff = (struct sk_buff **) vmalloc(num_bytes))) {
	printk(KERN_ERR
	       "could not allocate a pool of tx sk_buff pointers\n");
	return -ENOMEM;
    }
    memset(data->tx_skbuff, 0, num_bytes);

    DLPRINTK("mpc8260sar_init_dev_data:data->tx_skbuff=%p\n",
	     data->tx_skbuff);
    DLPRINTK("mpc8260sar_init_dev_data:&(data->tx_skbuff_ptr_pool)=%p\n",
	     &(data->tx_skbuff_ptr_pool));
    // Initialise the mpool object which keeps track of blocks of sk_buff ptrs
    mpool_init(&(data->tx_skbuff_ptr_pool), (unchar *) data->tx_skbuff,
	       num_bytes);

    // success
    return 0;
}


/*
#########################################################
#
#  Function : mpc8260sar_release_dev_data
#
#  Purpose  : Releases resources used by device
#
#  Args     : data = pointer to device specific data
#  Returns  : 0 for success
##########################################################
*/
int mpc8260sar_release_dev_data(dev_data_t * data)
{
    // Destroy object which keeps track
    // of which blocks of pointers (to tx skbuffs) are allocated
    mpool_destroy(&(data->tx_skbuff_ptr_pool));

    // Free the block of ptrs to tx sk_buffs
    vfree(data->tx_skbuff);

    // Destroy object which keeps track of which TX BDs are allocated
    mpool_destroy(&(data->tx_bd_pool));

    // Free the TX BDs
    // PEM - changed to allocate together with RX BDs
    //RETURN_ON_ERROR(mm_free_pages((int) data->tbdbase));

    // Destroy object which keeps track
    // of which blocks of pointers (to rx skbuffs) are allocated
    mpool_destroy(&(data->rx_skbuff_ptr_pool));

    // Free the block of ptrs to rx sk_buffs
    vfree(data->rx_skbuff);

    // Destroy object which keeps track of which RX BDs are allocated
    mpool_destroy(&(data->rx_bd_pool));

    // Free the RX BDs
    mm_free_pages((void*) data->rbdbase);

    // Free the channels array
    vfree(data->channels);

    // Destroy the structure that keeps track of channel numbers allocated
    intpool_destroy(&(data->channel_tracker));

    // success
    return 0;
}

/*
#########################################################
#
#  Function : mpc8260sar_add_address_mapping
#   
#  Purpose  : Modify the Dual level address tables
#             so rx cells are mapped to the correct RCT
#  Args     : dev = receiving ATM device
#             chanid = channel ID (CPM uses this to derive RCT address)
#             vpi = incoming VPI
#             vci = incoming VCI
#   
#  Returns  : 0 for success
#   
#  Notes    : see page 4-4 of MPC8260 Enhanced SAR
#             functionality supplement
#   
##########################################################
*/
STATIC int
mpc8260sar_add_address_mapping(struct atm_dev *dev, int chanid, ushort vpi,
			       ushort vci)
{
    volatile ulong *entry;	// pointer to entry into 2nd level address table

    // Get the address of the 2nd level table entry corresponding to this dev/vpi/vci
    DLPRINTK(__FUNCTION__ "\n");

    entry = mpc8260sar_get_address_table_entry(dev, vpi, vci);

    // Did we get a match
    if (entry == NULL) {
	// No!
	printk(KERN_ERR "Error: (" __FUNCTION__
	       ") couldn't find match in address table for %d/%d\n", vpi,
	       vci);
	return -1;
    }
    // Got match - write the channel number in the 2nd level address table entry
    *entry = (ulong) chanid;
    DLPRINTK("Entry Address = %p\n", entry);
    DPRINTK(__FUNCTION__ " adding mapping %d/%d->%lx\n", vpi, vci, *entry);

    // success
    return 0;
}

/*
#########################################################
#
#  Function : mpc8260sar_del_address_mapping
#   
#  Purpose  : removes an entry from the Dual level address
#             matching table
#   
#  Args     : dev = receiving device
#             vpi = VPI
#             vci = VCI
#   
#  Returns  : 0 for success
#   
#  Notes    : see page 4-4 of MPC8260 Enhanced SAR
#             functionality supplement
#   
##########################################################
*/
STATIC int
mpc8260sar_del_address_mapping(struct atm_dev *dev, ushort vpi, ushort vci)
{
    volatile ulong *entry;	// pointer to entry into 2nd level address table

    // Get the address of the 2nd level table entry corresponding to this dev/vpi/vci
    entry = mpc8260sar_get_address_table_entry(dev, vpi, vci);

    // Did we get a match
    if (entry == NULL) {
	// No!
	printk(KERN_ERR "Error: (" __FUNCTION__
	       ") couldn't find match in address table for %d/%d\n", vpi,
	       vci);
	return -1;
    }
    // Got match - point the dev/VPI/VCI at the raw cell queue (channel 0)
    *entry = 0;

    // success
    return 0;
}


/*
#########################################################
#
#  Function : mpc8260sar_interrupt_bh
#   
#  Purpose  : Bottom half handler for General INTerrupts.
#             Reads and deals with one interrupt q entry.
#  Args     : ptr to dev->dev_data
#   
#  Notes    : Queued by interrupt handler for interrupts
#             on each device, and executed when
#             the kernel feels like it.
#   
#########################################################
*/
void mpc8260sar_interrupt_bh(void *param)
{
    dev_data_t *dev_data = (dev_data_t *) param;
    ushort status;
    ushort chnum;
    int j;
    
    DINT_PRINTK(__FUNCTION__ "\n");

    /* see 8260 UM section 29.11.1 */

    while (1) {
      for(j=0; j<ATM_INT_QUEUES; j++){	    
	status = dev_data->intptr[j]->status;
	chnum = dev_data->intptr[j]->chnum;

	DXMIT_PRINTK("intptr=%p,status=%x,chnum=%x\n", dev_data->intptr[j],
		     status, chnum);

#ifdef DEBUG_LOW
	{
	  ulong *tmp =
	    (ulong *) (dev_data->sar_pram->atm.IntQParamBase + IMAP_ADDR);
	  tmp++;
	  DLPRINTK("Hardware Pointer = %lx\n", *tmp);
	}
#endif

	// Make sure the interrupt is valid
	if (!(status & INTR_V)) {
	    return;		
	}
	
	// Clear the interrupt queue entry
	// The INTR_W bit must always be preserved!
	dev_data->intptr[j]->status = status & INTR_W;
	dev_data->intptr[j]->chnum = 0;

	// advance queue pointer, checking for wrap 
	if (status & INTR_W) {
	    dev_data->intptr[j] = dev_data->intbase[j];
	} else {
	    dev_data->intptr[j]++;
	}

	if (status & INTR_TBNR) {
	    printk(KERN_DEBUG "Tx buffer-not-ready\n");
	}

	// Is this a valid receive interrupt ?
	if (status & (INTR_RXF | INTR_RXB)) {
	    mpc8260sar_rx_bh(dev_data, chnum);
	}

	// Is this a transmit complete interrupt ?
	if (status & INTR_TXB) {
	    mpc8260sar_tx_bh(dev_data, chnum);
	}

	if (status & INTR_BSY) {
	    //printk(KERN_WARNING "INTR_BSY\n");
            dev_data->rx_errors.bsy++;
            // the 860 driver disables the channel for 1 sec here		
	}

	if (!(status &
	     (INTR_TBNR | INTR_RXF | INTR_RXB | INTR_TXB | INTR_BSY))) {
	    printk(KERN_ERR "unknown interrupt: status=%x,chnum=%x\n",
		   status, chnum);
	}
      }
    }
}

/*
#########################################################
#
#  Function : mpc8260sar_tx_bh
#
#  Purpose  : bottom half handler for tx
#
#  Args     : dev_data=device data pointer
#             chanid=channel
#
#  Notes    : called by bottom half handler after it's
#             read an entry with TXB set
##########################################################
*/
STATIC void mpc8260sar_tx_bh(dev_data_t * dev_data, int chanid)
{
    cpm_channel_t *chan;
    volatile atm_tx_cbd_t *bdp;
    struct sk_buff *skb;
    int i;
    int last;
	
    DXMIT_PRINTK(__FUNCTION__ "\n");

    // Sanity check: we should never get a tx GINT on Raw Cell Queue
    if (chanid == 0) {
	printk(KERN_ERR "Error: tx GINT on RCQ!\n");
	return;
    }
    // Get the channel structure (note that channel numbers are allocated
    // starting at NUM_INT_CONN_TABLES.  This is because we do not have
    // space in DPRAM for 32 connection tables for each device)
    chan = &(dev_data->channels[chanid]);

    // Scan BDs between tbase[tx_tail] and tbase[tx_head]
    // (This is where all the unhandled sent BDs will be)
    last = chan->tx_ring_size - 1;
    i = chan->tx_tail;
    bdp = &(chan->tbase[i]);
    DXMIT_PRINTK("Address of the next BD = %p\n", bdp);

    while (i != chan->tx_head) {
	DXMIT_PRINTK("Tx_tail = %x, Tx_head = %x\n", i, chan->tx_head);
	DXMIT_PRINTK("TxBD status = %x\n", bdp->cbd_sc);
	// Is this buffer waiting to be transmitted
	if (bdp->cbd_sc & TX_BD_R)
	    break;		// Yes: wait until the CPM has transmitted it then.

	// Is this buffer currently unused - i.e. no skb
	if ((skb = chan->tx_skbuff[i]) == NULL) {
	    // Shouldn't happen
	    printk(KERN_ERR "Error: (" __FUNCTION__
		   ") CPM indicated buffer sent but no skb present\n");
	    break;
	}
	// If we reach here, we have found a socket buffer that
	// exists in the TX ring and is waiting to be released.
	mpc8260sar_free_tx_skb(skb);

	// Update channel stats
	atomic_inc(&chan->vcc->stats->tx);

	switch (chan->aal) {
	case ATM_AAL0:
	    atomic_inc(&chan->dev->stats.aal0.tx);
	    break;
	case ATM_AAL5:
	    atomic_inc(&chan->dev->stats.aal5.tx);
	    break;

	case ATM_AAL34:
	    atomic_inc(&chan->dev->stats.aal34.tx);
	    break;

	default:
	    break;
	}

	// Release skb buffer from TX ring
	chan->tx_skbuff[i] = NULL;

	// A cell has been transmitted successfully
	// so Mark this channel as available for TX
	// i.e. there is at least one available
	// transmit slot
	chan->tbusy = 0;

	// Point i and bdp at the next BD in ring
	if (i < last) {
	    i++;
	    bdp++;
	} else {
	    i = 0;
	    bdp = chan->tbase;
	}
    }

    // Move the tail forward
    chan->tx_tail = i;

}

/*
#########################################################
#
#  Function : mpc8260sar_close_rx_channel
#
#  Purpose  : frees the socket buffers associated with
#             an rx channel
#  Args     : chan points to cpm_channel_t struct associated with channel
#
##########################################################
*/
STATIC void mpc8260sar_close_rx_channel(cpm_channel_t * chan)
{
    unsigned int i;
    struct atm_dev *dev = chan->dev;
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;

    // Yes, so free socket buffers allocated in the RX ring
    for (i = 0; i < chan->rx_ring_size; ++i) {
	// Make sure there is a socket buffer allocated
	if (chan->rx_skbuff[i] != NULL) {
	    // Free RX ring socket buffer
	    dev_kfree_skb(chan->rx_skbuff[i]);
	} else {
	    printk(KERN_ERR
		   "Error: Attempting to de-allocate RX socket buffer\n");
	}
    }

    // Free the array of rx BDs used by this channel
    mpool_free(&(dev_data->rx_bd_pool), (unchar *) chan->rbase,
	       chan->rx_ring_size * sizeof(atm_rx_cbd_t));

    // Free the array of rx skbuff ptrs used by this channel
    mpool_free(&(dev_data->rx_skbuff_ptr_pool), (unchar *) chan->rx_skbuff,
	       chan->rx_ring_size * sizeof(struct sk_buff *));
}

/*
#########################################################
#
#  Function : mpc8260sar_close_tx_channel
#
#  Purpose  : keeps track of total_tx_byte_rate for ATM
#             device and deactivates channel
#  Args     : chan points to cpm_channel_t struct associated with channel
#
##########################################################
*/
STATIC void mpc8260sar_close_tx_channel(cpm_channel_t * chan)
{
    int i;
    struct sk_buff *skb;
    struct atm_dev *dev = chan->dev;
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    
    DXMIT_PRINTK(__FUNCTION__ "\n");

    // Send a disable command to CPCR
    mpc8260sar_tx_channel(dev, CPM_CHAN_DISABLE, chan);

    if (chan->vcc->qos.txtp.traffic_class == ATM_CBR) {
	// Yes so decrement the total bandwidth used
	dev_data_t *dev_data = (dev_data_t *) chan->dev->dev_data;
	dev_data->total_tx_byte_rate -= chan->tx_byte_rate;
    }
    // Scan through all TX bd's and cleanup
    for (i = 0; i < chan->tx_ring_size; ++i) {
	// Is this buffer currently unused - i.e. no skb
	if ((skb = chan->tx_skbuff[i]) == NULL) {
	    // Yes, so ignore it
	    continue;
	}
	// If we reach here, we have found a socket buffer that
	// exists in the TX ring and is waiting to be released.
	printk(KERN_WARNING "Discarding unsent tx sk_buff\n");

	mpc8260sar_free_tx_skb(chan->tx_skbuff[i]);
	atomic_inc(&chan->vcc->stats->tx_err);
	switch (chan->aal) {
	case ATM_AAL0:
	    atomic_inc(&chan->dev->stats.aal0.tx_err);
	    break;
	case ATM_AAL5:
	    atomic_inc(&chan->dev->stats.aal5.tx_err);
	    break;
	case ATM_AAL34:
	    atomic_inc(&chan->dev->stats.aal34.tx_err);
	    break;
	default:
	    break;
	}

    }

    // Free the array of tx BDs used by this channel
    mpool_free(&(dev_data->tx_bd_pool), (unchar *) chan->tbase,
	       chan->tx_ring_size * sizeof(atm_tx_cbd_t));

    // Free the array of tx skbuff ptrs used by this channel
    mpool_free(&(dev_data->tx_skbuff_ptr_pool), (unchar *) chan->tx_skbuff,
	       chan->tx_ring_size * sizeof(struct sk_buff *));
}



/*
#########################################################
#
#  Function : mpc8260sar_tx_channel
#
#  Purpose  : Enables or disables a tx channel by writing
#             command to CPCR
#
#  Args     : dev = ptr to atm_dev device
#             chan = ptr to the channel in question
#             ctrl = CPM_CHAN_ENABLE or anything else to disable
#
#  Notes    : Sends a command to the Communications Processor
#             Command Register (CPCR)
#             This function assumes when ctrl = CPM_CHAN_ENABLE
#             that the channel is not currently present in the
#             APC scheduling table.  This is important for
#             otherwise we'd end up with two or more entries
#             pertaining to the same channel.
#             To ensure that this is the case, this function
#             waits for the channel to be removed from the
#             APC scheduling table when ctrl = CPM_CHAN_DISABLE
#             before exiting
#
##########################################################
*/
STATIC void
mpc8260sar_tx_channel(struct atm_dev *dev, CPM_CHAN_CTRL ctrl,
		      cpm_channel_t * chan)
{
    unsigned long flags;
    spinlock_t my_lock = SPIN_LOCK_UNLOCKED;
    volatile cpm8260_t *cp = cpmp;
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    volatile sar8260_pram_t *sar_pram = dev_data->sar_pram;
    //int cbr = (chan->vcc->qos.txtp.traffic_class == ATM_CBR);
    int fcc = dev_data->fcc;

    DXMIT_PRINTK(__FUNCTION__ "\n");

    // Name the tx channel
    sar_pram->atm.Channel_num = chan->number;

    spin_lock_irqsave(&my_lock, flags);

    // Wait for other previous command to clear
    mpc8260_cmd_wait(__FUNCTION__, __LINE__);
    /* while (cp->cp_cpcr & CPM_CR_FLG)
       ; */

    // Send the command
    switch(ctrl){
      case CPM_CHAN_ENABLE:
	// Write channel activate command to CPM command register
	cp->cp_cpcr = mk_cr_cmd((CPM_CR_FCC1_PAGE + (fcc - 1)),
				CPM_CR_ATM_SBLOCK,
				FCC_GFMR_MODE_ATM,
				CPM_CR_INIT_TX) | CPM_CR_FLG;
	break;

      case CPM_CHAN_DISABLE:
	// Write channel deactivate command to CPM command regsiter
	cp->cp_cpcr = mk_cr_cmd((CPM_CR_FCC1_PAGE + (fcc - 1)),
				CPM_CR_ATM_SBLOCK,
				FCC_GFMR_MODE_ATM,
				CPM_CR_STOP_TX) | CPM_CR_FLG;
	chan->tctptr->tx_bd_base |= TCT_STPT;
	break;

      case CPM_CHAN_ATM_TX:
	cp->cp_cpcr = mk_cr_cmd((CPM_CR_FCC1_PAGE + (fcc - 1)),
				CPM_CR_ATM_SBLOCK,
				FCC_GFMR_MODE_ATM,
				CPM_CR_ATM_TX) | CPM_CR_FLG;
	break;

      default:
	printk(KERN_ERR "Error: (" __FUNCTION__ ") invalid argument\n");
	return;
    }

    // Wait for acknowledgement before writing another command to CPCR register
    /* while (cp->cp_cpcr & CPM_CR_FLG)
       ; */
    mpc8260_cmd_wait(__FUNCTION__, __LINE__);
    spin_unlock_irqrestore(&my_lock, flags);

    if (ctrl == CPM_CHAN_DISABLE) {
	volatile int timetowaste = 1;

	// Wait for the OUT bit to clear
	// (this indicates that the channel has been
	// removed from the APC sheduling table)
	while (chan->tctptr->tct_status & TCT_VCON) {
	    // We don't want the CPU to constantly be
	    // reading the DPRAM as this would slow down
	    // the CPM.  So we waste some time
	    // before we check the TCT_OUT bit again.
	    volatile int timewasted;

	    // Waste some time
	    for (timewasted = 0; timewasted < timetowaste; timewasted++);

	    // Waste 50% more time next time
	    timetowaste += (timetowaste + 1) / 2;

	    // Sanity check to prevent infinite loop
	    if (timetowaste > 1000000) {
		printk(KERN_ERR
		       "Channel deactivate command sent but TCT[VCON] not clearing\n");
		break;
	    }
	}
    }
}


/*
#########################################################
#
#  Function : mpc8260sar_rx_channel
#
#  Purpose  : Enables or disables an rx channel for reception
#
#  Args     : dev = ptr to atm_dev device
#             chan = ptr to the channel in question
#             ctrl = CPM_CHAN_ENABLE or anything else to disable
#
#  Notes    : Sends a command to the Communications Processor
#             Command Register (CPCR)
#
##########################################################
*/
STATIC void
mpc8260sar_rx_channel(struct atm_dev *dev, CPM_CHAN_CTRL ctrl,
		      cpm_channel_t * chan)
{
    volatile cpm8260_t *cp = cpmp;
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    int fcc = dev_data->fcc;

    DINIT_PRINTK(__FUNCTION__ "\n");

    // Specify the channel to invoke the command on
    dev_data->sar_pram->atm.Channel_num = chan->number;

    // Wait for other previous command to clear
    mpc8260_cmd_wait(__FUNCTION__, __LINE__);

    // Is this a enable or disable request
    if (ctrl == CPM_CHAN_ENABLE) {
	// Invoke activate channel (for reception) command
	cp->cp_cpcr = mk_cr_cmd((CPM_CR_FCC1_PAGE + (fcc - 1)),
				CPM_CR_ATM_SBLOCK,
				FCC_GFMR_MODE_ATM,
				CPM_CR_INIT_RX) | CPM_CR_FLG;
    } else {
	// Invoke de-activate channel command
	cp->cp_cpcr = mk_cr_cmd((CPM_CR_FCC1_PAGE + (fcc - 1)),
				CPM_CR_ATM_SBLOCK,
				FCC_GFMR_MODE_ATM,
				CPM_CR_STOP_RX) | CPM_CR_FLG;
    }

    // Wait for acknowledgement from CPM
    mpc8260_cmd_wait(__FUNCTION__, __LINE__);

    dev_data->im_fcc->fcc_gfmr |= 0x00000020;	// Enable receive
}


/*
#########################################################
#
#  Function : mpc8260sar_rx_bh
#
#  Purpose  : bottom half handler for rx
#
#  Args     : dev=device pointer
#             chanid=channel
#
#  Notes    : called by bottom half handler after it's
#             read an entry with RXB | RXF set
##########################################################
*/
STATIC void mpc8260sar_rx_bh(dev_data_t * dev_data, int chanid)
{
    volatile atm_rx_cbd_t *bdp;
    struct sk_buff *skb;
    struct sk_buff *newskb;
    ushort pkt_len;
    ushort rx_stat;
    int bdindex;
    cpm_channel_t *chan;
    unchar aal;
    ushort newskblen;
    struct atm_vcc *vcc;
    ushort reception_error = 0;

    DRECV_PRINTK(__FUNCTION__ "\n");

    // Get the channel structure (note that channel numbers are allocated
    // starting at NUM_INT_CONN_TABLES.  This is because we do not have
    // space in DPRAM for 32 connection tables for each device)
    if (chanid == 0)		// Raw Cell Queue
	chan = &(dev_data->rcq_chan);
    else
	chan = &(dev_data->channels[chanid]);

    // Get AAL and length of new socket buffer to allocate
    aal = chan->aal;
    newskblen = ((aal == ATM_AAL5) ? AAL5_BUFLEN : MIN_CPM_BUFSZ);

    // Toggle RD_BAR (of CB) to indicate reception
    // mpc8260sar_phy_cb_toggle_rd_bar();
    // Loop until all received skbs have been processed
    for (;;) {
	DRECV_PRINTK("chanid=%d\n", chanid);

	// Get the buffer descriptor index from the tail of the queue
	bdindex = chan->rx_tail;

	DRECV_PRINTK("Reception on RX BD %u\n", bdindex);

	// Get the BD associated with this index
	bdp = &(chan->rbase[bdindex]);

	DRECV_PRINTK("bdp=%p\n", bdp);

	//spin_lock_irq(&dev_data->lock); SPIN

	// PEM - too early to print here
	//DRECV_PRINTK("rx_stat=%04x\n", rx_stat);

	// Is there a reception waiting ?
	if ((rx_stat = bdp->cbd_sc) & RX_BD_E) {
	    // No, so return for BH
	    return;
	}

	DRECV_PRINTK("rx_stat=%04x\n", rx_stat);
	
	// Get a new skb to replace the one just consumed
	if (!(newskb = mpc8260sar_alloc_skb(newskblen))) {
	    printk(KERN_ERR "no rx socket buffers, dropping packet\n");

	    // Return here so we don't get out of sync w/cpm
	    return;
	}
	// We found a bd with data, bump the tail index
	chan->rx_tail++;

	if (chan->rx_tail >= chan->rx_ring_size) {
	    bdp->cbd_sc = RX_BD_I | RX_BD_W;
	    chan->rx_tail = 0;
	} else {
	    bdp->cbd_sc = RX_BD_I;
	}

	// Make sure there is a skb assigned
	if (chan->rx_skbuff[bdindex] == NULL) {
	    printk(KERN_ERR
		   "no socket buffer assigned to chan->rx_skbuff[%d]\n",
		   bdindex);
	    return;
	}
	// Get the received socket data buffer
	skb = chan->rx_skbuff[bdindex];

	// Replace the socket buffer
	chan->rx_skbuff[bdindex] = newskb;

	// Get length of received data from skb
	pkt_len = (aal == ATM_AAL5) ? bdp->cbd_datlen : ATM_AAL0_SDU;

	// Make sure the buffer is burst aligned
	if (__pa(newskb->data) & (ulong) 0x0000000f) {
	    printk(KERN_ERR "receive buffer not burst aligned!\n");
	}
	// Set the physical address of the new socket buffer
	bdp->cbd_bufaddr = __pa(newskb->data);

	// Mark ready to receive data
	bdp->cbd_sc |= RX_BD_E;

	// Is this a valid reception - i.e. not on the raw cell queue?
	if (chanid == 0) {
	    //printk(KERN_WARNING "buffer recvd on chan 0\n");
	    goto bad_skb;
	}
	// This is not the raw cell queue, so there is a vcc
	// associated with it....
	vcc = chan->vcc;

	// Were there any reception errors?
	if (aal == ATM_AAL5) {
	    reception_error = (rx_stat) &
		(RX_BD_CRE_AAL5 | RX_BD_LNE_AAL5 | RX_BD_ABRT_AAL5 |
		 RX_BD_CNG_AAL5);
	}
	if (aal == ATM_AAL0) {
	  /* wei-sun */
	    reception_error = rx_stat & RX_BD_CRE;
	}
	// Was there a reception error ???
	if (reception_error) {
	    printk(KERN_WARNING "(utopia) ATM cell reception error\n");
	    atomic_inc(&vcc->stats->rx_err);
	    switch (chan->aal) {
	    case ATM_AAL0:
		atomic_inc(&chan->dev->stats.aal0.rx_err);
		break;
	    case ATM_AAL5:
		atomic_inc(&chan->dev->stats.aal5.rx_err);
		break;
	    case ATM_AAL34:
		atomic_inc(&chan->dev->stats.aal34.rx_err);
		break;
	    default:
		break;
	    }

	    goto bad_skb;
	}

	if (pkt_len > skb->end - skb->tail) {
	    printk(KERN_WARNING "dropped over-size (%u) frame\n", pkt_len);
	    // Should we count this? Or is rx_drop just for buffer exhaustion drops?
	    atomic_inc(&vcc->stats->rx_drop);
	    switch (chan->aal) {
	    case ATM_AAL0:
		atomic_inc(&chan->dev->stats.aal0.rx_drop);
		break;
	    case ATM_AAL5:
		atomic_inc(&chan->dev->stats.aal5.rx_drop);
		break;
	    case ATM_AAL34:
		atomic_inc(&chan->dev->stats.aal34.rx_drop);
		break;
	    default:
		break;
	    }
	    goto bad_skb;
	}

	if (!atm_charge(vcc, skb->truesize)) {
	    printk(KERN_WARNING
		   "dropped thanks to atm_charge (chanid=%d)\n", chanid);
	    // drop stats incremented in atm_charge
	    goto bad_skb;
	}

	if ((aal == ATM_AAL5) &&
	    ((rx_stat & (RX_BD_L | RX_BD_F)) != (RX_BD_L | RX_BD_F))) {
	    printk(KERN_WARNING "aal5 frame too big for rx buffer\n");
	    atomic_inc(&vcc->stats->rx_drop);
	    goto bad_skb;
	}
	// BD passed all sanity checks!

	//  Add received length to socket buffer
	skb_put(skb, pkt_len);

	// VC layer stats
	atomic_inc(&vcc->stats->rx);
	skb->stamp = xtime;

	// Point socket buffer at the right VCC before giving to socket layer
	ATM_SKB(skb)->vcc = vcc;
	// push socket buffer up to ATM layer
	vcc->push(vcc, skb);

	// Reception complete so go round again!
	continue;

      bad_skb:
	// Free this socket buffer - do nothing with it!
	dev_kfree_skb(skb);

	// Reception complete so go round again!
	continue;
    }
}

/*
#########################################################
#
#  Function : mpc8260sar_pcr_to_byterate
#
#  Purpose  : calculates actual byterate to allocate chan-
#             nel in terms of requested PCR.
#
#  Args     : pcr = requested PCR.
#             chan_byterate = ptr to returned actual byterate.
#             dev = device on which we're txing
#
#  Returns  : 0 for success
#
#  Notes    : Will fail if not enough bandwith left on dev.
#             Adjusts byterate up if PCR is lower than
#             minimum possible to configure.
#
##########################################################
*/
STATIC int
mpc8260sar_pcr_to_byterate(struct atm_dev *dev, int pcr,
			   ulong * chan_byterate)
{
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    ulong chan_byterate_local;

    // Validate requested rates for CBR
    if (pcr <= 0) {
	printk(KERN_NOTICE "Error: invalid CBR cell rate\n");
	return -EINVAL;
    }
    // Calculate requested PCR as PBR (peak byte rate)
    if ((chan_byterate_local =
	 (pcr * 53)) > dev_data->max_channel_byterate) {
//	printk(KERN_NOTICE
//	       "Error: requested CBR PCR byterate %ld exceeds APC maximum byterate %ld\n",
//	       chan_byterate_local, dev_data->max_channel_byterate);
//	return -EINVAL;
	    //	PEM - temp debug
	chan_byterate_local = dev_data->max_channel_byterate;
  }
    // Round up if below the minimum byte rate allowable on this ATM device
    if (chan_byterate_local < dev_data->min_channel_byterate)
	chan_byterate_local = dev_data->min_channel_byterate;

    // Make sure there is sufficient bandwidth
    if ((dev_data->total_tx_byte_rate + chan_byterate_local) >
	dev_data->phy_byterate) {
	printk(KERN_NOTICE "Error: CBR bandwidth %ld bytes/s exceeded\n",
	       dev_data->phy_byterate);
	return -EINVAL;
    }

    DOPENCLOSE_PRINTK(__FUNCTION__ ": total_tx_byte_rate %lu\n",
		      dev_data->total_tx_byte_rate);

    // Keep a running total of allocated bandwidth (for CBR channels)
    dev_data->total_tx_byte_rate += chan_byterate_local;

    // Return the actual byte rate
    DOPENCLOSE_PRINTK("Setting CBR PCR (byterate) to %ld\n",
		      chan_byterate_local);
    *chan_byterate = chan_byterate_local;

    // (Debug) what's the new total?
    DOPENCLOSE_PRINTK(__FUNCTION__ ": total_tx_byte_rate %lu\n",
		      dev_data->total_tx_byte_rate);

    // Success CBR configured
    return 0;
}

/*
#########################################################
#
#  Function : mpc8260sar_init_tx_channel
#
#  Purpose  : Initialise the TCT, the BD ring, and vcc->dev_data
#
#  Args     : vcc = pointer to vcc struct
#             chan = ptr to channel to be initialised
#  Returns  : 0 for success
#
#  Notes    :
#
##########################################################
*/
STATIC int
mpc8260sar_init_tx_channel(struct atm_vcc *vcc, cpm_channel_t * chan)
{
    struct atm_dev *dev = vcc->dev;
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    struct atm_qos *qos = &(vcc->qos);
    volatile atm_tx_cbd_t *bdp;
    int result, i;

    DXMIT_PRINTK(__FUNCTION__ "\n");

    // Disable transmit interrupts
    chan->tctptr->tx_bd_base &= ~(TCT_BNM | TCT_IMK);

    // Mark tx channel as busy until initialisation of channel is complete
    chan->tbusy = 1;

    if (qos->aal == ATM_AAL5) {
	// This is an AAL5 transmission

	// Configure receive connection entry as AAL5
	chan->tctptr->tct_status |= TCT_BO_BE | TCT_GBL;
	chan->tctptr->tct_status |= TCT_AAL5;

    } else if (qos->aal == ATM_AAL0) {
	// This is an AAL0 transmission
	// Configure transmit connection entry as AAL0 and
	// disable CRC10 generatation on AAL0 payload
      /* wei-sun */
	chan->tctptr->tct_status = TCT_BO_BE | TCT_GBL | TCT_AAL0;
    } else {
	printk(KERN_ERR "Error: (" __FUNCTION__ ") unknown AAL\n");
	return -EINVAL;
    }

    // Init to 0x0 to indicate an idle channel
    chan->tctptr->apc_linked_channel = 0x0;

    // If this is a CBR channel determine PCR
    if (vcc->qos.txtp.traffic_class == ATM_CBR) {
	// Calculate the required byte rate
	if ((result =
	     mpc8260sar_pcr_to_byterate(dev, vcc->qos.txtp.max_pcr,
					&(chan->tx_byte_rate)))) {
	    // Transmission rate is invalid
	    printk(KERN_INFO
		   "error: requested transmission rate is invalid\n");
	    return result;
	}

	DXMIT_PRINTK
	    ("setting tservice to CBR/UBR and disabling Auto VC off\n");

	// calculate the apcp and apcpf
	//mpc8260sar_byterate_to_apcp(0,chan->tx_byte_rate, &apcp, &apcpf);

	chan->tctptr->pcr_fraction = 0xF;
	chan->tctptr->pcr = 0xF;

	// Disable auto-VC-off (see mpc8260 ESAR supplement pg 5-8)
	// AJZ TODO need to change the initialisation of this if we do performance monitoring
	chan->tctptr->tct_status &= ~TCT_AVCF;

	//DXMIT_PRINTK("done\n");
    } else if (vcc->qos.txtp.traffic_class == ATM_UBR) {
	// Set the byte rate to the maximum for this ATM port (CBR will still take
	// priority as UBR channels will be scheduled in the level 2 APC table)
	chan->tx_byte_rate = dev_data->max_channel_byterate;
	DXMIT_PRINTK("tx_byte_rate = %lu\n", chan->tx_byte_rate);
	DXMIT_PRINTK
	    ("setting tservice to CBR/UBR and enabling Auto VC off\n");
	// calculate the apcp and apcpf
	//mpc8260sar_byterate_to_apcp(0 ,chan->tx_byte_rate, &apcp, &apcpf);

	// Set the type of service to CBR/UBR and set APC Pace rate, and set APC Pace fraction
	chan->tctptr->pcr_fraction = dev_data->peek_cell_rate_fraction;
	chan->tctptr->pcr = dev_data->peek_cell_rate;
	//chan->tctptr->tct_status |= TCT_AVCF;
	chan->tctptr->tct_status &= ~TCT_AVCF;

	//	chan->tctptr->tct_status |= TCT_VCON;
	DXMIT_PRINTK("done\n");
    } else {
	printk(KERN_ERR "Error: (" __FUNCTION__
	       ") unknown traffic class\n");
	return -EINVAL;
    }

    // Allocate base address for TX buffer descriptors
    chan->tx_ring_size = dev_data->tx_ring_size;

    DXMIT_PRINTK("mpool_alloc(&(dev_data->tx_bd_pool),%d)\n",
		 chan->tx_ring_size * sizeof(atm_tx_cbd_t));

    chan->tbase = (volatile atm_tx_cbd_t *)
	mpool_alloc(&(dev_data->tx_bd_pool),
		    chan->tx_ring_size * sizeof(atm_tx_cbd_t));
    if (chan->tbase == NULL) {
	printk(KERN_ERR "no tx bds available\n");
	return -ENOMEM;
    }
    // Clear the BDS
    memset((void *) chan->tbase, 0,
	   chan->tx_ring_size * sizeof(atm_tx_cbd_t));

    DXMIT_PRINTK("chan->tbase=%p\n", chan->tbase);

    chan->tctptr->tx_bd_offset = 0;

    // Initialise the pointer to the array of sk_buff ptrs
    chan->tx_skbuff = (struct sk_buff **)
	mpool_alloc(&(dev_data->tx_skbuff_ptr_pool),
		    chan->tx_ring_size * sizeof(struct sk_buff *));
    if (chan->tx_skbuff == NULL) {
	printk(KERN_ERR "no tx skbuff ptrs available\n");
	return -ENOMEM;
    }
    // Initially point them all at NULL
    memset(chan->tx_skbuff, 0,
	   chan->tx_ring_size * sizeof(struct sk_buff *));

    // Synchronize the local state machine with the CPM
    chan->tx_tail = chan->tx_head = 0;

    // Initialize the TX Buffer Descriptor Ring
    bdp = chan->tbase;

    for (i = 0; i < chan->tx_ring_size; ++i, ++bdp) {
	bdp->cbd_sc = 0;

	// No pointers yet
	bdp->cbd_bufaddr = 0;

	// Is this the last BD in the ring
	if (i == (chan->tx_ring_size - 1)) {
	    // Yes, so set the W bit
	    bdp->cbd_sc |= TX_BD_W;
	}
	// Is there a socket buffer already allocated
	if (chan->tx_skbuff[i] != NULL) {
	    // Free tx skb
	    printk(KERN_ERR
		   "Discovered tx sk_buff not freed by old channel\n");
	    mpc8260sar_free_tx_skb(chan->tx_skbuff[i]);

	    // Unallocate for ring
	    chan->tx_skbuff[i] = NULL;

	    // Count number dropped !
	    atomic_inc(&vcc->stats->tx_err);
	}
    }

    // Put Buffer Pointer into TCT
    chan->tctptr->p_tx_data = 0;

    // Enable transmit interrupts
    chan->tctptr->tx_bd_base = __pa(chan->tbase);
    chan->tctptr->tx_bd_base |= (TCT_BNM | TCT_IMK);


    // TX not longer busy
    chan->tbusy = 0;

    DXMIT_PRINTK("leaving " __FUNCTION__ "\n");

    // Success
    return 0;
}


/*
#########################################################
#
#  Function : mpc8260sar_init_rx_channel
#
#  Purpose  : Initialise the RCT, the BD ring, and chan
#
#  Args     :
#             chan = ptr to channel structure
#  Returns  : 0 for success
#
#  Notes    : Does not allocate any buffers
#
##########################################################
*/
STATIC int mpc8260sar_init_rx_channel(cpm_channel_t * chan)
{
    dev_data_t *dev_data = (dev_data_t *) chan->dev->dev_data;
    volatile atm_rx_cbd_t *bdp;
    ulong offset;
    volatile int i;

    DLPRINTK(__FUNCTION__ "\n");

    DLPRINTK("chan->tctptr=%p\n", chan->tctptr);

    // Disable all interrupts
    dev_data->im_fcc->fcc_gfmr &= ~0x00000020;	// Disable receive 
    chan->rctptr->StatusMask &= (~RCT_RXBUF_INTR & RCT_AAL5_RXFM_INTR);

    /* wei-sun */
    if (chan->aal == ATM_AAL5)
    {
        // Configure receive connection entry as AAL5
        chan->rctptr->StatusMask &= (~RCT_RXBUF_INTR & RCT_AAL5_RXFM_INTR) ;
        chan->rctptr->rct_status = RCT_AAL5 | RCT_BO_BE | RCT_GBL;
        chan->rctptr->Mrblr = AAL5_BUFLEN;
    }
    else
    {
        // Configure receive connection entry as AAL0 and
        // disable CRC10 checking on AAL0 payload
        chan->rctptr->StatusMask &= ~RCT_RXBUF_INTR ;
        chan->rctptr->rct_status = RCT_AAL0 | RCT_BO_BE | RCT_GBL;
        chan->rctptr->prot_spec_rct.aal0.status_bits = 0x00400;
    }

    // Allocate base address for this channel's RX buffer descriptors
    if (chan->number == 0)
	chan->rx_ring_size = dev_data->rcq_rx_ring_size;	// Raw Cell Queue
    else
	chan->rx_ring_size = dev_data->rx_ring_size;	// Ordinary RX channel

    DLPRINTK("mpool_alloc(&(dev_data->rx_bd_pool),%d)\n",
	     chan->rx_ring_size * sizeof(atm_rx_cbd_t));

    chan->rbase = (volatile atm_rx_cbd_t *)
	mpool_alloc(&(dev_data->rx_bd_pool),
		    chan->rx_ring_size * sizeof(atm_rx_cbd_t));
    if (chan->rbase == NULL) {
	printk(KERN_ERR "no rx bds available\n");
	return -ENOMEM;
    }
    // Clear the BDS
    memset((void *) chan->rbase, 0,
	   chan->rx_ring_size * sizeof(atm_rx_cbd_t));

    DLPRINTK("chan->rbase=%p\n", chan->rbase);
    DLPRINTK("Size of RCT = %d\n", sizeof(rx_conn_table_t));

    offset = (ulong) chan->rbase;
    offset -= (ulong) dev_data->rbdbase;
    offset >>= 2;

    chan->rctptr->rx_bd_offset = 0;	//initialize to 0 CP controls it

    DLPRINTK("dev_data->rbdbase=%p\n", dev_data->rbdbase);

    // rbd_ptr is the offset from dev_data->rbdbase to the current
    // buffer descriptor in the vpi/vci's ring
    // The actual address of the current BD in the list
    // is (rbd_ptr*4)+dev_data->rbdbase
    // It must be initialized to the same value as rbase
    chan->rctptr->RxBdBase = __pa(chan->rbase);
    DLPRINTK("chan->rctptr->RxBdBase =%lx\n", chan->rctptr->RxBdBase);

#ifdef DEBUG_PRINT_ALL
    print_table((void *) chan->rctptr);
#endif

    // Initialise the pointer to the array of sk_buff ptrs
    chan->rx_skbuff = (struct sk_buff **)
	mpool_alloc(&(dev_data->rx_skbuff_ptr_pool),
		    chan->rx_ring_size * sizeof(struct sk_buff *));
    if (chan->rx_skbuff == NULL) {
	printk(KERN_ERR "no rx skbuff ptrs available\n");
	return -ENOMEM;
    }
    // Initially point them all at NULL
    memset(chan->rx_skbuff, 0,
	   chan->rx_ring_size * sizeof(struct sk_buff *));

    // Synchronize the local state machine with the CPM
    DOPENCLOSE_PRINTK("chan->rx_tail = 0\n");
    chan->rx_tail = 0;

    // Initialize the RX Buffer Descriptor Ring and Connection Table
    for (i = 0, bdp = chan->rbase; i < chan->rx_ring_size; ++i, ++bdp) {
	// No pointers yet
	bdp->cbd_bufaddr = 0;

	// We don't use the CPCS bytes
	//bdp->cbd_cpcs = 0;
	bdp->cbd_sc = RX_BD_I;

	// Is this the last entry in the rx ring ?
	if (i == (chan->rx_ring_size - 1)) {
	    // Yes so set the wrap bit
	    bdp->cbd_sc |= RX_BD_W;
	}
	// Free any allocated socket buffers
	if (chan->rx_skbuff[i] != NULL) {
	    printk(KERN_ERR "Discovered rx sk_buff not freed by old VC\n");
	    dev_kfree_skb(chan->rx_skbuff[i]);
	}

	chan->rx_skbuff[i] = NULL;
    }

    // dev_data->sar_pram->fcc.rbptr = (ulong) __pa(chan->rbase);

    DLPRINTK("chan->rbase->cbd_datlen  = %d\n", chan->rbase->cbd_datlen);
    DLPRINTK("mpc8260sar_init_rx_channel:rbptr = %lx\n",
	     dev_data->sar_pram->fcc.rbptr);

    // Enable receiver interrupts (recv buffer and recv frame)
    chan->rctptr->StatusMask = (RCT_RXBUF_INTR | RCT_AAL5_RXFM_INTR);

#ifdef DEBUG_PRINT_ALL
    print_table((void *) chan->rctptr);
#endif

    // Success
    return 0;
}


/*
#########################################################
#
#  Function : mpc8260sar_alloc_rx_ring
#
#  Purpose  : allocates buffers to each buffer descriptor
#             in a channels BD ring
#  Args     :
#             chan = ptr to channel structure
#  Returns  : 0 for success
#
#  Notes    : assumes mpc8260sar_init_rx_channel has already
#             been called as this initialises the RCT and the BDs
##########################################################
*/
STATIC int mpc8260sar_alloc_rx_ring(cpm_channel_t * chan)
{
    int i;
    volatile atm_rx_cbd_t *bdp;
    struct sk_buff *newskb;
    ushort skblen;
    dev_data_t *dev_data = (dev_data_t *) chan->dev->dev_data;

    // the socket buffer length depends on the adaptation layer
    if (chan->aal == ATM_AAL5)
	skblen = AAL5_BUFLEN;
    else
	skblen = MIN_CPM_BUFSZ;

    // Initialize the RX Buffer Descriptor Ring
    bdp = chan->rbase;

    // For each BD in the rx ring allocate a socket buffer
    for (i = 0; i < chan->rx_ring_size; ++i, ++bdp) {
	// Allocate a socket buffer for this entry in the rx ring
	if (!(newskb = mpc8260sar_alloc_skb(skblen))) {
	    printk(KERN_ERR "cannot alloc socket buffer\n");
	    goto fail_rx_buffer;
	}
	// Make sure the buffer is burst aligned
	if (__pa(newskb->data) & (ulong) 0x0000000f) {
	    printk(KERN_ERR "receive buffer not burst aligned!\n");
	}
	// Allocate physical address
	bdp->cbd_bufaddr = __pa(newskb->data);

	// Mark BD as empty
	bdp->cbd_sc |= RX_BD_E;

	// Keep a local copy of the allocated socket buffer
	chan->rx_skbuff[i] = newskb;
    }

    chan->rctptr->p_rx_data = (ulong) chan->rbase->cbd_bufaddr;
    dev_data->sar_pram->fcc.rdptr = (ulong) __pa(chan->rbase);

    DLPRINTK("chan->rbase->cbd_bufaddr = %x\n", chan->rbase->cbd_bufaddr);
    DLPRINTK("rdptr = %lx\n", dev_data->sar_pram->fcc.rdptr);

    // Success
    return (0);

  fail_rx_buffer:

    for (i = 0; i < chan->rx_ring_size; ++i) {
	// Free any allocated socket buffers
	if (chan->rx_skbuff[i]) {
	    // Claim the socket buffer back
	    dev_kfree_skb(chan->rx_skbuff[i]);
	}

	chan->rx_skbuff[i] = NULL;
    }

    return (-ENOMEM);
}

typedef enum { RX, TX } direction_t;
STATIC int
mpc8260sar_valid_traffic_class(struct atm_vcc *vcc, direction_t dir)
{
    dev_data_t *dev_data = (dev_data_t *) vcc->dev->dev_data;
    int levels = dev_data->num_apc_levels;

    if (dir == RX) {
	unsigned char rclass = vcc->qos.rxtp.traffic_class;
	if ((levels == 1 && rclass != ATM_CBR)
	    || (rclass != ATM_UBR && rclass != ATM_CBR)) {
	    printk(KERN_ERR "Error: (" __FUNCTION__
		   ") invalid traffic class\n");
	    return -1;
	}
    } else {
	unsigned char tclass = vcc->qos.txtp.traffic_class;
	if ((levels == 1 && tclass != ATM_CBR)
	    || (tclass != ATM_UBR && tclass != ATM_CBR)) {
	    printk(KERN_ERR "Error: (" __FUNCTION__
		   ") invalid traffic class\n");
	    return -1;
	}
    }

    return 0;
}

/*
#########################################################
#
#  Function : mpc8260sar_activate_tx_channel
#
#  Purpose  : Sets up the CPM for a transmit VC
#
#  Args     : vcc = description of VC to recv
#             chan = ptr to channel structure
#                    alloced by mpc8260sar_alloc_chan()
#  Returns  : 0 for success
#
##########################################################
*/
STATIC int
mpc8260sar_activate_tx_channel(struct atm_vcc *vcc, cpm_channel_t * chan)
{
    DXMIT_PRINTK(__FUNCTION__ "\n");

    // Make sure the trasmit traffic class is CBR or UBR
    if (mpc8260sar_valid_traffic_class(vcc, TX) == 0) {
	// Initialize the tx connection table and buffer descriptors and the array of sk_buffs
	RETURN_ON_ERROR(mpc8260sar_init_tx_channel(vcc, chan));

	// Is this a AAL5 connection
	if (vcc->qos.aal == ATM_AAL5) {
	    // Create the cell header
	    ulong chead;
	    chead = (ulong) vcc->vpi << 20;
	    chead |= (ulong) vcc->vci << 4;
	    DXMIT_PRINTK("VPI = %d, VCI= %d, CHEAD = %lx\n", vcc->vpi,
			 vcc->vci, chead);
	    // Copy the header into the Transmit Connection Table
	    // Byte ordering is little endian
	    chan->tctptr->cell_header = chead;
	}
	// If this is a CBR channel then activate the channel here
	// (UBR channels use auto VC off and are activated
	// - if necessary - by mpc8260sar_send())

	// PEM - temp debug
	//if (tx_traffic_class == ATM_CBR) {
	    //DXMIT_PRINTK("entering mpc8260sar_tx_channel\n");
	    //mpc8260sar_tx_channel(vcc->dev, CPM_CHAN_ATM_TX, chan); 
	    //mpc8260sar_tx_channel(vcc->dev, CPM_CHAN_ENABLE, chan);	    
	    //DXMIT_PRINTK("leaving mpc8260sar_tx_channel\n");
	    //}
    } else {
	printk(KERN_ERR "Invalid transmit traffic class\n");
	return -EINVAL;
    }

    DXMIT_PRINTK("leaving " __FUNCTION__ "\n");

    return 0;
}

/*
#########################################################
#
#  Function : mpc8260sar_activate_rx_channel
#
#  Purpose  : Sets up the CPM to recieve a VC
#
#  Args     : vcc = description of VC to recv
#             chan = ptr to channel structure allocated
#                      with mpc8260sar_alloc_chan()
#  Returns  : 0 for success
#
##########################################################
*/
STATIC int
mpc8260sar_activate_rx_channel(struct atm_vcc *vcc, cpm_channel_t * chan)
{
  DOPENCLOSE_PRINTK(__FUNCTION__ "\n");

  // Make sure the receive traffic class is CBR or UBR
  RETURN_ON_ERROR(mpc8260sar_valid_traffic_class(vcc, RX));

  // Initialize the RX connection table and buffer descriptors and skbuff ptrs
  RETURN_ON_ERROR(mpc8260sar_init_rx_channel(chan));
  
  // Allocate buffers for all RX Buf Descr for this channel
  RETURN_ON_ERROR(mpc8260sar_alloc_rx_ring(chan));
  
  // Add an address mapping vpi/vci->chan
  RETURN_ON_ERROR(mpc8260sar_add_address_mapping(vcc->dev, chan->number,
						       vcc->vpi, vcc->vci));
  // Finally enable receptions on this channel
  mpc8260sar_rx_channel(vcc->dev, CPM_CHAN_ENABLE, chan);

  return 0;
}

/*
#########################################################
#
#  Function : mpc8260sar_activate_channel
#
#  Purpose  : Activates a (bi/uni)directional channel
#
#  Args     : vcc = describes the channel desired
#             chan = ptr to the channel struct
#                    allocated by mpc8260sar_alloc_chan()
#  Returns  : 0 for success
#
##########################################################
*/
STATIC int
mpc8260sar_activate_channel(struct atm_vcc *vcc, cpm_channel_t * chan)
{
  DXMIT_PRINTK(__FUNCTION__ "\n");

  // Is a receive interface required ?
  if (vcc->qos.rxtp.traffic_class != ATM_NONE) {
    // Make sure that the requested vpi/vci is not already open
    RETURN_ON_ERROR(mpc8260sar_check_channel(vcc->dev, vcc->vpi, vcc->vci));
    RETURN_ON_ERROR(mpc8260sar_activate_rx_channel(vcc, chan));
  }
  // Is a transmit interface required ??
  if (vcc->qos.txtp.traffic_class != ATM_NONE) {
    RETURN_ON_ERROR(mpc8260sar_activate_tx_channel(vcc, chan));
  }

  // Success
  return (0);
}

/*
#########################################################
#
#  Function : mpc8260sar_undo_activate_channel
#
#  Purpose  : should be called to free memory structures
#             in case mpc8260sar_activate_channel()
#             fails
#  Args     : vcc=ptr to vcc structure
#             chan=ptr to cpm_channel_t structure
#  Returns  : nothing
#
#  Notes    : Do not call from close.  This specifically
#             deals with activation failures
##########################################################
*/
STATIC void
mpc8260sar_undo_activate_channel(struct atm_vcc *vcc, cpm_channel_t * chan)
{
  dev_data_t *dev_data = (dev_data_t *) chan->dev->dev_data;

  printk(KERN_WARNING "mpc8260sar_activate_channel() failed\n"
	 "calling mpc8260sar_undo_activate_channel()\n");
  
    // Free the chanid so that it can be used again
    // by another VC.
    intpool_free(&(dev_data->channel_tracker), chan->number - 32);

    // Subtract from the tx byte rate as we won't be using it anyway
    if (chan->tx_byte_rate)
	dev_data->total_tx_byte_rate -= chan->tx_byte_rate;

    // If we've allocated some tx bds from the free pool then free them back
    if (chan->tbase)
	mpool_free(&(dev_data->tx_bd_pool), (unchar *) chan->tbase,
		   chan->tx_ring_size * sizeof(atm_tx_cbd_t));

    // If we've allocated some rx bds from the free pool then free them back
    if (chan->rbase)
	mpool_free(&(dev_data->rx_bd_pool), (unchar *) chan->rbase,
		   chan->rx_ring_size * sizeof(atm_rx_cbd_t));

    // If we've allocated some tx sk_buff pointers from the free pool then free them back
    // (There are no sk_buffs to free as these are added by mpc8260sar_send()
    if (chan->tx_skbuff)
	mpool_free(&(dev_data->tx_skbuff_ptr_pool),
		   (unchar *) chan->tx_skbuff,
		   chan->tx_ring_size * sizeof(struct sk_buff *));
    // If we've allocated some rx sk_buff pointers from the free pool then free them back
    // and also free any allocated sk_buffs
    if (chan->rx_skbuff) {
	// Free any allocated sk_buffs
	int i;
	for (i = 0; i < chan->rx_ring_size; ++i)
	    if (chan->rx_skbuff[i] != NULL)
		dev_kfree_skb(chan->rx_skbuff[i]);

	// Now free the pointers to the sk_buffs
	mpool_free(&(dev_data->rx_skbuff_ptr_pool),
		   (unchar *) chan->rx_skbuff,
		   chan->rx_ring_size * sizeof(struct sk_buff *));
    }
    // Delete channel from address match table
    if (chan->number)
	mpc8260sar_del_address_mapping(chan->dev, chan->vpi, chan->vci);
}

/*
#########################################################
#
#  Function : mpc8260sar_calculate_timing
#
#  Purpose  : Calculate timing parameters specific to this
#             device. (E.g. NCITS/APC table
#             size/max channel rate).
#
#  Arguments: dev = pointer to device being initialised
#
#  Returns  : 0 for success
#
##########################################################
*/
int mpc8260sar_calculate_timing(struct atm_dev *dev)
{
    volatile immap_t *immap = (immap_t *) IMAP_ADDR;
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    bd_t *bd = (bd_t *) __res;
    int rate_mode = dev_data->rate_mode;
    int fcc = dev_data->fcc;
    int i;
    int clock_div;
   
    /* see 8260 UM section 15.4.1 */
    if(dev_data->rate_mode == RATE_MODE_INTERNAL){
    	immap->im_cpmux.cmx_uar &= ~(0x0003 << (8 - fcc * 2));
    	immap->im_cpmux.cmx_uar |= (((dev_data->int_brg - 5) & 0x03) << (8 - fcc * 2));
    
        /* see 8260 UM section 29.13.4 and 29.16.1 */
	clock_div = (bd->bi_brgfreq / 1000 * ATM_CELL_SIZE * 8) / dev_data->line_rate_kbps;
	printk(KERN_INFO "int rate clk div = %d\n",clock_div);
        *(&immap->im_brgc5 + (dev_data->int_brg - 5)) = (clock_div - 1) << 1;

        /* assumption: internal rate timer == 1x BRG clock */
	for(i=0; i <= UTOPIA_LAST_PHY; i++){
            dev_data->im_fcc->fcc_ftirr_phy[i] = rate_mode << 7;
	}
    }

    /* make sure FC bit in the CMXFCR is cleared - 
     * see Figure 15-2 in the 8260 UM section 15.2 */
    immap->im_cpmux.cmx_fcr &= ~(0x40000000 >> ((fcc - 1) * 8));

    /* configure brg for fcc clock for 1/2 of system clock */
    clock_div = 2;
    *(&immap->im_brgc5 + (dev_data->fcc_brg - 5)) = ((clock_div - 1) << 1); 
    
    /* make sure CMXFCR is configured for the correct BRGs */
    /* assumed: tx and rx clocks are the same */
    /* assumed: 5 <= brg <= 8 */
    immap->im_cpmux.cmx_fcr &= ~(0x38000000 >> ((fcc-1)*8));
    immap->im_cpmux.cmx_fcr |= (((dev_data->fcc_brg - 5) & 0x07) << (11+(3-fcc)*8));
   immap->im_cpmux.cmx_fcr &= ~(0x07000000 >> ((fcc-1)*8));
    immap->im_cpmux.cmx_fcr |= (((dev_data->fcc_brg - 5) & 0x07) << (8+(3-fcc)*8));
    
    /******************************************************************/
    /****  Calculate all parameters needed for the APC Scheduling  ****/
    /******************************************************************/

    ///// Calculate Cells Per Slot , depending on line_rate,min/max_vc_rate
    dev_data->cells_per_slot =
	dev_data->line_rate_kbps / dev_data->max_vc_rate;

    ///// Calculate number_of_slots needed for the APC scheduling table
    dev_data->number_of_slots =
	(dev_data->line_rate_kbps /
	 (dev_data->min_vc_rate * dev_data->cells_per_slot)) + 1;

    ///// Calculate Peek Cell Rate (PCR)
    dev_data->peek_cell_rate =
	(dev_data->line_rate_kbps /
	 (dev_data->min_vc_rate * dev_data->cells_per_slot));

    ///// Calculate Peek Cell Rate Fraction
    dev_data->peek_cell_rate_fraction = 1;	// Needs Kernel with floating point operations

    ///// Calculate ABR Parameters
    dev_data->cells_per_slot_abr = dev_data->cells_per_slot;
    dev_data->line_rate_abr = dev_data->line_rate_kbps;

    /******************************************************************/
    /****                      Printing Results                    ****/
    /******************************************************************/
    DLPRINTK("Calculate Timing:line_rate               = %ld\n",
	     dev_data->line_rate_kbps);
    DLPRINTK("Calculate Timing:min_vc_rate             = %ld\n",
	     dev_data->min_vc_rate);
    DLPRINTK("Calculate Timing:max_vc_rate             = %ld\n",
	     dev_data->max_vc_rate);
    DLPRINTK("Calculate Timing:cells_per_slot          = %ld\n",
	     dev_data->cells_per_slot);
    DLPRINTK("Calculate Timing:number_of_slots         = %ld\n",
	     dev_data->number_of_slots);
    DLPRINTK("Calculate Timing:peak_cell_rate          = %ld\n",
	     dev_data->peek_cell_rate);
    DLPRINTK("Calculate Timing:peak_cell_rate_fraction = %ld\n",
	     dev_data->peek_cell_rate_fraction);

    if (dev_data->peek_cell_rate_fraction > 255) {
	printk(KERN_ERR "Error: (" __FUNCTION__
	       ") PCR Fraction value too large: %ld+%ld/256\n",
	       dev_data->peek_cell_rate,
	       dev_data->peek_cell_rate_fraction);
	return (-EINVAL);
    }

    return (0);
}

/*
#########################################################
#
#  Functions :  Implementations of function ptrs in
#               mpc8260sar_ops.
#   mpc8260sar_open(),
#   mpc8260sar_close(),
#   mpc8260sar_ioctl(),
#   mpc8260sar_getsockopt(),
#   mpc8260sar_setsockopt(),
#   mpc8260sar_send(),
#   mpc8260sar_sg_send(),
#   NULL,           no send_oam()
#   mpc8260sar_phy_put(),
#   mpc8260sar_phy_get(),
#   NULL,           no feedback()
#   mpc8260sar_change_qos(),
#   NULL,           no free_rx_skb()
#   mpc8260sar_proc_read()
#
#
#  Purpose  : See ATM device driver interface v0.1
#
#  Notes    : Conforming to Linux ATM device driver i/f
#             interface.  Draft version 0.1
#
#             Designed to work with multiple devices
##########################################################
*/
STATIC int mpc8260sar_open(struct atm_vcc *vcc, short vpi, int vci)
{
    /* Access ATM device structure */
    int result;
    unsigned char rx_traffic_class = vcc->qos.rxtp.traffic_class;
    unsigned char tx_traffic_class = vcc->qos.txtp.traffic_class;
    cpm_channel_t *chan;

    DOPENCLOSE_PRINTK(__FUNCTION__ "\n");

    /* Make sure we are opening a AAL0 or AAL5 connection */
    if ((vcc->qos.aal != ATM_AAL5) && (vcc->qos.aal != ATM_AAL0)) {
	printk(KERN_WARNING "Invalid AAL\n");
	return -EINVAL;
    }
    // Make sure traffic class is valid
    if ((rx_traffic_class == ATM_NONE) && (tx_traffic_class == ATM_NONE)) {
	printk(KERN_WARNING "rx and tx traffic class not specified\n");
	return -EINVAL;
    }
    // Open in progress
    set_bit(ATM_VF_ADDR, &vcc->flags.bits);

    // Allocate a channel for this vpi/vci */
    if (!(chan = mpc8260sar_alloc_chan(vcc->dev))) {
	printk(KERN_ERR "Could not allocate a CPM channel\n");
	return -ENOMEM;
    }
    // Save the AAL in chan
    chan->aal = vcc->qos.aal;

    // Save ptr to the vcc in chan
    chan->vcc = vcc;

    // Save ptr to chan in vcc
    vcc->dev_data = chan;

    /* Assign VPI and VCI in both atm_vcc and cpm_channel_t */
    vcc->vpi = chan->vpi = vpi;
    vcc->vci = chan->vci = vci;

    // Activate this channel
    if ((result = mpc8260sar_activate_channel(vcc, chan))) {
	mpc8260sar_undo_activate_channel(vcc, chan);
	return result;
    }

    /* Connection is now ready to receive data */
    set_bit(ATM_VF_READY, &vcc->flags);

    return 0;
}

STATIC void mpc8260sar_close(struct atm_vcc *vcc)
{
    cpm_channel_t *chan = (cpm_channel_t *) vcc->dev_data;
    dev_data_t *dev_data = (dev_data_t *) vcc->dev->dev_data;
    unsigned char tx_tclass = vcc->qos.txtp.traffic_class;
    unsigned char rx_tclass = vcc->qos.rxtp.traffic_class;
    volatile atm_rx_cbd_t *rbdp;
    volatile atm_tx_cbd_t *tbdp;
    int i,j;

    // Make sure the channel is valid
    if (chan->number >= dev_data->max_channels + NUM_INT_CONN_TABLES) {
	printk(KERN_ERR
	       "Error: Attempting to close a invalid CPM channel %u\n",
	       chan->number);
	return;
    }
    // channel number valid
    DOPENCLOSE_PRINTK("Attempting to close CPM channel number %u\n",
		      chan->number);

    printk(KERN_ERR __FUNCTION__ ": tctstatus %lx\n", chan->tctptr->tct_status);

    for (i = 0, tbdp = chan->tbase; i < chan->tx_ring_size; ++i, ++tbdp) {
      printk("status %04x, len %d, buf ptr %08x",
	     tbdp->cbd_sc, tbdp->cbd_datlen, tbdp->cbd_bufaddr);
#ifdef CONFIG_ATM8260_TX_UDC      
      printk(", udc: ");
      for (j = 0; j < 8; j++)
	printk(" %02x", tbdp->udc_header[j]);
#endif
      printk("\n");
    }
    printk(KERN_ERR __FUNCTION__ ": rctstatus %lx\n", chan->rctptr->rct_status);	

    for (i = 0, rbdp = chan->rbase; i < chan->rx_ring_size; ++i, ++rbdp)
      printk("status %04x, len %d, buf ptr %08x\n",
	     rbdp->cbd_sc, rbdp->cbd_datlen, rbdp->cbd_bufaddr);

    // Is there a receive interface open ?
    if (rx_tclass != ATM_NONE) {
	// Delete channel from address match table
	if (mpc8260sar_del_address_mapping(chan->dev, chan->vpi, chan->vci)
	    == 0) {
	    // Finally, re-claim all socket buffers
	    mpc8260sar_close_rx_channel(chan);
	}
    }
    // Was this a CBR channel ?
    if (tx_tclass != ATM_NONE) {
	// Turn off the APC &c.
	mpc8260sar_close_tx_channel(chan);
    }
    // Is there either a receive or transmit interface open
    if ((tx_tclass == ATM_NONE) && (rx_tclass == ATM_NONE)) {
	printk(KERN_ERR "Error: Attempting to close unopen interface\n");
	return;
    }
    // free the chan so that it can be allocated again
    mpc8260sar_free_chan(chan);

    // Indicate channel closed
    clear_bit(ATM_VF_READY, &vcc->flags);
}

STATIC void mpc8260sar_print_uni_stats(struct atm_dev *dev)
{
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    uni_stat_t *pus =
	(uni_stat_t *) (IMAP_ADDR +
			dev_data->sar_pram->atm.UniStatTableBase);

    printk(KERN_INFO "UTOPIAE=%d, MIC_COUNT=%d, CRC10E_COUNT=%d\n",
	   pus->utopiae, pus->mic_cnt, pus->crc10_cnt);
}

struct udc_ioctl
{
  struct atm_vcc *vcc;
  void* udc;
};

static int
init_udc(struct atm_dev *dev, void *arg)
{
#ifdef CONFIG_ATM8260_TX_UDC
   int i, j;
   char udc[8];
   cpm_channel_t * chan;
   struct udc_ioctl* udc_io;
   volatile atm_tx_cbd_t *bdp;

   udc_io = (struct udc_ioctl*) arg;

   chan = (cpm_channel_t *) udc_io->vcc->dev_data;

   if (!chan) {
     printk(KERN_ERR "channel not opened yet!\n");
     return -ENOTCONN;
   }

   if (copy_from_user(udc, udc_io->udc, sizeof(udc))) {
     return -EFAULT;
   }

   // Copy into the Tx descriptor ring
   for (j = 0, bdp = chan->tbase; j < chan->tx_ring_size; ++j, ++bdp)
     for (i = 0; i < (ATM_TEHS + 1); i++)
       bdp->udc_header[i] = udc[i];

   return 0;
#else
   return -EINVAL;
#endif
}

static int
mpc8260_setloop(dev_data_t *dev_data, int loop_mode)
{
     switch (loop_mode) {

     case ATM_LM_NONE:
       if(dev_data->utopia.master)
         dev_data->im_fcc->fcc_fpsmr &= ~(FPSMR_TUMS | FPSMR_RUMS);
       else
         dev_data->im_fcc->fcc_fpsmr |= (FPSMR_TUMS | FPSMR_RUMS);
       dev_data->im_fcc->fcc_gfmr &= 0x3fffffff; // clear DIAG
       break;

     case ATM_LM_LOC_ATM:
       printk("atm8260: setting local (8260) loopback\n");
       dev_data->im_fcc->fcc_fpsmr &= ~FPSMR_TUMS;
       dev_data->im_fcc->fcc_fpsmr |= FPSMR_RUMS;
       dev_data->im_fcc->fcc_gfmr |= GFMR_DIAG_LPB;
       break;

     default:
       printk("atm8260: crappy loopback control arg!\n");
       return -EINVAL;
     }

     dev_data->loop_mode = loop_mode;

     return 0;
}

STATIC int
mpc8260sar_ioctl(struct atm_dev *dev, unsigned int cmd, void *arg)
{
     dev_data_t *dev_data = (dev_data_t *) dev->dev_data;

     DPRINTK(__FUNCTION__ "\n");

    if (!capable(CAP_NET_ADMIN))
      return -EPERM;

     switch(cmd) {

     case ATM_SETLOOP:
        return mpc8260_setloop(dev_data, (int)(unsigned long)arg);

     case ATM_GETLOOP:
        return put_user(dev_data->loop_mode, (int*)arg) ? -EFAULT : 0;

     case ATM_QUERYLOOP:
        return put_user(ATM_LM_LOC_PHY | ATM_LM_RMT_PHY, (int*)arg) ? -EFAULT
: 0;

     case 0x554443: // ASCII for UDC
       return init_udc(dev, arg);

     default:
       /* pass IOCTL on down to the phy driver */
       if (dev->phy) {
        return (dev->phy->ioctl(dev, cmd, arg));
       }
     }

     return -ENOSYS; /* not implemented */
}

STATIC int
mpc8260sar_getsockopt(struct atm_vcc *vcc, int level, int optname,
		      void *optval, int optlen)
{
    DPRINTK(__FUNCTION__ "\n");
    return -EINVAL;
}


STATIC int
mpc8260sar_setsockopt(struct atm_vcc *vcc, int level, int optname,
		      void *optval, int optlen)
{
    DPRINTK(__FUNCTION__ "\n");
    return -EINVAL;
}

STATIC int mpc8260sar_send(struct atm_vcc *vcc, struct sk_buff *skb)
{
    cpm_channel_t *chan = (cpm_channel_t *) vcc->dev_data;
    struct atm_dev *dev = vcc->dev;
    volatile atm_tx_cbd_t *bdp;
    int tx_head;
    int new_tx_head;

    // Assign VCC to socket buffer
    // Note: this must be done before attempting to call
    // mpc8260sar_free_tx_skb() as this may use ATM_SKB(skb)->vcc->pop()

    DXMIT_PRINTK("entering mpc8260sar_send\n");

    ATM_SKB(skb)->vcc = vcc;

    // Is the transmitter busy on this CPM channel
    if (chan->tbusy) {
	// Determine how many clock ticks have occured
	// since this transmission was started
	int tickssofar = jiffies - chan->trans_start;

	DXMIT_PRINTK("chan->tbusy != 0\n");

	// Has the transmit timed out
	if (tickssofar < TX_TIMEOUT) {
	    // Interface is too busy to handle cells
	    // Free tx skb
	    mpc8260sar_free_tx_skb(skb);
	    DXMIT_PRINTK("skb: line %d\n", __LINE__);

	    atomic_inc(&vcc->stats->tx_err);

	    return (-EBUSY);
	}
	// Yes:
	printk(KERN_WARNING "ATM: transmit timed out, restarting\n");

	// Finally, restart the transmitter
	mpc8260sar_close_tx_channel(chan);
	mpc8260sar_init_tx_channel(vcc, chan);
    }
#ifdef DEBUG_XMIT
    // Make sure there is a socket buffer
    if (skb == NULL) {
	DXMIT_PRINTK("NO socket buffer\n");
	return (-1);
    }
#endif

    // Get the index of the BD at the head of queue
    tx_head = chan->tx_head;

    // Get tx BD at head of queue
    bdp = &(chan->tbase[tx_head]);

    // increment copy of tx_head
    new_tx_head = tx_head + 1;
    if (new_tx_head >= chan->tx_ring_size)
	new_tx_head = 0;

    // Is this BD still waiting to be transmitted?
    if (new_tx_head == chan->tx_tail) {
	DXMIT_PRINTK(": no tx bd's available\n");

	// Mark this tx channel as busy
	chan->tbusy = 1;

	// Free socket buffer
	mpc8260sar_free_tx_skb(skb);

	// Update tx channel stats
	atomic_inc(&vcc->stats->tx_err);

	// Interface is busy - APC parameters exceeded
	return (-EBUSY);
    }
    // When we reach here we have found a free
    // BD at the head of the TX ring,

    // Has the tx socket buffer NOT yet been re-claimed
    if (chan->tx_skbuff[tx_head] != NULL) {
	// This shouldn't happen
	printk(KERN_ERR "Error: (" __FUNCTION__
	       ") found free BD with unclaimed skb\n");

	// Free up the tx skb
	mpc8260sar_free_tx_skb(chan->tx_skbuff[tx_head]);
	atomic_inc(&vcc->stats->tx_err);

	// Free skb from TX ring
	chan->tx_skbuff[tx_head] = NULL;

	// Stop if this error condition arises
	return (-EBUSY);
    }
    // Set BD data length to that of socket buffer
    bdp->cbd_datlen = skb->len;

    if (skb->len > AAL5_MTU)
      printk(KERN_ERR "send: len (%u) > mtu\n", skb->len);

    DXMIT_PRINTK("Send size %u\n", skb->len);

    // Set physical address of socket buffer data in BD
    bdp->cbd_bufaddr = __pa(skb->data);
#ifdef DEBUG_XMIT
    print_tabled((uint *) skb->data, skb->len / 4);
#endif

#ifdef  DEBUG_XMIT
    printk("single TCT entry - see 8260 UM sec. 29.10.2.3\n");
    print_table((void *) chan->tctptr);
#endif

    // Push the data cache so the CPM does not get stale data
    flush_dcache_range((ulong) skb->data, (ulong) (skb->data + skb->len));

    // Timestamp this transmission
    chan->trans_start = jiffies;

    // AJZ TODO (lo-pri) if we use multi buffer AAL5 frames then clear
    // BD_ATM_TX_LAST for all buffers but the last in the AAL5 frame

    // Activate BD entry in TX ring - force transmit
    bdp->cbd_sc |= TX_BD_R | TX_BD_I | TX_BD_L;

#ifdef DEBUG_XMIT
    printk("--------------- Tx BD -----------------\n");
    printk("TxBD cbd_sc = %x\n", chan->tbase->cbd_sc);
    printk("TxBD cbd_datlen = %x\n", chan->tbase->cbd_datlen);
    printk("TxBD cbd_bufaddr = %x\n", chan->tbase->cbd_bufaddr);
#ifdef CONFIG_ATM8260_TX_UDC
    {
      int i;
      printk("TxBD udc = ");
      for (i = 0; i < ATM_TEHS + 1; i++)
	printk("%x ", chan->tbase->udc_header[i]);
      printk("\n");
    }
#endif
    printk("---------------------------------------\n");
#endif

    // Set socket buffer in BD to new skb
    chan->tx_skbuff[tx_head] = skb;

    // Increment BD at head of ring (for next time)
    // NOTE: It is important that this is done AFTER
    // the BD_ATM_TX_READY bit is set, otherwise
    // mpc8260sar_tx_bh() might try to clear up this
    // BD before it has been sent!
    chan->tx_head = new_tx_head;

    // non-CBR channels use auto deactivation.  We must
    // check here if we need to reactivate

#ifdef DEBUG_XMIT
    printk("TCT entry:\n");
    print_table((void *) chan->tctptr);
#endif

    // 8260 UM sec. 29-14 says this commmand should be issued
    // only after TCT and BD is ready to go...
    if (!(chan->tctptr->tct_status & TCT_VCON))  {
      chan->tctptr->tct_status |= TCT_VCON;
      mpc8260sar_tx_channel(dev, CPM_CHAN_ATM_TX, chan);
    }
    
    return (0);
}

STATIC int
mpc8260sar_sg_send(struct atm_vcc *vcc, unsigned long start,
		   unsigned long size)
{

    DXMIT_PRINTK(__FUNCTION__ "\n");
    return vcc->qos.aal == ATM_AAL5 && !((start | size) & 3);
    /* don't tolerate misalignment */
}

STATIC void
mpc8260sar_phy_put(struct atm_dev *dev, unsigned char value,
		   unsigned long addr)
{
#ifdef CONFIG_IDT77106
  idt_phy_write(le_2_be(addr), le_2_be(value));
#else				/* if defined(CONFIG_PM5350) */
  suni_phy_write(addr, value);
#endif
}

STATIC unsigned char
mpc8260sar_phy_get(struct atm_dev *dev, unsigned long addr)
{
#ifdef CONFIG_IDT77106
  return le_2_be(idt_phy_read(le_2_be(addr)));
#else				/* if defined(CONFIG_PM5350) */
  return suni_phy_read(addr);
#endif
  return 0;
}


STATIC int
mpc8260sar_change_qos(struct atm_vcc *vcc, struct atm_qos *qos, int flgs)
{
    DPRINTK(__FUNCTION__ "\n");
    return 0;
}

STATIC int
mpc8260sar_proc_read(struct atm_dev *dev, loff_t * pos, char *page)
{
    int left = (int) *pos;

    if (mask_apcov) {
	if (!left--)
	    return sprintf(page, "APC Overflow accounting disabled\n");
    } else {
	dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
	if (!left--)
	    return sprintf(page, "APC Overflows:\n");
	if (!left--)
	    return sprintf(page, "CBR Ring: %ld\n",
			   dev_data->apc_overflow[0]);
	if (dev_data->num_apc_levels > 1 && !left--)
	    return sprintf(page, "UBR Ring: %ld\n",
			   dev_data->apc_overflow[1]);
    }
    return 0;
}

/*
#########################################################
#
#  Function : mpc8260sar_release
#
#  Purpose  : Release resource used by all ATM devices
#             driven by this code.
#
#  Returns  : 0 for success
#
##########################################################
*/
int mpc8260sar_release(void)
{
#ifdef CONFIG_ATM_RISCTIMER
    // Stop the timestamp timer
    RETURN_ON_ERROR(risc_timer_stop(timestamp_timer));

    // Disable all timers
    RETURN_ON_ERROR(risc_timer_disable());
#endif

    return 0;
}


/*
#########################################################
#
#  Function : mpc8260sar_start
#
#  Purpose  : Starts the CPM in ATM mode after all of the device
#             specific initialisations
#
#  Returns  : 0 for success
#
#  Notes    : Must be called after all the device specific
#             initialisation has taken place
##########################################################
*/
int mpc8260sar_start(void)
{
  return 0;
}

/*
#########################################################
#
#  Function : mpc8260sar_stop
#
#  Purpose  : Stops the CPM
#
#  Returns  : 0 for success
#
#  Notes    : Only really needed for modular driver
##########################################################
*/
int mpc8260sar_stop(void)
{
  return 0;
}

/* someone needs to implement this? */
STATIC int m8260_cpm_dpfree(int addr)
{
    return 0;
}

#ifdef MODULE
void cleanup_module(void)
{
    extern struct atm_dev *utopia_dev;
    dev_data_t *dev_data = (dev_data_t *) utopia_dev->dev_data;

    remove_proc_entry("8260", atm_proc_root);

#ifdef CONFIG_ATM_VADS
    printk(KERN_INFO "atm-8260 cleanup_module called\n");
    /* PEM - is there a better place for this? */
    if (utopia_dev->phy->stop)
	utopia_dev->phy->stop(utopia_dev);
#endif

    free_irq(SIU_INT_FCC1 + (dev_data->fcc - 1), dev_data);

    /* PEM - added */
    if (utopia_dev) {
	atm_dev_deregister(utopia_dev);
	mpc8260sar_release_pram(utopia_dev);
	utopia_dev = NULL;
    }

}
#endif

int mpc8260sar_init_proc(struct atm_dev *dev)
{
    struct proc_dir_entry *entry;

    entry = create_proc_entry("8260", 0600, atm_proc_root);
    entry->nlink = 1;
    entry->read_proc = mpc8260sar_read_proc;
    entry->write_proc = NULL;
    entry->data = dev;

    return 0;
}

STATIC int  mpc8260sar_read_proc(char *buf, char **start, off_t offset, int count, int *eof, void *data)
{
    int len = 0;
    struct atm_dev *dev = (struct atm_dev *)data;

    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    uni_stat_t *pus = (uni_stat_t *) (IMAP_ADDR + dev_data->sar_pram->atm.UniStatTableBase);

    len = sprintf(buf, "UTOPIAE=%d, MIC_COUNT=%d, CRC10E_COUNT=%d\n",
        pus->utopiae, pus->mic_cnt, pus->crc10_cnt);
	
    *eof = 1;
    return len;
}


/*
#######################################################################
#
# (C) Copyright 2002
# Peter McCormick, pete261@yahoo.com
# Eastern Research Inc., http://www.erinc.com
# ported from mpc860sar project, http://mpc860sar.sourceforge.net
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
*/

/*-----------------------------------------------*/
/* General FCC Mode Register (GFMR) definitions. */
/*-----------------------------------------------*/

#define GFMR_ENT      0x00000010  /* Enable Transmitter */
#define GFMR_DIAG     0xC0000000
#define GFMR_TCI      0x20000000
#define GFMR_TRX      0x10000000
#define GFMR_TTX      0x08000000
#define GFMR_CDP      0x04000000
#define GFMR_CTSP     0x02000000
#define GFMR_CDS      0x01000000
#define GFMR_CTSS     0x00800000
#define GFMR_SYNL     0x0000C000
#define GFMR_RTSM     0x00002000
#define GFMR_RENC     0x00001800
#define GFMR_REVD     0x00000400
#define GFMR_TENC     0x00000300
#define GFMR_TCRC     0x000000C0
#define GFMR_ENR      0x00000020  /* Enable Receiver    */
#define GFMR_MODE_ATM 0x0000000A  /* ATM protocol def.  */
#define GFMR_DIAG_LPB 0x40000000  /* Enable Receiver    */

/*-----------------------------------------------*/
/*  FCC ATM Mode Register (FPSMR) definitions    */
/*-----------------------------------------------*/

#define FPSMR_TEHS   0xF0000000 
#define FPSMR_REHS   0x0F000000
#define FPSMR_ICD    0x00800000
#define FPSMR_TUMS   0x00400000
#define FPSMR_RUMS   0x00200000
#define FPSMR_PHY_ID 0x001F0000
#define FPSMR_TUDC   0x00001000
#define FPSMR_RUDC   0x00000800
#define FPSMR_RXP    0x00000400
#define FPSMR_TUMP   0x00000200
#define FPSMR_TSIZE  0x00000080
#define FPSMR_RSIZE  0x00000040
#define FPSMR_UPRM   0x00000020
#define FPSMR_UPLM   0x00000010
#define FPSMR_RUMP   0x00000008
#define FPSMR_HECI   0x00000004

/*-----------------------------------------------*/
/*  Global Mode Entry (GMODE) definitions        */
/*-----------------------------------------------*/

#define GMODE_ALB     ((ushort)0x0200)
#define GMODE_CTB     ((ushort)0x0100)
#define GMODE_REM     ((ushort)0x0080)
#define GMODE_UEAD    ((ushort)0x0010)
#define GMODE_CUAB    ((ushort)0x0008)
#define GMODE_EVPT    ((ushort)0x0004)
#define GMODE_ALM     ((ushort)0x0001)


#define CPMVEC_RISCTIMER   ((ushort)0x03)

/*-----------------------------------------------*/
/*  Interrupt Queue Masks for Control            */
/*-----------------------------------------------*/

#define INTR_V      0x8000
#define INTR_W      0x2000
#define INTR_TBNR   0x0010
#define INTR_RXF    0x0008
#define INTR_BSY    0x0004
#define INTR_TXB    0x0002
#define INTR_RXB    0x0001

/*-----------------------------------------------*/
/*  Buffer Discriptor Mask Definitions           */
/*-----------------------------------------------*/

/* Rx BD Masks */
#define RX_BD_E     0x8000
#define RX_BD_W     0x2000
#define RX_BD_I     0x1000
/* AAL0 Rx BD */
#define RX_BD_CRE   0x0020
#define RX_BD_OAM   0x0010
/* AAL1 Rx BD */
#define RX_BD_SNE_AAL1  0x0800
/* AAL5 Rx BD */
#define RX_BD_L     0x0800
#define RX_BD_F     0x0400
#define RX_BD_CLP_AAL5  0x0020
#define RX_BD_CNG_AAL5  0x0010
#define RX_BD_ABRT_AAL5 0x0008
#define RX_BD_CPUU_AAL5 0x0004
#define RX_BD_LNE_AAL5  0x0002
#define RX_BD_CRE_AAL5  0x0001
/* Tx BD Masks */
#define TX_BD_R     0x8000
#define TX_BD_W     0x2000
#define TX_BD_I     0x1000
/* AAL5 Tx BD*/
#define TX_BD_L     0x0800
/* AAL0 Tx BD */
#define TX_BD_CM    0x0200
#define TX_BD_OAM   0x0010

#define CPM_CR_ATM_SBLOCK       0x0e

#define CPM_CR_ACT_CHAN         0x02
#define CPM_CR_DEACT_CHAN       0x04 
#define CPM_CR_RESTART_RX       0x06
#define CPM_CR_STOP_RX          0x07
#define CPM_CR_ATM_TX 0xA

#define TCT_OUT                 0x00040000

/*-----------------------------------------------*/
/*     TCT STATUS BITS MASKS Definitions         */
/*-----------------------------------------------*/

#define TCT_GBL         0x20000000
#define TCT_BO_LE       0x08000000
#define TCT_BO_BE       0x10000000
#define TCT_DTB_LOCAL   0x02000000
#define TCT_BIB_LOCAL   0x01000000
#define TCT_AVCF        0x00800000
#define TCT_VBR_ATT     0x00100000
#define TCT_UBR_ATT     0x00200000
#define TCT_CPUU        0x00080000
#define TCT_VCON        0x00040000
#define TCT_INF         0x00004000
#define TCT_ABRF        0x00000008
#define TCT_BNM         0x00000008
#define TCT_STPT        0x00000004
#define TCT_IMK         0x00000002
#define TCT_AAL1        0x00000001
#define TCT_AAL0        0x00000000
#define TCT_AAL5        0x00000002
#define TCT_PM          0x00000001
#define TCT_AAL0_CRC10  0x0040
#define TCT_AAL0_ACHC   0x0010
#define TCT_AAL1_PFM    0x80
#define TCT_AAL1_SRT    0x40
#define TCT_AAL1_STF    0x10
#define TCTE_VBR2       0x8000
#define TCTE_ABR_ACRC   0x8000
#define TCTE_ABR_ADTF   0x01e8  
#define TCTE_ABR_NI     0x1000

/*-----------------------------------------------*/
/*     RCT STATUS BITS MASKS Definitions         */
/*-----------------------------------------------*/

#define RCT_GBL             0x20000000
#define RCT_BO_LE           0x08000000
#define RCT_BO_BE           0x10000000
#define RCT_DTB_LOCAL       0x02000000
#define RCT_BIB_LOCAL       0x01000000
#define RCT_BUFM_GLOBAL     0x00400000
#define RCT_SEGF            0x00200000
#define RCT_ENDF            0x00100000
#define RCT_CPUU            0x00080000
#define RCT_INF             0x00004000
#define RCT_ABRF            0x00000008
#define RCT_RXBUF_INTR      0x0080
#define RCT_AAL0            0x00000000
#define RCT_AAL1            0x00000001
#define RCT_AAL5            0x00000002
#define RCT_PM              0x00000001
#define RCT_AAL0_INVE       0x0060
#define RCT_AAL0_NO_INVE    0x0040
#define RCT_AAL1_PFM        0x0080
#define RCT_AAL1_SRT        0x0040
#define RCT_AAL1_INVE       0x0020
#define RCT_AAL1_STF        0x0010
#define RCT_AAL1_SNEM_INTR  0x0800
#define RCT_AAL5_RXFM_INTR  0x0040

/* PEM - added */

#define MPC8260_PORTA 0
#define MPC8260_PORTB 1
#define MPC8260_PORTC 2
#define MPC8260_PORTD 3





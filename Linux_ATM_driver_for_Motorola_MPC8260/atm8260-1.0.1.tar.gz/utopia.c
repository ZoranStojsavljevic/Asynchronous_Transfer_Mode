
/*
#######################################################################
#
# (C) Copyright 2002
# Peter McCormick, pete261@yahoo.com
# Eastern Research Inc., http://www.erinc.com
# ported from mpc860sar project, http://mpc860sar.sourceforge.net
#
# (C) Copyright 2001
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
# Notes:
# This file contains functions and data which is specific to the
# utopia ATM device.
#
# Any functions/data used by both utopia and serial ATM devices should
# go in mpc860sar.[ch]
#######################################################################
*/

/*#################### Includes #####################*/
#include <linux/module.h>
#include <linux/config.h>
#include <linux/kernel.h>
#include <linux/vmalloc.h> /* for vmalloc */
#include <linux/mm.h>
#include <linux/pci.h>
#include <linux/errno.h>
#include <linux/atm.h>
#include <linux/atmdev.h>
#include <linux/sonet.h>
#include <linux/skbuff.h>
#include <linux/time.h>
#include <linux/sched.h> /* for xtime */
#include <linux/delay.h>
#include <linux/uio.h>
#include <linux/init.h>
#include <asm/system.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include <asm/string.h>
#include <asm/byteorder.h>
#include <asm/irq.h>

#include <linux/netdevice.h>
#include <linux/ioport.h>
#include <linux/atm.h>

#include <asm/immap_8260.h>
#include <asm/cpm_8260.h>
#include "utopia.h"
#include "debug.h"
#include "mpc8260sar.h"

#ifdef CONFIG_ATM_VADS
//#include <asm/mpc8260ads.h>         
#endif

#if (defined(CONFIG_IDT77106) && defined(CONFIG_ATM_VADS))
#error Cant have both VADS and IDT support simultaneously
#endif
#if (!defined(CONFIG_IDT77106) && !defined(CONFIG_ATM_VADS))
#error You should select at least one of VADS or IDT support
#endif

static int fcc = ATM_FCC;
#ifdef MODULE
MODULE_PARM(fcc, "l");
MODULE_PARM_DESC(fcc, "FCC used for ATM: 1 or 2");
#endif

/*############## forward declarations ##############*/

/* utopia ATM device specific functions */
static int utopia_config_pins(struct atm_dev *dev);
static void utopia_interrupt_handler(int irq, void * dev_id, struct pt_regs * regs);
static int utopia_init_phy(struct atm_dev *dev);
extern void mpc8260sar_interrupt_bh(void *param);
extern void mpc8260_cmd_wait(char *func, int line);

#ifdef CONFIG_IDT77106
extern int start_idt77v106(void);
#endif
extern int mpc8260sar_init(void);
#ifdef CONFIG_ATM_VADS
  extern int start_vads_phy(void);
#endif
/*#################### File scope variables ############*/

/* ATM device and it's private data (accessible only to driver) */
struct atm_dev *utopia_dev = NULL;
EXPORT_SYMBOL(utopia_dev);
extern struct tq_struct bh_tq; 
static dev_data_t utopia_dev_data;

#if 0
/* Variables calculated by utopia_calculate_timing() */
static ulong utopia_sccr_divisor;

/* the speed of the utopia clock */
static ulong utopia_clock = UTOPIA_CLOCK_HZ;
#endif

/*############## function definitions ##############*/

/*
#########################################################
#
#  Function : utopia_interrupt_handler
#
#  Purpose  : Work out what caused the MPC interrupt
#             and schedule the appropriate bottom half
#             handler
#  Args     : ???
#
#  Notes    : Called in interrupt context
#
##########################################################
*/
static void utopia_interrupt_handler(int irq, void * dev_id, struct pt_regs * regs)
{
    dev_data_t * dev_data = (dev_data_t *) dev_id;

    // Get the interrupt events
    /* see UM section 29.13.3 */
    ushort int_events = dev_data->im_fcc->fcc_fcce;

    // Clear off these events
    dev_data->im_fcc->fcc_fcce = int_events;

    DINT_PRINTK(__FUNCTION__ "\n");
    DINT_PRINTK("int_events = %x\n",int_events);
  
    if (int_events & 0x000f){
        // Do not printk here or we'll never catch up!
        //printk(KERN_ERR "utopia: interrupt queue overflow\n");
        dev_data->rx_errors.intr_q_ov++;
    }
 
    // Is this a IDSR general interrupt
    // or an interrupt overflow
    if(int_events & 0x00ff){
         mpc8260sar_interrupt_bh(dev_id);
    }
}

/*
#########################################################
#
#  Function : utopia_config_pins
#             
#  Purpose  : Configures the PPC pins for use with a
#             UTOPIA bus
#  Returns  : 0 for success
#             
##########################################################
*/
static int utopia_config_pins(struct atm_dev *dev)
{
    volatile immap_t* immap = (immap_t*)IMAP_ADDR;

#ifdef CONFIG_IDT77106
        // Pin configure is made through the ppcboot loader

        /// Initialize Port A
        immap->im_ioport.iop_psora  = 0x00000000;
        immap->im_ioport.iop_ppara  = 0x003FFFFF;
        immap->im_ioport.iop_pdira  = 0x40003FCD;
        /// Initialize Port C
        // immap->im_ioport.iop_psorc &= 0xFFFFEFFF; 
        // immap->im_ioport.iop_pparc |= 0x00001000;
        // immap->im_ioport.iop_pdirc |= 0x00001000;       
	return 0;
#endif
    
#ifdef CONFIG_ATM_VADS
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
    int fcc = dev_data->fcc;

	if(fcc == 1){
	    immap->im_ioport.iop_ppara |= 0x003FFFFF;
	    immap->im_ioport.iop_psora &= ~0x003FFFFF; 
	    immap->im_ioport.iop_pdira |= 0x00003FCD;

            immap->im_ioport.iop_pparc |= 0x00e00c00;
	    immap->im_ioport.iop_psorc &= ~0x00e00c00;
            immap->im_ioport.iop_pdirc |= 0x00e00400;

	    immap->im_ioport.iop_ppard |= 0x0603cff8;
	    immap->im_ioport.iop_psord &= ~0x0603cff8;
            immap->im_ioport.iop_pdird |= 0x06008248;

	    /* to do: 16-bit UTOPIA */

	    return 0;
	}
#endif
#ifdef CONFIG_ATM_FCC2

	        /*
		 * The 8260 is a complex part with many different 
		 * possible configurations and options, some of which conflict.  
		 * Better to let the software detect 
		 * when conflicting functions have been selected,
		 * than to waste time debugging.
		 * Avoids errors shifting bits also...
		 */
	
	else if(fcc == 2){
	    if(dev_data->utopia.bus_size != 8){
                printk(KERN_ERR "FCC2 ATM only supports UTOPIA 8\n");
		return -EINVAL;
	    }
		
            if(dev_data->utopia.last_phy){
		if(dev_data->utopia.master){
                    mpc8260_ioport_cfg(MPC8260_PORTA,2,1,0,1);  /* TxAddr[0] */
		    mpc8260_ioport_cfg(MPC8260_PORTA,1,1,0,1);  /* TxAddr[1] */
		    mpc8260_ioport_cfg(MPC8260_PORTA,0,1,1,1);  /* TxAddr[2] */
		    mpc8260_ioport_cfg(MPC8260_PORTD,19,1,0,1); /* TxAddr[3] polling: multiplexed */		   
		    mpc8260_ioport_cfg(MPC8260_PORTD,7,1,1,1);  /* TxAddr[4] polling: multiplexed */
		}
		else{
		    mpc8260_ioport_cfg(MPC8260_PORTD,19,1,0,0); /* TxAddr[0] polling: multiplexed */	
		    mpc8260_ioport_cfg(MPC8260_PORTD,7,1,1,0);  /* TxAddr[1] polling: multiplexed */
		    mpc8260_ioport_cfg(MPC8260_PORTC,7,1,1,0);  /* TxAddr[2] polling: multiplexed */  	  
		    mpc8260_ioport_cfg(MPC8260_PORTC,13,1,1,0); /* TxAddr[3] */			
		    mpc8260_ioport_cfg(MPC8260_PORTC,15,1,1,0); /* TxAddr[4] */
		}
	    }
			    
	    mpc8260_ioport_cfg(MPC8260_PORTB,11,1,0,1);	/* TxD[0] */
	    /* mpc8260_ioport_cfg(MPC8260_PORTB,27,1,0,1); */ /* TxD[0] */
	    
	    mpc8260_ioport_cfg(MPC8260_PORTB,10,1,0,1); /* TxD[1] */ 
	    /* mpc8260_ioport_cfg(MPC8260_PORTB,26,1,0,1); */ /* TxD[1] */
	    
	    mpc8260_ioport_cfg(MPC8260_PORTB,9,1,0,1);  /* TxD[2] */
	    /* mpc8260_ioport_cfg(MPC8260_PORTC,25,1,0,1); */  /* TxD[2] */
	    /* mpc8260_ioport_cfg(MPC8260_PORTC,3,1,0,1); */  /* TxD[2] */

	    mpc8260_ioport_cfg(MPC8260_PORTB,8,1,0,1);  /* TxD[3] */
	    /* mpc8260_ioport_cfg(MPC8260_PORTC,30,1,0,1); */  /* TxD[3] */
	    /* mpc8260_ioport_cfg(MPC8260_PORTC,24,1,0,1); */  /* TxD[3] */
	    /* mpc8260_ioport_cfg(MPC8260_PORTC,2,1,0,1); */  /* TxD[3] */
	    
	    mpc8260_ioport_cfg(MPC8260_PORTB,25,1,0,1); /* TxD[4] */
	    mpc8260_ioport_cfg(MPC8260_PORTB,24,1,0,1); /* TxD[5] */
	    mpc8260_ioport_cfg(MPC8260_PORTB,23,1,0,1); /* TxD[6] */
	    mpc8260_ioport_cfg(MPC8260_PORTB,22,1,0,1); /* TxD[7] */

    	    mpc8260_ioport_cfg(MPC8260_PORTB,30,1,0,1); /* TxSOC */
	    
	    if(master){
		mpc8260_ioport_cfg(MPC8260_PORTD,30,1,0,1); /* TxENB */
	    }
	    else{
		mpc8260_ioport_cfg(MPC8260_PORTD,30,1,0,0); /* TxENB */
		
	    }
	    
	    if(master){
	        mpc8260_ioport_cfg(MPC8260_PORTC,5,1,0,0) /* TxCLAV */
	    }
            else{
                mpc8260_ioport_cfg(MPC8260_PORTC,5,1,0,1) /* TxCLAV */
            }
	    
	    mpc8260_ioport_cfg(MPC8260_PORTD,8,1,0,1);  /* TxPRTY */
	    
	    /* probably one of the BRGO pins... */ /* TxCLK */
	    
	    if(mphy){
		if(master){    
                    mpc8260_ioport_cfg(MPC8260_PORTA,3,1,0,1);  /* RxAddr[0] */
                    mpc8260_ioport_cfg(MPC8260_PORTA,4,1,0,1);  /* RxAddr[1] */
	            mpc8260_ioport_cfg(MPC8260_PORTA,5,1,1,1);  /* RxAddr[2] */
		    mpc8260_ioport_cfg(MPC8260_PORTD,18,1,0,1); /* RxAddr[3] polling: multiplexed */
		    mpc8260_ioport_cfg(MPC8260_PORTD,29,1,1,1); /* RxAddr[4] */
		    
		}
		else{
	            mpc8260_ioport_cfg(MPC8260_PORTD,18,1,0,0); /* RxAddr[0] polling: multiplexed */
		    mpc8260_ioport_cfg(MPC8260_PORTD,29,1,1,0); /* RxAddr[1] polling: multiplexed */
		    mpc8260_ioport_cfg(MPC8260_PORTC,6,1,1,0);  /* RxAddr[2] polling: multiplexed */
		    mpc8260_ioport_cfg(MPC8260_PORTC,12,1,1,0); /* RxAddr[3] */
	            mpc8260_ioport_cfg(MPC8260_PORTC,14,1,1,0); /* RxAddr[4] */
		}
            }

            mpc8260_ioport_cfg(MPC8260_PORTB,4,1,0,0); /* RxD[0] */
	    /* mpc8260_ioport_cfg(MPC8260_PORTD,11,1,0,0); */ /* RxD[0] */
	    
            mpc8260_ioport_cfg(MPC8260_PORTB,5,1,0,0); /* RxD[1] */
	    /* mpc8260_ioport_cfg(MPC8260_PORTD,10,1,0,0); */ /* RxD[1] */
	    
            mpc8260_ioport_cfg(MPC8260_PORTB,6,1,0,0); /* RxD[2] */
	    /* mpc8260_ioport_cfg(MPC8260_PORTC,11,1,1,0); */ /* RxD[2] */
	    
            mpc8260_ioport_cfg(MPC8260_PORTB,7,1,0,0); /* RxD[3] */
	    /* mpc8260_ioport_cfg(MPC8260_PORTC,10,1,1,0); */ /* RxD[3] */
	    
	    mpc8260_ioport_cfg(MPC8260_PORTB,18,1,0,0); /* RxD[4] */
	    mpc8260_ioport_cfg(MPC8260_PORTB,19,1,0,0); /* RxD[5] */
            mpc8260_ioport_cfg(MPC8260_PORTB,20,1,0,0); /* RxD[6] */
	    mpc8260_ioport_cfg(MPC8260_PORTB,21,1,0,0); /* RxD[7] */
      	
	    mpc8260_ioport_cfg(MPC8260_PORTB,31,1,0,0); /* RxSOC */
	    
            if(master){
	        mpc8260_ioport_cfg(MPC8260_PORTC,4,1,0,1); /* RxENB */ 
            }
            else{
	        mpc8260_ioport_cfg(MPC8260_PORTC,4,1,0,0); /* RxENB */ 
	    }
	    
	    if(slave){
	        mpc8260_ioport_cfg(MPC8260_PORTB,29,1,0,1);  /* RxCLAV */
	    }
	    else{
                mpc8260_ioport_cfg(MPC8260_PORTB,29,1,0,0);  /* RxCLAV */
	    }
	    
	    mpc8260_ioport_cfg(MPC8260_PORTD,9,1,1,0); /* RxPRTY */

	    /* probably one of the BRGO pins... */ /* RxCLK */	    
	}
#endif	
	return(0);
}

/*
#########################################################
#
#  Function : utopia_init_phy
#             
#  Purpose  : Initialises the physical layer (I.e. UTOPIA phy
#             and the UTOPIA bus)
#  Args     : dev describes atm device
#             
#  Returns  : 0 for success
#             
##########################################################
*/
static int utopia_init_phy(struct atm_dev *dev)
{   
    /* PEM - to do: remove specific phy dependencies from this file!
       Maybe the phy's could init themselves? */
   
#ifdef CONFIG_IDT77106
    RETURN_ON_ERROR(start_idt77v106());
#endif
#ifdef CONFIG_ATM_VADS
    RETURN_ON_ERROR(start_vads_phy());
#endif

    RETURN_ON_ERROR(utopia_config_pins(dev));

    return 0;
}

/*
#########################################################
#
#  Function : utopia_init
#             
#  Purpose  : Initialise the CPM for utopia mode and 
#             creates structures to be used by the
#             utopia ATM device
#  Args     : pointer to registered device struct
#
#  Notes    : does not start interrupts for device. Caller
#             does this after the remaining ATM devices
#             have been initialised
#             
#  Returns  : 0 for success
#             
##########################################################
*/

int utopia_init(struct atm_dev *dev)
{
    dev_data_t * dev_data = &utopia_dev_data;

    DINIT_PRINTK(__FUNCTION__ "\n");

    dev->dev_data = dev_data;

    // Connect dev to device specific data
    // Clear everything to begin with
    memset(dev_data, 0, sizeof(*dev_data));

    /* don't some of these parameters really have nothing to do with UTOPIA?
       maybe they should be called ATM instead? */
    dev_data->immap = (immap_t*)IMAP_ADDR; 
    dev_data->fcc = ATM_FCC;
    dev_data->fcc_brg = ATM_FCC_BRG;
    dev_data->int_brg = ATM_INT_BRG;
    dev_data->rate_mode = ATM_RATE_MODE;
    dev_data->log2_max_channels = UTOPIA_LOG2_MAX_CHANNELS;
    dev_data->phy_byterate = UTOPIA_PHY_BYTERATE;
    dev_data->min_channel_byterate = ATM_MIN_CHANNEL_BYTERATE;
    dev_data->num_vpis = ATM_NUM_VPIS;
    dev_data->num_vcis_per_vpi = UTOPIA_NUM_VCIS_PER_VPI;
    dev_data->num_apc_levels = UTOPIA_NUM_APC_LEVELS;
#ifdef CONFIG_PTP_SWITCHING
    dev_data->ptp_tx_ring_size = UTOPIA_PTP_TX_RING_SIZE;
#endif
    dev_data->rcq_rx_ring_size = UTOPIA_RCQ_RX_RING_SIZE;
    dev_data->rx_ring_size = UTOPIA_RX_RING_SIZE;
    dev_data->tx_ring_size = UTOPIA_TX_RING_SIZE;
    dev_data->num_rx_bds = ATM_NUM_RX_BDS;
    dev_data->num_tx_bds = ATM_NUM_TX_BDS;
    dev_data->addr_lookup_comp = 1;
    dev_data->addr_lookup_local = 0;
    dev_data->conn_tbl_local = 0;
    dev_data->vp_tbl_ext = 0;
    dev_data->utopia.master = UTOPIA_BUS_MASTER;
    dev_data->utopia.last_phy = 0; 
    //dev_data->utopia.mphy_priority=0;
    //dev_data->utopia.mphy_polling=0;
    dev_data->utopia.bus_size = UTOPIA_BUS_SIZE;   

    RETURN_ON_ERROR(mpc8260sar_init_dev_data(dev_data));
    
    DLPRINTK("utopia_init: dev->dev_data=%p\n", dev->dev_data);    

    // Calculate the device-wide timing parameters
    RETURN_ON_ERROR(mpc8260sar_calculate_timing(dev));
  
    dev->ci_range.vpi_bits = 0;
    dev->ci_range.vci_bits = UTOPIA_LOG2_NUM_VCIS_PER_VPI;
    dev->link_rate = ATM_25_PCR;

    // Initialise CPM controller 
    RETURN_ON_ERROR(mpc8260sar_init_pram(dev,
					 UTOPIA_SCREEN_OAM,
					 UTOPIA_INTERRUPT_TABLE_SIZE));
    
    // Activate the global raw cell queue (channel 0)
    RETURN_ON_ERROR(mpc8260sar_init_rcq(dev));

    // Initialise the physical layer
    RETURN_ON_ERROR(utopia_init_phy(dev));

    return 0;
}

/*
#########################################################
#
#  Function : utopia_release
#             
#  Purpose  : Release resources used by this device
#             utopia ATM device
#  Args     : pointer to registered device struct
#
#  Returns  : 0 for success
#             
##########################################################
*/
int utopia_release(struct atm_dev *dev)
{
  return 0;
}

/* can't use dev_data->im_fcc since it has not been set up 
 * when this is first called 
 * to do: fix this */
void utopia_disable_interrupts(void)
{
  volatile immap_t* immap = (immap_t*)IMAP_ADDR;

  immap->im_fcc[fcc-1].fcc_fccm = 0x0000;
  immap->im_fcc[fcc-1].fcc_fcce = 0xFFFF;
  immap->im_fcc[fcc-1].fcc_gfmr = 0x00000000;     
}

/* PEM - removed hidden dependencies on FCC1 and BRG5 */
void utopia_enable_interrupts(struct atm_dev *dev)
{ 
  volatile immap_t* immap = (immap_t*)IMAP_ADDR;
  volatile cpm8260_t* cp = cpmp;
  dev_data_t *dev_data = (dev_data_t *) dev->dev_data;
  int fcc = dev_data->fcc;
 
  // Install the CPM SAR interrupt handler for the utopia h/w
  if(request_8xxirq(SIU_INT_FCC1+(fcc-1), utopia_interrupt_handler , 0, "atm", dev->dev_data) < 0){
    printk(KERN_ERR "Unable to install utopia interrupt handler \n");
    return;
  }

  DINIT_PRINTK ("Installed utopia_interrupt_handler\n");

  dev_data->im_fcc->fcc_fcce = 0xFFFF; 
  dev_data->im_fcc->fcc_fccm = 0x00FF;          //Enable Interrupts

  mpc8260_cmd_wait(__FUNCTION__,__LINE__);
    
  // parenthesis added due to crappy macro in cpm_8260.h
  cp->cp_cpcr = mk_cr_cmd((CPM_CR_FCC1_PAGE + fcc - 1),
			  (CPM_CR_FCC1_SBLOCK + fcc - 1), 
			  FCC_GFMR_MODE_ATM, 
			  CPM_CR_INIT_TRX) | CPM_CR_FLG; //Init RX and TX parameters
    
  mpc8260_cmd_wait(__FUNCTION__,__LINE__);

  // start clocks
  // PEM - temp debug 
  *(&immap->im_brgc5+(dev_data->int_brg-5)) |= 0x00010000;
  *(&immap->im_brgc5+(dev_data->fcc_brg-5)) |= 0x00010000;

  immap->im_intctl.ic_simrl |= (0x80000000 >> (fcc-1));     //Allow interrupts 
  
  // PEM - temp debug
  dev_data->im_fcc->fcc_gfmr |= 0x00000030;     //Enable Receive and Transmit
}


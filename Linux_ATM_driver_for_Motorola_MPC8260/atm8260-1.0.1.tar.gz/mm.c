/*
# (C) Copyright 2002
# Peter McCormick, pete261@yahoo.com
# Eastern Research Inc., http://www.erinc.com
# ported from mpc860sar project, http://mpc860sar.sourceforge.net
# 
# (C) Copyright 2001
#  David Pegler, Cambridge Broadband Ltd, dwp@cambridgebroadband.com
#  Daris Nevil,  Simple Network Magic Corporation dnevil@snmc.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#
*/

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/slab.h>

void *mm_alloc_uncached_pages(int size)
{
  void* tmp;

  tmp = kmalloc(size ,GFP_KERNEL | GFP_DMA);

  if (!tmp)
    printk(KERN_ERR "atm: kmalloc failed, size %d\n", size);

  return tmp;
}

//--------------------------------------------------------------
// mm_free_pages()
//
// Return:
//	0 if successful, a negative number on failure.
//
// Input Parameters:
//	(I) va - virtual address of the 1st page to free
//
// Frees pages allocated by mm_alloc_uncached_pages().  Restores the
// previous state of the pages.

void mm_free_pages(void *va)
{
  kfree(va);
}


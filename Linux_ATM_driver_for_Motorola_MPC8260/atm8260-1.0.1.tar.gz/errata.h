/*
#######################################################################
#
# (C) Copyright 2001
# Alex Zeffertt, Cambridge Broadband Ltd, ajz@cambridgebroadband.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston,
# MA 02111-1307 USA
#######################################################################
# Notes:
# 
# Contains #defines which, when uncommented, enable software workarounds
# to hardware bugs found in the MPC860/862.
#
#
#######################################################################
*/


/*
# (From MPC862D Errata document)
# If the RCCR is written as a byte or halfword 
# (to addresses IMMR+0x9C4, IMMR+0x9C5), then RCCR[ERAM4K]
# (located at address IMMR+0x9C7) will be cleared.
#
# Workaround:
# When one wants to change the RCCR bytes at address 
# IMMR+(0x9C4, 0x9C5), then one should write the whole
#  word (addresses IMMR+0x9C4 to IMMR+0x9C7).
*/
#define RCCR_BUG

/*
# The FADS board has a problem:
# If you are making frequent external memory
# accesses then this causes SMC1 (used by
# ttyS0) to think that it's receiving characters.
# Here's how to reproduce this problem.
# o    Write a user program which continuously sends
#      and recieves 6 cell AAL5 frames on a ATM socket.
# o    Make socket UBR (this makes channel use all 
#      the available bandwidth)
# o    Modify mpc860sar.c so that we only use
#      internal Connection tables
# 
# With the above program I've noticed about 1 rx
# interrupt per 1000 cells.
# 
# Workaround:
# This h/w bug can be fixed by giving IDMA
# requests the lowest priority - i.e. by setting
# RCCR[DRQP] = 10.
*/
#define FADS_BUG

/*
# In Table 2-1 (recieve Buffer Descriptors) of the "Enhanced SAR Functionality Supplement" it says:
#        "Note: In AAL0, if NCRC in the RCT status sord is set, the CR indication
#         will not be valid (CR=0)"
# However, when you
# o       set up an AAL0 channel
# o       set RCT[NCRC]
# o       receive cells on the channel
# the CR bits in the buffer descriptors get set.
# This means one of two things:
# o       Setting RCT[NCRC] does not turn off CRC checking - the CPM does the work anyway
# o       Table 2-1 should say "the CR indication should be ignored" rather than "the CR
#         indication will not be valid (CR=0)"
#
# This problem was first observed on an MPC860 using UTOPIA.  That was fixed in revision 860E silicon
# This problem was then observed on an MPC862 using serial ATM.  It looks like 
# Motorola should have fixed it in two places but only fixed it in one.
#
# Workaround:
# Ignore CR if aal == AAL0 and the current cell
# is not an OAM cell
#
*/
#define CRC_BUG

/*
# When you open a UBR channel the driver does not immediately
# send an ACTIVATE_TRANSMIT_CHANNEL command to the CPCR, as 
# is the case with CBR channels.
# Instead, the driver enables "Auto VC off" in the TCT
# (See "Enhanced SAR Functionality Supplement pg 2-19.)
# It then waits for mpc860sar_send() to be called.
# This function then checks TCT[ACT] to see if the channel 
# has either (a) never been enabled, or (b) been disabled
# by the CPM after the tx BDs were found to be empty.
# mpc860sar_send() will then only send an ACTIVATE_TRANSMIT_CHANNEL
# command to the CPCR if it finds that TCT[ACT]=0 
# (indicating that the channel has been disabled,
# and all entries have been removed from the APC scheduling table.)
#
# The problem:
# The problem is that the CPM often clears TCT[ACT]
# BEFORE removing the entry from the APC sheduling table.
# If the code just believes TCT[ACT] and sends an
# ACTIVATE_TRANSMIT_CHANNEL anyway, this will cause
# 2 entries to appear in the APC sheduling table
# for the one channel.
# If this goes on the number of entries in the 
# APC scheduling table will continue to grow, and
# the APC_SPTR will eventually be wrapped by the
# APC_PTR.  This results in an APCOverflow interrupt.
#
# Workaround:
# Do not use Auto-VC-Off for UBR channels.  Instead have 
# mpc860sar_tx_bh() deactivate the channel
# if it finds that there are no tx BDs waiting to be sent.
# (This deactivation should be allowed to complete - i.e.
# it should wait for the channel to be removed from the
# APC sheduling table.)
# mpc860sar_tx_bh() should then set a flag (dis) in the cpm_channel_t
# structure.
# mpc860sar_send() should then check the flag to see
# if it needs to reactivate the channel.
# This effectively emulates Auto-VC-Off in software.
*/
#define ACT_BUG

/*
 # Problem:
 # If you set NCITS less than 1 then the APC_PTRx for that ATM
 # port increment at 1/NCITS of the rate at which they are supposed
 # to increment (i.e. the APC tick rate).
 # 
 # Workaround:
 # o       work out the NCITS required in usual manner
 # o       round up to 1 if this is < 1
 */
#define APC_BUG

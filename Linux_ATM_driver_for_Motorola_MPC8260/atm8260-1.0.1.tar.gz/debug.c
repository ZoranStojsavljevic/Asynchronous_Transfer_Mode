#include <linux/module.h>
#include <linux/config.h>
#include <linux/kernel.h>
#include <linux/vmalloc.h>	/* for vmalloc */
#include <linux/mm.h>
#include <linux/pci.h>
#include <linux/errno.h>
#include <linux/atm.h>
#include <linux/atmdev.h>
#include <linux/sonet.h>
#include <linux/skbuff.h>
#include <linux/time.h>
#include <linux/timex.h>
#include <linux/sched.h>	/* for xtime */
#include <linux/delay.h>
#include <linux/uio.h>
#include <linux/init.h>
#include <asm/system.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include <asm/string.h>
#include <asm/byteorder.h>

#include <linux/netdevice.h>
#include <linux/ioport.h>
#include <linux/atm.h>

#include <asm/mpc8260.h>
#include <asm/immap_8260.h>
#include <asm/cpm_8260.h>
#include "mpc8260sar.h"
#include "mpool.h"
#include "intpool.h"
#include "cpmtimer.h"
#include "mm.h"
#include "risctimer.h"
#include "debug.h"
#include "errata.h"

void report_error(char * module, int line)
{
  printk(KERN_ERR "Failure in %s line %d\n",module,line);
}

#ifdef DEBUG_XMIT

void print_table(ushort * p)
{
    int i;
    printk("Now printing address %p\n", p);
    for (i = 0; i < 16; i++) {
	printk("%4x\n", *p);
	p++;
    }
    printk("End of printing...\n");
}

void print_tabled(uint * p, int num)
{
    int i;
    printk("Now printing address %p\n", p);
    for (i = 0; i < num; i++) {
	printk("%8x\n", *p);
	p++;
    }
    printk("End of printing...\n");
}

void debug_print(struct atm_dev *dev, int param)
{
    dev_data_t *dev_data = (dev_data_t *) dev->dev_data;

    if (param == 1) {
	printk("FCC Parameter RAM\n");
	printk("---------------------------------------------\n");
	printk("riptr=%x ", dev_data->sar_pram->fcc.riptr);
	printk("tiptr=%x ", dev_data->sar_pram->fcc.tiptr);
	printk("mrblr=%x ", dev_data->sar_pram->fcc.mrblr);
	printk("rstate=%lx\n", dev_data->sar_pram->fcc.rstate);
	printk("rbase=%p ", dev_data->sar_pram->fcc.rbase);
	printk("rbdstat=%x ", dev_data->sar_pram->fcc.rbdstat);
	printk("rbdlen=%x ", dev_data->sar_pram->fcc.rbdlen);
	printk("rdptr=%lx\n", dev_data->sar_pram->fcc.rdptr);
	printk("tstate=%lx ", dev_data->sar_pram->fcc.tstate);
	printk("tbase=%p ", dev_data->sar_pram->fcc.tbase);
	printk("tbdstat=%x ", dev_data->sar_pram->fcc.tbdstat);
	printk("tbdlen=%x\n", dev_data->sar_pram->fcc.tbdlen);
	printk("tdptr=%lx ", dev_data->sar_pram->fcc.tdptr);
	printk("rbptr=%lx ", dev_data->sar_pram->fcc.rbptr);
	printk("tbptr=%lx ", dev_data->sar_pram->fcc.tbptr);
	printk("rcrc=%lx\n", dev_data->sar_pram->fcc.rcrc);
	printk("tcrc=%lx\n", dev_data->sar_pram->fcc.tcrc);
	printk("---------------------------------------------\n");
    }
    if (param == 2) {
	printk("ATM Parameter RAM\n");
	printk("---------------------------------------------\n");
	printk("RCELL_TMP_BASE=%x ", dev_data->sar_pram->atm.RCELL_TMP_BASE);
	printk("TCELL_TMP_BASE=%x ", dev_data->sar_pram->atm.TCELL_TMP_BASE);
	printk("UDC_TMP_BASE=%x ", dev_data->sar_pram->atm.UDC_TMP_BASE);
	printk("INT_RCT_BASE=%x ", dev_data->sar_pram->atm.INT_RCT_BASE);
	printk("INT_TCT_BASE=%x\n", dev_data->sar_pram->atm.INT_TCT_BASE);
	printk("INT_TCTE_BASE=%x ", dev_data->sar_pram->atm.INT_TCTE_BASE);
	printk("EXT_RCT_BASE=%p ", dev_data->sar_pram->atm.EXT_RCT_BASE);
	printk("EXT_TCT_BASE=%p ", dev_data->sar_pram->atm.EXT_TCT_BASE);
	printk("EXT_TCTE_BASE=%p ", dev_data->sar_pram->atm.EXT_TCTE_BASE);
	printk("UeadOffset=%x\n", dev_data->sar_pram->atm.UeadOffset);
	printk("PmtBase=%x ", dev_data->sar_pram->atm.PmtBase);
	printk("ApcParamBase=%x ", dev_data->sar_pram->atm.ApcParamBase);
	printk("FbpParamBase=%x ", dev_data->sar_pram->atm.FbpParamBase);
	printk("IntQParamBase=%x ", dev_data->sar_pram->atm.IntQParamBase);
	printk("UniStatTableBase=%x\n",
	       dev_data->sar_pram->atm.UniStatTableBase);
	printk("BD_BASE_EXT=%lx ", dev_data->sar_pram->atm.BD_BASE_EXT);
	printk("VPT_BASE=%p ", dev_data->sar_pram->atm.VPT_BASE);
	printk("VctBase=%lx ", dev_data->sar_pram->atm.VctBase);
	printk("Vpt1Base=%lx ", dev_data->sar_pram->atm.Vpt1Base);
	printk("Vct1Base=%lx\n", dev_data->sar_pram->atm.Vct1Base);
	printk("VpMask=%x ", dev_data->sar_pram->atm.VpMask);
	printk("VciFiltering=%x ", dev_data->sar_pram->atm.VciFiltering);
	printk("GMODE=%x ", dev_data->sar_pram->atm.GMODE);
	printk("CommInfo1=%x ", dev_data->sar_pram->atm.CommInfo1);
	printk("Channel_num=%x\n", dev_data->sar_pram->atm.Channel_num);
	printk("Burst_tol=%x ", dev_data->sar_pram->atm.Burst_tol);
	printk("CRC32Preset=%lx ", dev_data->sar_pram->atm.CRC32Preset);
	printk("CRC32Mask=%lx ", dev_data->sar_pram->atm.CRC32Mask);
	printk("AAL1SnpTableBase=%x ",
	       dev_data->sar_pram->atm.AAL1SnpTableBase);
	printk("SrtsBase=%lx\n", dev_data->sar_pram->atm.SrtsBase);
	printk("IdleBase=%x ", dev_data->sar_pram->atm.IdleBase);
	printk("IdleSize=%x ", dev_data->sar_pram->atm.IdleSize);
	printk("EmptyCellPayload=%lx ",
	       dev_data->sar_pram->atm.EmptyCellPayload);
	printk("Trm=%lx ", dev_data->sar_pram->atm.Trm);
	printk("Nrm=%x\n", dev_data->sar_pram->atm.Nrm);
	printk("Mrm=%x ", dev_data->sar_pram->atm.Mrm);
	printk("Tcr=%x ", dev_data->sar_pram->atm.Tcr);
	printk("AbrRxTcte=%x\n", dev_data->sar_pram->atm.AbrRxTcte);
	printk("---------------------------------------------\n");
    }
}
#endif
